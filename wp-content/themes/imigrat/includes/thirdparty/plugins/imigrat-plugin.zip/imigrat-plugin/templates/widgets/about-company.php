<?php
extract($args);
echo wp_kses_post($before_widget); ?>

<div class="logo-widget">
    <?php if ($instance['widget_logo_img']) { ?>
    <div class="brand-logo">
        <img src="<?php echo esc_url(wp_get_attachment_url($instance['widget_logo_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
    </div>
    <?php } ?>
    
	<?php if ($instance['content2']) { ?>
    <div class="logo-desc">
        <?php echo wp_kses_post($instance['content2']); ?>
    </div>
    <?php } ?>
    
	<?php if($instance['widget_author_name'] || $instance['widget_email_address']){ ?>
    <div class="logo-twitter d-flex align-items-center">
        <div class="inner-icon d-flex align-items-center justify-content-center">
            <i class="fab fa-twitter"></i>
        </div>
        <div class="inner-text headline">
            <h4><?php echo wp_kses_post($instance['widget_author_name']); ?></h4>
            <a href="<?php echo esc_attr($instance['widget_email_address']); ?>"><?php echo wp_kses_post($instance['widget_email_address']); ?></a>
        </div>
    </div>
    <?php } ?>
    
</div>
<?php

echo wp_kses_post($after_widget);
