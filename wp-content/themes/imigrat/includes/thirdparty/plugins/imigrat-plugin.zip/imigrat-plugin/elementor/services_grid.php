<?php

namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Services_Grid extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_services_grid';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Services Grid', 'imigrat' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tools';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		$this->add_control(
			'style_two',
			[
				'label'   => esc_html__( 'Choose Different Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'one' => esc_html__( 'Style One ', 'imigrat'),
					'two'  => esc_html__( 'Style Two', 'imigrat' ),
					'three' => esc_html__( 'Style Three', 'imigrat' ),
					'four' => esc_html__( 'Style Four', 'imigrat' ),
					'five' => esc_html__( 'Style Five', 'imigrat' ),
				),
			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'style_two' => ['three', 'four', 'five'],
				]
            ]
        );

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Bg Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style_two' => ['three', 'four'],
				]
			]
		);

		$this->add_control(
			'image1',
			[
				'label' => esc_html__('Box Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image2',
			[
				'label' => esc_html__('Box Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style_two' => ['four'],
				]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'title_section',
            [
                'label' => esc_html__( 'SECTION TITLE', 'imigrat' ),
				'condition' => [
					'style_two' => ['three', 'five'],
				]
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'style_two' => ['three', 'five'],
				]
            ]
        );

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_grid',
			[
				'label' => esc_html__( 'Imigrat Services Grid', 'imigrat' ),
			]
		);

		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default'  => esc_html__( 'Default', 'imigrat' ),
					'one' => esc_html__( 'One Column Grid ', 'imigrat'),
					'two'  => esc_html__( 'Two Column Grid', 'imigrat' ),
					'three'  => esc_html__( 'Three Column Grid', 'imigrat' ),
					'four'  => esc_html__( 'Four Column Grid', 'imigrat' ),
					'five'  => esc_html__( 'Six Column Grid', 'imigrat' ),
				),
			]
		);

		$this->add_control(
			'btn_title',
			[
				'label' => esc_html__( 'Button Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter button title', 'imigrat' ),
				'default' => esc_html__( 'Read More', 'imigrat' ),
			]
		);

		$this->add_control(
            'text_limit',
            [
                'label'   => esc_html__( 'Text Limit', 'imigrat' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 6,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'imigrat' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'imigrat' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'imigrat' ),
                    'title'      => esc_html__( 'Title', 'imigrat' ),
                    'menu_order' => esc_html__( 'Menu Order', 'imigrat' ),
                    'rand'       => esc_html__( 'Random', 'imigrat' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'imigrat' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'imigrat' ),
                    'ASC'  => esc_html__( 'ASC', 'imigrat' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'imigrat'),
				'label_block' => true,
                'options' => get_service_categories(),
            ]
        );
		$this->add_control(
			'button_label',
			[
				'label'       => __( 'Button Label', 'imigrat' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'default'  => __('Read More', 'imigrat'),
				'placeholder' => __( 'Enter your title', 'imigrat' ),

			]
		);
		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('LOOP STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		//Loop Background Color Style
		$this->add_control(
			'show_loop_shape_style',
			[
				'label'       => __( 'ON/OFF  Shape Background Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'loop_shape_bgcolor',
				'label' => __( 'Loop Shape Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' =>
					'{{WRAPPER}} .imi-service-item-2',
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
			]
		);

		//Title Style
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' =>
                    '
					{{WRAPPER}} .imi-service-item-2 .imi-service-text h3,
					{{WRAPPER}} .service-block_one-heading a
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item-2 .imi-service-text h3 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_one-heading a' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_hover_color',
            [
                'label' => __('Title Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item-2 .imi-service-text h3:hover a' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_border_color',
            [
                'label' => __('Title Border Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item-2 .imi-service-text h3:before' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_border_hover_color',
            [
                'label' => __('Title Border Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item-2 .imi-service-text h3:after' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );

		//Content Style
		$this->add_control(
			'show_loop_content_style',
			[
				'label'       => __( 'ON/OFF  Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_content_typography',
                'label' => __('Content Typography', 'imigrat'),
                'selector' =>
                    '
					{{WRAPPER}} .imi-service-item-2 .imi-service-text p,
					{{WRAPPER}} .service-block_one-text
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_content_color',
            [
                'label' => __('Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item-2 .imi-service-text p' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_one-text' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		//Button Style
		$this->add_control(
			'show_loop_btn_style',
			[
				'label'       => __( 'ON/OFF  Button Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_btn_typography',
                'label' => __('Button Typography', 'imigrat'),
                'selector' =>
                    '
					{{WRAPPER}} .service_more_btn,
					{{WRAPPER}} .service-block_one-more
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_btn_color',
            [
                'label' => __('Button Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .service_more_btn' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_one-more' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_btn_hover_color',
            [
                'label' => __('Button Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .service_more_btn:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .service-block_one-more:hover' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_btn_hover_border_color',
            [
                'label' => __('Button Hover Border Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item-2 .imi-service-text .service_more_btn:before' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_btn_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .color-layer',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);
		$this->end_controls_section();

		// button style
		$this->start_controls_section(
			'btn_style',
			[
				'label' => __( 'BUTTON STYLE', 'imigrat-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// enable button style
		$this->add_control(
			'show_btn_style2',
			[
				'label'       => __( 'ON/OFF Button Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		// button typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_title_typography2',
				'label' => __('Button Text Typography', 'imigrat-plugin'),
				'selector' =>
					'
						{{WRAPPER}} .btn-style-one span,
						{{WRAPPER}} .btn-style-two span,
						{{WRAPPER}} .btn-style-four span,
						{{WRAPPER}} .btn-style-seven span
					',
				'separator' => 'before',
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// border radius
		$this->add_responsive_control(
			'btn_border_radius2',
			[
				'label'              => __( 'Border Radius', 'imigrat-plugin' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .btn-style-one' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-two' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-four' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-seven' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],

				'frontend_available' => true,
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->start_controls_tabs( '_tabs_button-' );

		$this->start_controls_tab(
            '_tab_button_normal',
            [
                'label' => __( 'Normal', 'elementhelper' ),
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
            ]
        );

		// button color
		$this->add_control(
			'btn_title_color2',
			[
				'label' => __( 'Button Text Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven span' => 'color: {{VALUE}}!important',
				],
				'condition' => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg color
		$this->add_control(
			'btn_bg_color2',
			[
				'label' => __( 'Button Background Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
            'button_hover',
            [
                'label' => __( 'Hover', 'elementhelper' ),
            ]
        );

		// button hover color
		$this->add_control(
			'btn_title_hover_color2',
			[
				'label' => __( 'Button Text Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover span' => 'color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg hover color
		$this->add_control(
			'btn_bg_hover_color2',
			[
				'label' => __( 'Button Background Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover::before' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();
        $this->end_controls_tabs();

		$this->end_controls_section();

	}

	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$grid_col = $settings[ 'col_grid' ];
		$btn_title = $settings[ 'btn_title' ];

		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-6 col-sm-12';
		}else{
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}

        $paged = imigrat_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-imigrat' );

        $args = array(
            'post_type'      => 'service',
            'posts_per_page' => imigrat_set( $settings, 'query_number' ),
            'orderby'        => imigrat_set( $settings, 'query_orderby' ),
            'order'          => imigrat_set( $settings, 'query_order' ),
            'paged'         => $paged
        );

        if( imigrat_set( $settings, 'query_category' ) ) $args['service_cat'] = imigrat_set( $settings, 'query_category' );
        $query = new \WP_Query( $args );
        if ( $query->have_posts() ) :

	?>

	<?php if($settings['style_two'] == 'five' ) : ?>
	<section class="services-four">
		<?php if(!empty( $settings['image1']['id'] )) : ?>
		<div class="services-four_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)"></div>
		<?php endif; ?>
		<?php if(!empty( $settings['image2']['id'] )) : ?>
		<div class="services-four_pattern-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"></div>
		<?php endif; ?>
		<div class="container">
			<div class="sec-title-three centered">
				<?php if(!empty( $settings['sub_title'] )) : ?>
				<div class="title"><?php echo wp_kses($settings['sub_title'], true); ?></div>
				<?php endif; ?>

				<?php if(!empty( $settings['title'] )) : ?>
				<h2><?php echo wp_kses($settings['title'], true); ?></h2>
				<?php endif; ?>
			</div>
			<div class="row">

				<?php while ( $query->have_posts() ) : $query->the_post();
				 $imigrat_service_meta = get_post_meta( get_the_ID(), 'imigrat_meta_service', true );
					$post_thumb_url = get_the_post_thumbnail_url( get_the_ID(), 'full' );
				 ?>
				<div class="service-block_three col-lg-4 col-md-6 col-sm-12">
					<div class="service-block_three-inner">
						<div class="triangle-one"></div>
						<div class="triangle-two"></div>
						<?php if(!empty( $imigrat_service_meta['service_icon_img']['id'] )) : ?>
						<div class="service-block_three-icon">
							<img src="<?php echo esc_url( wp_get_attachment_url( $imigrat_service_meta['service_icon_img']['id'], true ) );?>" alt="" />
						</div>
						<?php endif; ?>
						<h4 class="service-block_three-title"><a href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
							<?php the_title();?>
						</a></h4>
						<div class="service-block_three-text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>
						<div class="service-block_three-arrow">
							<a class="arrow" href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
							<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-4.png" alt="" /></a>
						</div>
						<div class="overlay-box"
							<?php if(has_post_thumbnail()) : ?>
							style="background-image: url(<?php echo esc_url($post_thumb_url); ?>)"
							>
							<?php endif; ?>
							<div class="overlay-box_inner">
								<?php if(!empty( $imigrat_service_meta['service_icon_img']['id'] )) : ?>
								<div class="service-block_three-icon">
									<img src="<?php echo esc_url( wp_get_attachment_url( $imigrat_service_meta['service_icon_img']['id'], true ) );?>" alt="" />
								</div>
								<?php endif; ?>
								<h4 class="service-block_three-title">
									<a href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>"><?php the_title();?></a>
								</h4>
								<div class="service-block_three-text">
									<?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?>
								</div>
								<!-- Button Box -->
								<div class="button-box">
									<a class="btn-style-seven theme-btn" href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
										<div class="btn-wrap">
											<span class="text-one">
											<?php if( !empty( $btn_title ) ):?>
												<?php echo wp_kses( $btn_title, true );?>
											<?php else: ?>
												<?php esc_html_e('More Details', 'imigrat');?>
											<?php endif;?>
											<i class="fal fa-angle-double-right fa-fw"></i></span>
											<span class="text-two">
											<?php if( !empty( $btn_title ) ):?>
												<?php echo wp_kses( $btn_title, true );?>
											<?php else: ?>
												<?php esc_html_e('More Details', 'imigrat');?>
											<?php endif;?>
											<i class="fal fa-angle-double-right fa-fw"></i></span>
										</div>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endwhile; ?>

				<!-- Text Column -->
				<div class="services-four_text-column col-lg-4 col-md-6 col-sm-12">
					<?php if(!empty( $settings['text'] )) : ?>
					<div class="text">
						<?php echo wp_kses($settings['text'], true); ?>
					</div>
					<?php endif; ?>
					<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
					<div class="button-box">
						<a class="btn-style-eight theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
							<div class="btn-wrap">
								<span class="text-one"><?php echo wp_kses($settings['button_text'], true); ?>
								 <i class="fal fa-angle-double-right fa-fw"></i></span>
								<span class="text-two"><?php echo wp_kses($settings['button_text'], true); ?>
								 <i class="fal fa-angle-double-right fa-fw"></i></span>
							</div>
						</a>
					</div>
					<?php endif; ?>
				</div>

			</div>
		</div>
	</section>
	<?php elseif($settings['style_two'] == 'four' ) : ?>
	<section class="services-two"
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"
		<?php endif; ?>
	>

		<?php if(!empty( $settings['image1']['id'] )) : ?>
		<div class="services-two_icon" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['image2']['id'] )) : ?>
		<div class="services-two_icon-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"></div>
		<?php endif; ?>
		<div class="container">
			<div class="row g-0 clearfix">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
                <?php $imigrat_service_meta = get_post_meta( get_the_ID(), 'imigrat_meta_service', true );?>
				<div class="service-block_two <?php echo esc_attr( $classes );?>">
					<div class="service-block_two-inner">
						<?php if(!empty( $imigrat_service_meta['service_icon_img']['id'] )) : ?>
						<div class="service-block_two-icon">
							<img src="<?php echo esc_url( wp_get_attachment_url( $imigrat_service_meta['service_icon_img']['id'], true ) );?>" alt="<?php esc_attr_e('Awesome Image', 'imigrat');?>">
						</div>
						<?php endif; ?>
						<h4 class="service-block_two-heading">
							<a href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>"><?php the_title();?></a>
						</h4>
						<div class="service-block_two-text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
		</div>
	</section>
	<?php elseif($settings['style_two'] == 'three' ) : ?>

	<section class="services-one"
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"
		<?php endif; ?>
		>
		<div class="container">
			<div class="sec-title">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box d-block">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>
					</div>

					<?php if(!empty( $settings['text'] )) : ?>
					<div class="text">
						<?php echo wp_kses($settings['text'], true); ?>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="row clearfix">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
                <?php $imigrat_service_meta = get_post_meta( get_the_ID(), 'imigrat_meta_service', true );?>
				<!-- Service Block One -->
				<div class="service-block_one <?php echo esc_attr( $classes );?>">

					<?php if(!empty( $settings['image1'] )) : ?>
					<div class="service-block_one_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)"></div>
					<?php endif; ?>

					<div class="service-block_one-inner wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1000ms">
						<?php if(has_post_thumbnail()): ?>
						<div class="service-block_one-image">
							<a href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
								<?php the_post_thumbnail('large', array('class' => 'img-fluid')); ?>
							</a>
						</div>
						<?php endif; ?>
						<div class="service-block_one-content">
							<div class="service-block_one-upper">
								<h4 class="service-block_one-heading">
									<a href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
										<?php the_title();?>
									</a>
								</h4>
								<div class="service-block_one-text">
									<p><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></p>
								</div>
							</div>
							<div class="service-block_one-lower">
								<a class="service-block_one-more" href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
									<?php if( !empty( $btn_title ) ):?>
										<?php echo wp_kses( $btn_title, true );?>
									<?php else: ?>
										<?php esc_html_e('Read More', 'imigrat');?>
									<?php endif;?>
								</a>
							</div>
						</div>
					</div>
				</div>
				<?php endwhile; ?>
			</div>

			<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
			<!-- Button Box -->
			<div class="button-box text-center">
				<a class="btn-style-one theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
					<div class="btn-wrap">
						<span class="text-one">
							<?php echo wp_kses($settings['button_text'], true);?> <i>
								<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" /></i></span>
						<span class="text-two">
							<?php echo wp_kses($settings['button_text'], true);?> <i>
								<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" /></i></span>
					</div>
				</a>
			</div>
			<?php endif; ?>
		</div>
	</section>

	<?php else : ?>
    <section id="imi-service-2" class="imi-service-section-2 p-0 m-0">
		<div class="container">
			<div class="<?php if($settings['style_two'] == 'two') echo 'imi-service-content-3'; else echo 'imi-service-content-2'?>">
				<div class="row justify-content-center">
                	<?php while ( $query->have_posts() ) : $query->the_post(); ?>
                    <?php $imigrat_service_meta = get_post_meta( get_the_ID(), 'imigrat_meta_service', true );?>
					<div class="<?php echo esc_attr( $classes );?>  wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1000ms">
						<div class="imi-service-item-2">
							<?php if(!empty( $imigrat_service_meta['service_icon_img']['id'] )) : ?>
							<div class="imi-service-icon text-center">
								<img src="<?php echo esc_url( wp_get_attachment_url( $imigrat_service_meta['service_icon_img']['id'], true ) );?>" alt="<?php esc_attr_e('Awesome Image', 'imigrat');?>">
							</div>
							<?php endif; ?>
							<div class="imi-service-text headline-2 pera-content">
								<h3><a href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>"><?php the_title();?></a></h3>

								<p><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></p>

								<a class="service_more_btn text-uppercase" href="<?php echo esc_url( get_the_permalink( get_the_ID() ) );?>">
                                <?php if( !empty( $btn_title ) ):?>
									<?php echo wp_kses( $btn_title, true );?>
                                <?php else: ?>
                                    <?php esc_html_e('Read More', 'imigrat');?>
                                <?php endif;?>
                             	<i class="fal fa-long-arrow-right"></i></a>
							</div>
						</div>
					</div>
                    <?php endwhile; ?>
				</div>
			</div>
		</div>
	</section>
	<?php
		endif;
		endif;
    wp_reset_postdata();
	}
}