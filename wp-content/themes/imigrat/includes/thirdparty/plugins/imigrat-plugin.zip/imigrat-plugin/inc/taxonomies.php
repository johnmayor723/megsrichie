<?php
namespace IMIGRATPLUGIN\Inc;
use IMIGRATPLUGIN\Inc\Abstracts\Taxonomy;
class Taxonomies extends Taxonomy {
	public static function init() {
		//Projects
		$labels = array(
			'name'              => _x( 'Project Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Project Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Project Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'project_cat' ),
		);
		register_taxonomy( 'project_cat', 'project', $args );
		
		//Services Taxonomy Start
		$labels = array(
			'name'              => _x( 'Service Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Service Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Service Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'service_cat' ),
		);
		register_taxonomy( 'service_cat', 'service', $args );
		
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Testimonials Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Testimonials Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);
		register_taxonomy( 'testimonials_cat', 'testimonials', $args );
		
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Team Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Team Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);
		register_taxonomy( 'team_cat', 'team', $args );
		
		//Faqs Taxonomy Start
		$labels = array(
			'name'              => _x( 'Faqs Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Faq Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Faq Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'faqs_cat' ),
		);
		register_taxonomy( 'faqs_cat', 'faqs', $args );
		
		
		//Visa Taxonomy Start
		$labels = array(
			'name'              => _x( 'Visa Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Visa Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Visa Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'visa_cat' ),
		);
		register_taxonomy( 'visa_cat', 'visa', $args );
		
		
		//Country Taxonomy Start
		$labels = array(
			'name'              => _x( 'Country Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Country Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Country Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'country_cat' ),
		);
		register_taxonomy( 'country_cat', 'country', $args );
		
		//Jobs Taxonomy Start
		$labels = array(
			'name'              => _x( 'Jobs Category', 'wpimigrat' ),
			'singular_name'     => _x( 'Jobs Category', 'wpimigrat' ),
			'search_items'      => __( 'Search Category', 'wpimigrat' ),
			'all_items'         => __( 'All Categories', 'wpimigrat' ),
			'parent_item'       => __( 'Parent Category', 'wpimigrat' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpimigrat' ),
			'edit_item'         => __( 'Edit Category', 'wpimigrat' ),
			'update_item'       => __( 'Update Category', 'wpimigrat' ),
			'add_new_item'      => __( 'Add New Category', 'wpimigrat' ),
			'new_item_name'     => __( 'New Category Name', 'wpimigrat' ),
			'menu_name'         => __( 'Jobs Category', 'wpimigrat' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'jobs_cat' ),
		);
		register_taxonomy( 'jobs_cat', 'jobs', $args );
	}
	
}
