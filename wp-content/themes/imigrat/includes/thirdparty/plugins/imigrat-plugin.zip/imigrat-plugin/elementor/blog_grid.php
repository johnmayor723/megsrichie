<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Blog_Grid extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_blog_grid';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Blog Grid', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-list';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat'),
					'4' => esc_html__( 'Style Four ', 'imigrat'),
					'5' => esc_html__( 'Style Six ', 'imigrat'),
				),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'layout_control' => ['4', '5'],
				],
            ]
        );

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Section Bg Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
				'condition' => [
					'layout_control' => ['3', '4', '5'],
				],
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'blog_grid',
            [
                'label' => esc_html__( 'Imigrat Blog Grid', 'imigrat' ),
            ]
        );

		$this->add_control(
            'author',
            [
                'label'        => esc_html__( 'Show Author', 'imigrat' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'imigrat' ),
                'label_off'    => esc_html__( 'Off', 'imigrat' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
            'date',
            [
                'label'        => esc_html__( 'Show Date', 'imigrat' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'imigrat' ),
                'label_off'    => esc_html__( 'Off', 'imigrat' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );
		$this->add_control(
			'btn_title',
			[
				'label' => esc_html__( 'Button Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter button title', 'imigrat' ),
				'default' => esc_html__( 'Read More', 'imigrat' ),
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'imigrat' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
		$this->add_control(
            'text_limit',
            [
                'label'   => esc_html__( 'Text Limit', 'imigrat' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 6,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'imigrat' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'imigrat' ),
                    'title'      => esc_html__( 'Title', 'imigrat' ),
                    'menu_order' => esc_html__( 'Menu Order', 'imigrat' ),
                    'rand'       => esc_html__( 'Random', 'imigrat' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'imigrat' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'imigrat' ),
                    'ASC'  => esc_html__( 'ASC', 'imigrat' ),
                ),
            ]
        );
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'imigrat'),
				'label_block' => true,
                'options' => get_blog_categories(),
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'layout_control' => ['4', '5'],
				],
            ]
        );

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-blog-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
					'{{WRAPPER}} .imi-blog-section-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-blog-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
					'{{WRAPPER}} .imi-blog-section-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-blog-content,
							   {{WRAPPER}} .imi-blog-section-2',
			]
		);
		$this->end_controls_section();

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .color-layer',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography2',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke2',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow2',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype2',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_control(
			'text_color2',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography2',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__( 'Loop Style', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'show_loop_shape_style',
			[
				'label'       => __( 'ON/OFF Shape Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'layout_control'    => '1'
				]
			]
		);
		$this->add_responsive_control(
            'loop_shape__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-blog-item:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
            ]
        );
        $this->add_responsive_control(
            'loop_shape_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-blog-item:before' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_box_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' =>
					'{{WRAPPER}} .imi-blog-item:before,
					 {{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3',
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'general_box_border_type',
				'selector' =>
					'{{WRAPPER}} .imi-blog-item:before,
					 {{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3',
				'separator' => 'before',
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'general_box_shadow',
				'selector' =>
					'{{WRAPPER}} .imi-blog-item:before,
					 {{WRAPPER}} .imi-blog-item-2:before',
				'separator' => 'before',
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'general_border_radius',
			[
				'label' => esc_html__('Border Radius', 'imigrat'),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'             => [
					'show_loop_shape_style'    => 'yes',
				]
			]
		);

		//Date Style
		$this->add_control(
			'show_loop_date_style',
			[
				'label'       => __( 'ON/OFF Date Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'layout_control'    => ['2', '3']
				]
			]
		);
		$this->add_control(
			'loop_date_bg_color',
			[
				'label' => esc_html__( 'Date BG Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-date' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .news-block_one-date' => 'background-color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'loop_date_day_typography',
				'label' => __('Day Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-blog-item-2 .imi-blog-date,
				{{WRAPPER}} .news-block_one-date
				',
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'loop_date_color',
			[
				'label' => esc_html__( 'Day Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-date' => 'color: {{VALUE}};',
					'{{WRAPPER}} .news-block_one-date' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'loop_date_month_bg_color',
			[
				'label' => esc_html__( 'Date Month/Year BG Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-date span' => 'background-color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'loop_date_month_typography',
				'label' => __('Month/Year Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-blog-item-2 .imi-blog-date span',
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'loop_date_month_color',
			[
				'label' => esc_html__( 'Month/Year Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-date span' => 'color: {{VALUE}};'
				],
				'condition'             => [
					'show_loop_date_style'    => 'yes',
				]
			]
		);

		//Title Style
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'title_color2',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item .imi-blog-text h3 a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3' => 'color: {{VALUE}};',
					'{{WRAPPER}} .news-block_one-heading a' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item .imi-blog-text h3:hover a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3:hover a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .news-block_one-heading:hover a' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-blog-item .imi-blog-text h3,
								{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3,
								{{WRAPPER}} .news-block_one-heading a
								',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-blog-item .imi-blog-text h3,
				{{WRAPPER}} .imi-blog-item-2 .imi-blog-text h3,
				{{WRAPPER}} .news-block_one-heading a
							   ',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'show_loop_meta_style',
			[
				'label'       => __( 'ON/OFF Loop Meta Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'meta__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-blog-item .imi-blog-text .blog-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					 '{{WRAPPER}} .imi-blog-item-2  .imi-blog-text-meta .imi-blog-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
            ]
        );
        $this->add_responsive_control(
            'meta_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-blog-item .imi-blog-text .blog-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-blog-item-2  .imi-blog-text-meta .imi-blog-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'meta_icon_color',
			[
				'label' => esc_html__( 'Meta Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item .imi-blog-text .blog-meta a i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-meta a i' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item .imi-blog-text .blog-meta a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-blog-item-2 .imi-blog-meta a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .news-block_one-author' => 'color: {{VALUE}};',

				],
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'cat_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-blog-item .imi-blog-text .blog-meta a,
							   {{WRAPPER}} .imi-blog-item-2 .imi-blog-meta a,
							   {{WRAPPER}} .news-block_one-author
							   ',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
			]

		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'cat_text_shadow',
				'selector' => '{{WRAPPER}} .imi-blog-item .imi-blog-text .blog-meta a,
							   {{WRAPPER}} .imi-blog-item-2 .imi-blog-meta a,
							   {{WRAPPER}} .news-block_one-author',
				'condition'             => [
					'show_loop_meta_style'    => 'yes',
				]
			]

		);

		//Text Style
		$this->add_control(
			'show_loop_text_style',
			[
				'label'       => __( 'ON/OFF Text Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'layout_control'    => '1'
				]
			]
		);
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-blog-item .imi-blog-text p' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_loop_text_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-blog-item .imi-blog-text p',
				'condition'             => [
					'show_loop_text_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_text_shadow',
				'selector' => '{{WRAPPER}} .imi-blog-item .imi-blog-text p',
				'condition'             => [
					'show_loop_text_style'    => 'yes',
				]
			]
		);
		$this->end_controls_section();

		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'imigrat_tabs_btn' );

			$this->start_controls_tab(
				'imigrat_tab_btn_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a,
							{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more',
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'width: {{SIZE}}{{UNIT}};',
							 '{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more' => 'width: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'height: {{SIZE}}{{UNIT}};',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more' => 'height: {{SIZE}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-btn-1 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],

						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type',
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a,
							{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a,
							{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'btn_title_typography',
						'label' => __('Button Text Typography', 'imigrat'),
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a,
							{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'color: {{VALUE}}',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'imigrat_tab_btn_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a:hover',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more:hover',
					]
				);
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a:hover' => 'border-color: {{VALUE}}',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more:hover' => 'border-color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a:hover' => 'color: {{VALUE}}',
							'{{WRAPPER}} .imi-blog-item-2 .imi-blog-text .read_more:hover' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$date = $settings[ 'date' ];
		$author = $settings[ 'author' ];
		$btn_title = $settings[ 'btn_title' ];
		$layout = $settings[ 'layout_control' ];


		$paged = imigrat_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-imigrat' );
        $args = array(
            'post_type'      => 'post',
            'posts_per_page' => imigrat_set( $settings, 'query_number' ),
            'orderby'        => imigrat_set( $settings, 'query_orderby' ),
            'order'          => imigrat_set( $settings, 'query_order' ),
            'paged'         => $paged
        );
        if( imigrat_set( $settings, 'query_category' ) ) $args['category_name'] = imigrat_set( $settings, 'query_category' );
        $query = new \WP_Query( $args );
		if ( $query->have_posts() ) {
	?>


    <?php if( $layout == 5 ) : ?>
	<section class="news-three"
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"
		<?php endif; ?>
		>
		<div class="container">
			<!-- Sec Title Three -->
			<div class="sec-title-three">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>
					</div>
					<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
					<div class="button-box">
						<a class="btn-style-eight theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
							<div class="btn-wrap">
								<span class="text-one"><?php echo wp_kses($settings['button_text'], true); ?>
								 <i class="fal fa-angle-double-right fa-fw"></i></span>
								<span class="text-two"><?php echo wp_kses($settings['button_text'], true); ?>
								 <i class="fal fa-angle-double-right fa-fw"></i></span>
							</div>
						</a>
					</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="row clearfix">
				<!-- Column -->
				<div class="column col-lg-8 col-md-12 col-sm-12">

					<?php while ( $query->have_posts() ) : $query->the_post();
						$author_image = get_avatar_url( get_the_author_meta( 'ID' ) );

						$category = get_the_category();
						$category_name = $category[0]->cat_name;
						$category_link = get_category_link( $category[0]->cat_ID );

						// limit post 1 item
						if( $query->current_post == 0 ) :

					?>
					<div class="news-block_four">
						<div class="news-block_four-inner d-flex align-items-center">
							<div class="news-block_four-image">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php the_post_thumbnail('imigrat_530x420'); ?>
								</a>
							</div>
							<div class="content">
								<ul class="news-meta">
									<?php if( $category_name ) : ?>
									<li>
										<a href="<?php echo esc_url( $category_link );?>">
											<?php echo esc_html($category_name); ?>
										</a>
									</li>
									<?php endif; ?>
									<li><?php print get_the_date( "M d, Y" ); ?></li>
								</ul>
								<h4><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
								<div class="text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>

								<a class="more" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php if( !empty( $btn_title ) ):?>
										<?php echo wp_kses( $btn_title, true );?>
									<?php else:?>
										<?php esc_html_e('Read More', 'imigrat');?>
									<?php endif;?>
								</a>
							</div>
						</div>
					</div>
					<?php
						endif;
						endwhile;
					?>

					<?php while ( $query->have_posts() ) : $query->the_post();
						$author_image = get_avatar_url( get_the_author_meta( 'ID' ) );

						$category = get_the_category();
						$category_name = $category[0]->cat_name;
						$category_link = get_category_link( $category[0]->cat_ID );

						// limit post 1 item
						if( $query->current_post == 1 ) :

					?>
					<div class="news-block_four style-two">
						<div class="news-block_four-inner d-flex align-items-center">
							<div class="content">
								<ul class="news-meta">
									<?php if( $category_name ) : ?>
									<li>
										<a href="<?php echo esc_url( $category_link );?>">
											<?php echo esc_html($category_name); ?>
										</a>
									</li>
									<?php endif; ?>
									<li><?php print get_the_date( "M d, Y" ); ?></li>
								</ul>
								<h4><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
								<div class="text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>

								<a class="more" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php if( !empty( $btn_title ) ):?>
										<?php echo wp_kses( $btn_title, true );?>
									<?php else:?>
										<?php esc_html_e('Read More', 'imigrat');?>
									<?php endif;?>
								</a>
							</div>
							<div class="news-block_four-image">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php the_post_thumbnail('imigrat_530x420'); ?>
								</a>
							</div>
						</div>
					</div>
					<?php
						endif;
						endwhile;
					?>

				</div>

				<?php while ( $query->have_posts() ) : $query->the_post();
					$author_image = get_avatar_url( get_the_author_meta( 'ID' ) );

					$category = get_the_category();
					$category_name = $category[0]->cat_name;
					$category_link = get_category_link( $category[0]->cat_ID );

					// limit post 1 item
					if( $query->current_post == 2 ) :

				?>
				<div class="column col-lg-4 col-md-12 col-sm-12">
					<div class="news-block_five">
						<div class="news-block_five-inner">
							<div class="news-block_five-image">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php the_post_thumbnail('imigrat_530x420'); ?>
								</a>
							</div>
							<div class="content">
								<ul class="news-meta">
									<?php if( $category_name ) : ?>
									<li>
										<a href="<?php echo esc_url( $category_link );?>">
											<?php echo esc_html($category_name); ?>
										</a>
									</li>
									<?php endif; ?>
									<li><?php print get_the_date( "M d, Y" ); ?></li>
								</ul>
								<h4><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
								<div class="text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>

								<a class="more" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php if( !empty( $btn_title ) ):?>
										<?php echo wp_kses( $btn_title, true );?>
									<?php else:?>
										<?php esc_html_e('Read More', 'imigrat');?>
									<?php endif;?>
								</a>
							</div>
						</div>
					</div>
					<?php
						endif;
						endwhile;
					?>
				</div>
			</div>
		</div>
	</section>
    <?php elseif( $layout == 4 ):?>
	<section class="news-two">
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		<div class="news-two_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"></div>
		<?php endif; ?>
		<div class="container">
			<div class="sec-title-two">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box">

						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>
					</div>

					<?php if(!empty( $settings['title'] )) : ?>
					<div class="text">
						<?php echo wp_kses($settings['text'], true); ?>
					</div>
					<?php endif; ?>

				</div>
			</div>
			<div class="row clearfix">

				<!-- Left Column -->
				<div class="left-column col-lg-6 col-md-12 col-sm-12">
					<?php while ( $query->have_posts() ) : $query->the_post();
						$author_image = get_avatar_url( get_the_author_meta( 'ID' ) );

						$category = get_the_category();
						$category_name = $category[0]->cat_name;
						$category_link = get_category_link( $category[0]->cat_ID );

						// limit post 1 item
						if( $query->current_post == 0 ) :

					?>
					<div class="news-block_two">
						<div class="news-block_two-inner">
							<div class="news-block_two-image">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php the_post_thumbnail('imigrat_530x420'); ?>
								</a>
							</div>
							<div class="news-block_two-content">
								<h4 class="news-block_two-title">
									<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a>
								</h4>
								<div class="lower-box">
									<div class="d-flex justify-content-between align-items-center flex-wrap">
										<div class="news-block_two-author">
											<span><img src="<?php echo esc_url($author_image); ?>" alt="" /></span>
											<?php the_author(); ?>
										</div>
										<?php if( $category_name ) : ?>
										<a class="news-block_three-marketing" href="<?php echo esc_url( $category_link );?>">
											<?php echo esc_html($category_name); ?>
										</a>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
						endif;
						endwhile;
					?>
				</div>
				<!-- Right Column -->
				<div class="right-column col-lg-6 col-md-12 col-sm-12">
					<?php while ( $query->have_posts() ) : $query->the_post();
						$author_image = get_avatar_url( get_the_author_meta( 'ID' ) );

						// get post category name
						$category = get_the_category();
						$category_name = $category[0]->cat_name;
						$category_link = get_category_link( $category[0]->cat_ID );

						if( $query->current_post > 0 ) :
					?>
					<!-- News Block Three -->
					<div class="news-block_three">
						<div class="news-block_three-inner">
							<div class="news-block_three-image">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php the_post_thumbnail('imigrat_530x420'); ?>
								</a>
							</div>
							<div class="news-block_three-content">
								<h5 class="news-block_three-title">
									<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h5>
								<div class="lower-box">
									<div class="d-flex justify-content-between align-items-center flex-wrap">
										<div class="news-block_three-author">
											<span><img src="<?php echo esc_url($author_image); ?>" alt="" /></span>
											<?php the_author(); ?>
										</div>

										<?php if( $category_name ) : ?>
										<a class="news-block_three-marketing" href="<?php echo esc_url( $category_link );?>">
											<?php echo esc_html($category_name); ?>
										</a>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php
						endif;
						endwhile;
					?>
				</div>
			</div>

			<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
			<div class="lower-button-box text-center">
				<a class="btn-style-five theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
					<div class="btn-wrap">
						<span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
						 <i class="fas fa-arrow-circle-right fa-fw"></i></span>
						<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
						 <i class="fas fa-arrow-circle-right fa-fw"></i></span>
					</div>
				</a>
			</div>
			<?php endif; ?>

		</div>
	</section>
    <?php elseif( $layout == 3 ):?>
	<section class="news-one">
		<div class="container">
			<div class="sec-title">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>
					</div>
					<!-- Text -->
					<?php if(!empty( $settings['text'] )) : ?>
					<div class="text">
						<?php echo wp_kses($settings['text'], true); ?>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="row clearfix">
				<?php while ( $query->have_posts() ) : $query->the_post();
					$author_image = get_avatar_url( get_the_author_meta( 'ID' ) );
				?>
				<!-- News One -->
				<div class="news-block_one col-lg-4 col-md-6 col-sm-12">
					<div class="news-block_one-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="news-block_one-image">
							<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
								<?php the_post_thumbnail('imigrat_530x420'); ?>
							</a>
							<div class="news-block_one-date"><span class="far fa-calendar-alt fa-fw"></span>
								<?php print get_the_date( "M d, Y" ); ?>
							</div>
						</div>
						<div class="news-block_one-content">
							<h5 class="news-block_one-heading">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php the_title(); ?>
								</a>
							</h5>
							<div class="news-block_one-text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>
							<div class="lower-box">
								<div class="d-flex justify-content-between">
									<div class="news-block_one-author">
										<span><img src="<?php echo esc_url($author_image); ?>" alt="" /></span>
										<?php the_author(); ?>
									</div>
									<a class="news-block_one-more" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
										<?php if( !empty( $btn_title ) ):?>
											<?php echo wp_kses( $btn_title, true );?>
										<?php else:?>
											<?php esc_html_e('Read More', 'imigrat');?>
										<?php endif;?>
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endwhile; ?>

			</div>
		</div>
	</section>
    <?php elseif( $layout == 2 ):?>
    <section id="imi-blog-2" class="imi-blog-section-2 p-0 m-0">
        <div class="imi-blog-content-2">
            <div class="row justify-content-center">
                <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="500ms" data-wow-duration="1000ms">
                    <div class="imi-blog-item-2">
                        <div class="imi-blog-img-date position-relative">
                            <div class="imi-blog-img">
                                <?php the_post_thumbnail('imigrat_530x420'); ?>
                            </div>
                            <?php if( $date == 'yes' ){?>
                            <div class="imi-blog-date text-center position-absolute">
                                <?php echo esc_html(get_the_date('d')); ?>
                                <span><?php echo esc_html(get_the_date('M,Y')); ?></span>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="imi-blog-text-meta">
                            <div class="imi-blog-meta">
                                <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>">
								<i class="far fa-user"></i> <?php the_author(); ?></a>
                                <a href="<?php echo esc_url(get_permalink(get_the_id()).'#comments'); ?>"><i class="far fa-comments"></i> <?php comments_number( wp_kses(__('0 Comments' , 'imigrat'), true), wp_kses(__('01 Comment' , 'imigrat'), true), wp_kses(__('0% Comments' , 'imigrat'), true)); ?></a>
                            </div>
                            <div class="imi-blog-text headline-2">
                                <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                                <a class="read_more text-uppercase" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
									<?php if( !empty( $btn_title ) ):?>
										<?php echo wp_kses( $btn_title, true );?>
									<?php else:?>
										<?php esc_html_e('Read More', 'imigrat');?>
									<?php endif;?>
									<i class="fal fa-long-arrow-right"></i>
								</a>
                            </div>
                        </div>
                    </div>
                </div>
                 <?php endwhile; ?>
            </div>
        </div>
	</section>

    <?php else: ?>

    <div class="imi-blog-content p-0 m-0">
    	<?php $count = 1; while ( $query->have_posts() ) : $query->the_post(); ?>
        <?php if($count % 2) { ?>
        <div class="imi-blog-item right-align-img position-relative wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="imi-blog-text headline pera-content">
                        <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                        <?php if( $author == 'yes' || $date == 'yes' ){?>
                        <div class="blog-meta">
                            <?php if( $author == 'yes' ){?>
                            <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><i class="fas fa-user"></i> <?php esc_html_e('by', 'imigrat'); ?> <?php the_author(); ?> </a>
                        	<?php };?>
							<?php if( $date == 'yes' ){?>
                            <a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>"><i class="fas fa-calendar-alt"></i> <?php echo esc_attr(get_the_date()); ?></a>
                        	<?php };?>
                        </div>
                        <?php };?>
						<p><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></p>

                        <div class="imi-btn-1 text-uppercase">
                            <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
							<?php if( !empty( $btn_title ) ):?>
								<?php echo wp_kses( $btn_title, true );?>
                            <?php else:?>
                                <?php esc_html_e('Read More', 'imigrat');?>
                            <?php endif;?>
							</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="imi-blog-img">
                        <?php the_post_thumbnail('imigrat_530x420'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php } else { ?>
        <div class="imi-blog-item left-align-img position-relative wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="imi-blog-img">
                        <?php the_post_thumbnail('imigrat_530x420'); ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="imi-blog-text headline pera-content">
                        <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
                        <?php if( $author == 'yes' || $date == 'yes' ){?>
                        <div class="blog-meta">
                            <?php if( $author == 'yes' ){?>
                            <a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta('ID') )); ?>"><i class="fas fa-user"></i> <?php esc_html_e('by', 'imigrat'); ?> <?php the_author(); ?> </a>
                        	<?php };?>
							<?php if( $date == 'yes' ){?>
                            <a href="<?php echo get_month_link(get_the_date('Y'), get_the_date('m')); ?>"><i class="fas fa-calendar-alt"></i> <?php echo esc_attr(get_the_date()); ?></a>
                        	<?php };?>
                        </div>
                        <?php };?>
						<p><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></p>

                        <div class="imi-btn-1 text-uppercase">
                            <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
							<?php if( !empty( $btn_title ) ):?>
								<?php echo wp_kses( $btn_title, true );?>
                            <?php else:?>
                                <?php esc_html_e('Read More', 'imigrat');?>
                            <?php endif;?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    <?php $count++; endwhile; ?>

    <?php endif; ?>
      <?php }
		wp_reset_postdata();
	}
}