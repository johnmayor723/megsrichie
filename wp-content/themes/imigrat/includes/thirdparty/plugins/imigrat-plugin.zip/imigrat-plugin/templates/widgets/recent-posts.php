<?php

$query_string = 'posts_per_page=' . $instance['number'];
if ($instance['cat']) {
    $query_string .= '&cat=' . $instance['cat'];
}
$query = new WP_Query($query_string);

extract($args);
$title = apply_filters('widget_title', $instance['title']);

echo wp_kses_post($before_widget); ?>

<div class="imi-blog-widget">
    <div class="recent-blog-widget">
        <?php echo wp_kses_post($before_title . $title . $after_title); ?>
        <?php 
			global $post;
			while( $query->have_posts() ): $query->the_post(); 
			$post_thumbnail_id = get_post_thumbnail_id($post->ID);
			$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
		?>
        <div class="recent-blog-post-item d-flex align-items-center">
            <div class="blog-img">
                <?php the_post_thumbnail('imigrat_115x78'); ?>
            </div>
            <div class="blog-text headline">
                <h3><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h3>
                <span><?php echo esc_attr(get_the_date()); ?></span>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<?php echo wp_kses_post($after_widget);
