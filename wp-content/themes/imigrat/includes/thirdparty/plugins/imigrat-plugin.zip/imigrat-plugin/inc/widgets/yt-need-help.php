<?php
// Control core classes for avoid errors
//
// Create a widget 1
//
CSF::createWidget('yt_need_help', array(
    'title'       => esc_html__('YT Need Help', 'imigrat-plugin'),
    'classname'   => 'yt-need-help',
    'description' => esc_html__('Show Need Help', 'imigrat-plugins'),
    'fields'      => array(
        array(
            'id'      => 'widget_bg_img2',
            'type'    => 'media',
            'title'   => esc_html__( 'Background Image', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'help_title',
            'type'    => 'text',
            'title'   => esc_html__( 'Title', 'imigrat-plugin'),
            'default'   => esc_html__('Need Help?', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'help_description',
            'type'    => 'textarea',
            'title'   => esc_html__( 'Description', 'imigrat-plugin'),
        ),
        array(
            'id'      => 'help_btn_title',
            'type'    => 'text',
            'title'   => esc_html__( 'Button Title', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'help_btn_link',
            'type'    => 'link',
            'title'   => esc_html__('Button Link'),
            'default' => '#',
        ),
        
    )
));
//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_need_help') ) {
    function yt_need_help($args, $instance) {
        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/need-help.php';
    }
}
