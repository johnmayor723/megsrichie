(function($) {
	
	"use strict";
	var country_carousel_script_js = function($scope, $) {
		
		
		$(document).ready(function () {
			var swiper = new Swiper(".imi-country-list-slider", {
				direction: 'vertical',
				slidesPerView: 3,
				spaceBetween: 30,
				pagination: {
					el: '.swiper-paginations_2',
					clickable: true,
				},
				breakpoints: {
					1500: {
						slidesPerView: 3,
					},
					1199: {
						slidesPerView: 3,
					},
					991: {
						slidesPerView: 3,
					},
					767: {
						slidesPerView: 2,
					},
					575: {
						slidesPerView: 2,
					},
					0: {
						slidesPerView: 1,
					}
				},
			});
		});
		
	};
	
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_country.default', country_carousel_script_js);
    });	

})(window.jQuery);