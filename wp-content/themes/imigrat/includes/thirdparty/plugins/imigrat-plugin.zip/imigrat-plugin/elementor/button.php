<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Button extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_button';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Button', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-button';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'button',
            [
                'label' => esc_html__( 'Imigrat Button', 'imigrat' ),
            ]
        );

		$this->add_control(
			'btn_style',
			[
				'label'   => esc_html__( 'Choose Button Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two', 'imigrat' ),
					'3' => esc_html__( 'Style Three', 'imigrat' ),
					'4' => esc_html__( 'Style Four', 'imigrat' ),
				),
			]
		);

		$this->add_responsive_control(
			'btn_align',
			[
				'label' => esc_html__( 'Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'elementor' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .yt-btn' => 'text-align: {{VALUE}};',
					'{{WRAPPER}} .btn-wrapper' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title Here', 'imigrat' ),
			]
		);

		$this->add_control(
            'btn_link',
			[
				'label' => __( 'Button Url', 'imigrat' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
				'placeholder' => __( 'https://your-link.com', 'imigrat' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
            'show_icon',
            [
                'label'        => esc_html__( 'Show Icon', 'imigrat' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'imigrat' ),
                'label_off'    => esc_html__( 'Off', 'imigrat' ),
                'return_value' => 'yes',
                'default'      => 'no',
				'condition' => [
					'btn_style'      => '2',
				],
            ]
        );

		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Enter The icons', 'imigrat'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-arrow-right',
					'library' => 'solid',
				],
				'condition'   => [ 'show_icon' => 'yes' ]
			]

		);

		$this->end_controls_section();

		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'imigrat_tabs_btn' );

			$this->start_controls_tab(
				'imigrat_tab_btn_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a',
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'width: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'height: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-btn-1 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],

						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type',
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'btn_title_typography',
						'label' => __('Button Text Typography', 'imigrat'),
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'imigrat_tab_btn_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-btn-1 a:hover',
					]
				);
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a:hover' => 'border-color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-btn-1 a:hover' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$icon = $settings[ 'icon' ];
		$btn_style = $settings[ 'btn_style' ];

		if ( ! empty( $settings['btn_link']['url'] ) ) {
			$this->add_link_attributes( 'link', $settings['btn_link'] );
		}
	?>

    <?php if( $btn_style == '4' ): ?>
	<div class="btn-wrapper">
		<a class="btn-style-five theme-btn" <?php echo $this->get_render_attribute_string( 'link' ); ?>>
			<div class="btn-wrap">
				<span class="text-one"><?php echo wp_kses($settings['btn_title'], true);?>
				<?php if( $settings[ 'show_icon' ] === 'yes' ):?>
					<?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
				<?php else:?>
					<i class="fal fa-long-arrow-right"></i>
				<?php endif;?>
				</span>
				<span class="text-two"><?php echo wp_kses($settings['btn_title'], true);?>
				<?php if( $settings[ 'show_icon' ] === 'yes' ):?>
					<?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
				<?php else:?>
					<i class="fal fa-long-arrow-right"></i>
				<?php endif;?>
				</span>
			</div>
		</a>
	</div>
    <?php elseif( $btn_style == '3' ): ?>

    <div class="imi-btn-2">
        <a <?php echo $this->get_render_attribute_string( 'link' ); ?>>

        <?php echo wp_kses($settings['btn_title'], true);?>
		<?php if( $settings[ 'show_icon' ] === 'yes' ):?>
            <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
        <?php else:?>
            <i class="fal fa-long-arrow-right"></i>
        <?php endif;?>
        </a>

    </div>

	<?php elseif( $btn_style == '2' ): ?>

    <div class="imi-btn-1 text-uppercase wow fadeInUp" data-wow-delay="500ms" data-wow-duration="1500ms">
        <a  <?php echo $this->get_render_attribute_string( 'link' ); ?>>
			<?php echo wp_kses($settings['btn_title'], true);?>
			<?php if( $settings[ 'show_icon' ] === 'yes' ):?>
                <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
            <?php else:?>
                <i class="fas fa-cloud-download"></i>
            <?php endif;?>
        </a>
    </div>

    <?php else:?>

    <div class="imi-btn-1 text-uppercase yt-btn">
        <a <?php echo $this->get_render_attribute_string( 'link' ); ?>><?php echo wp_kses($settings['btn_title'], true);?></a>
    </div>

    <?php endif;
    }
}