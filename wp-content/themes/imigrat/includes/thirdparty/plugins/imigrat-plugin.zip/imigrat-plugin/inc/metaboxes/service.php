<?php

//
// Set a unique slug-like ID
$prefix = 'imigrat_meta_service';

//
// Create a metabox
CSF::createMetabox( $prefix, array(
	'title'      	=> 'Imigrat Service Setting',
	'icon'       	=> 'el el-cogs',
	'position'   	=> 'normal',
	'priority'   	=> 'core',
	'post_type' 	=> array( 'service' ),
	'show_restore'       => false,
	'context'            => 'advanced',
	'nav'                => 'normal',
	'theme'              => 'dark',
	'class'              => '',
) );

//
// Create a section
CSF::createSection($prefix, array(
	'fields' => array(
		array(
			'id'       => 'service_icon_img',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__('Choose Icon Image', 'imigrat-plugin'),
			'default'  => '',
		),
		
		//Feature Box Section
		array(
			'id' => 'show_feature_box',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Feature Box', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Feature Box', 'imigrat-plugin'),
			'default'  => false,
		),
		//Feature Box Info 
		array(
			'id'    => 'servce_features',
			'type'  => 'group',
			'title' => esc_html__( 'Feature Box Information', 'imigrat-plugin' ),
			'dependency' => array( 'show_feature_box', '==', true ),
			'fields'	=> array(
				array(
					'id'       => 'service_feature_image',
					'type'     => 'media',
					'url'      => true,
					'title'    => esc_html__('Choose feature Image', 'imigrat-plugin'),
					'default'  => '',
				),
				array(
					'id'       => 'service_feature_title',
					'type'     => 'text',
					'title'    => esc_html__( 'Title', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Title', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'service_feature_description',
					'type'     => 'textarea',
					'title'    => esc_html__( 'Description', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Description', 'imigrat-plugin' ),
				),
			),
		),
		
		array(
			'id'    => 'service_sub_content',
			'type'  => 'textarea',
			'title' => esc_html__( 'Description/Raw HTML', 'imigrat-plugin' ),
		),
		
		//Video Section
		array(
			'id' => 'show_video_box',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Video Box Information', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Video Box Information', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'       => 'service_video_image',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__('Choose Video Image', 'imigrat-plugin'),
			'dependency' => array( 'show_video_box', '==', true ),
			'default'  => '',
		),
		array(
			'id'    => 'service_video_link',
			'type'  => 'text',
			'title' => esc_html__( 'Video URL', 'imigrat-plugin' ),
			'dependency' => array( 'show_video_box', '==', true ),
		),
		array(
			'id'    => 'service_feature_list_title',
			'type'  => 'text',
			'title' => esc_html__( 'Feature List Heading', 'imigrat-plugin' ),
			'dependency' => array('show_video_box', '==', true),
		),
		array(
			'id'    => 'service_feature_list_description',
			'type'  => 'textarea',
			'title' => esc_html__( 'Feature List Description', 'imigrat-plugin' ),
			'dependency' => array('show_video_box', '==', true),
		),
		array(
			'id'    => 'service_feature_list',
			'type'  => 'textarea',
			'title' => esc_html__( 'Feature List', 'imigrat-plugin' ),
			'dependency' => array('show_video_box', '==', true),
		),
		
		//Sub Heading
		array(
			'id'    => 'service_sub_heading',
			'type'  => 'text',
			'title' => esc_html__( 'Accordion Main Heading', 'imigrat-plugin' ),
		),
		array(
			'id'    => 'service_sub_deacription',
			'type'  => 'textarea',
			'title' => esc_html__( 'Description', 'imigrat-plugin' ),
		),
		
		//Accordion Section
		array(
			'id' => 'show_accordion_box',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Accordion Information', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Accordion Information', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'    => 'servce_accordion_box',
			'type'  => 'group',
			'title' => esc_html__( 'Accordion Information', 'imigrat-plugin' ),
			'dependency' => array('show_accordion_box', '==', true),
			'fields'	=> array(
				array(
					'id'    => 'service_accordion_title',
					'type'  => 'text',
					'title' => esc_html__( 'Accordion Title', 'imigrat-plugin' ),
				),
				array(
					'id'    => 'service_accordion_description',
					'type'  => 'textarea',
					'title' => esc_html__( 'Accordion Description', 'imigrat-plugin' ),
				),
			)
		),
		
	)
));