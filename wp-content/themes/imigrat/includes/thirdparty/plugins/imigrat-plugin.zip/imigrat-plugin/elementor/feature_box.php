<?php

namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class feature_box extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_feature_box';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Feature Box', 'imigrat' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tools';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'feature_box',
			[
				'label' => esc_html__( 'Imigrat Feature Box', 'imigrat' ),
			]
		);
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
				),
			]
		);

		$this->add_control(
			'feature_image',
			[
			  	'label' => __( 'Feature Image1', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2']
				],
			]
	    );
		$this->add_control(
			'shape_image1',
			[
			  	'label' => __( 'Shape Image1', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2']
				],
			]
	    );
		$this->add_control(
			'shape_image2',
			[
			  	'label' => __( 'Shape Image2', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => '1',
				],
				
			]
	    );
		$this->add_control(
			'icon_image',
			[
			  	'label' => __( 'Icon Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => '2',
				],
			]
	    );
		$this->add_control(		
			 'title',
			[
				'label'       => __( 'Title', 'imigrat' ),				
                'type'        => Controls_Manager::TEXT,
				'label_block' => true,				
				'dynamic'     => [				
					'active' => true,
				],				
				'placeholder' => __( 'Enter your title', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1','2']
				],
			]
		);
		$this->add_control(		
			 'text',
			[
				'label'       => __( 'Text', 'imigrat' ),				
                'type'        => Controls_Manager::TEXT,
				'label_block' => true,				
				'dynamic'     => [				
					'active' => true,
				],				
				'placeholder' => __( 'Enter your Text', 'imigrat' ),
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);
		$this->add_control(
            'title_link',
			[
				'label' => __( 'Title Url', 'imigrat' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
					'layout_control'      => '1'
				],
			]
		);
		$this->add_control(		
			 'button_title',
			[
				'label'       => __( 'Button Title', 'imigrat' ),				
                'type'        => Controls_Manager::TEXT,
				'label_block' => true,				
				'dynamic'     => [				
					'active' => true,
				],				
				'placeholder' => __( 'Enter your Button Title', 'imigrat' ),
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);	
		$this->add_control(
            'button_link',
			[
				'label' => __( 'Button Url', 'imigrat' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);	
		
		$this->add_control(		
			 'designation',
			[
				'label'       => __( 'Designation', 'imigrat' ),				
                'type'        => Controls_Manager::TEXT,
				'label_block' => true,				
				'dynamic'     => [				
					'active' => true,
				],				
				'placeholder' => __( 'Enter your Designation', 'imigrat' ),
				'condition' => [
					'layout_control'      => '1',
				],
				
			]
		);
		$this->add_control(
            'designation_link',
			[
				'label' => __( 'Designation Url', 'imigrat' ),
				'type' => Controls_Manager::URL,
				'label_block' => true, 
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
					'layout_control'      => '1',
				],
			]
		);	
		$this->end_controls_section();
		
		/************************************************************************
								Tab Style Start
		*************************************************************************/
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-benifit-service-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-feature-item-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-benifit-service-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-feature-item-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-benifit-service-item
							   {{WRAPPER}} .imi-feature-item-2
								',				
			]
		);
		$this->end_controls_section();
		
		/**Title Style**/
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__('Title Style Settings', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'show_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' => 
                    '{{WRAPPER}} .imi-benifit-service-item .imi-benifit-service-text h3,
					 {{WRAPPER}} .imi-feature-item-2 .imi-feature-hover-item .feature-title h3,
					 {{WRAPPER}} .imi-feature-item-2 .imi-feature-text .feature-title h3
					',     
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-benifit-service-item .imi-benifit-service-text h3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-feature-item-2 .imi-feature-hover-item .feature-title h3 a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-feature-item-2 .imi-feature-text .feature-title h3' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'title_hover_color',
            [
                'label' => __('Title Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-benifit-service-item .imi-benifit-service-text h3:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-feature-item-2 .imi-feature-hover-item .feature-title h3:hover a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
		
		/**Desgination Style**/
		$this->start_controls_section(
			'designation_style',
			[
				'label' => esc_html__('Designation Style Settings', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => '1',
				],
			]
		);
		$this->add_control(
			'show_designation_style',
			[
				'label'       => __( 'ON/OFF  Designation Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [
					'layout_control'      => '1',
				],
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'designation_typography',
                'label' => __('Designation Typography', 'imigrat'),
                'selector' => 
                    '{{WRAPPER}} .imi-benifit-service-item .imi-benifit-service-text span',               
                'separator' => 'before',
				'condition'             => [
					'show_designation_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'designation_color',
            [
                'label' => __('designation Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-benifit-service-item .imi-benifit-service-text span' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_designation_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
		/**Content Style**/
		$this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__('Content Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);
		$this->add_control(
			'show_content_style',
			[
				'label'       => __( 'ON/OFF  Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __('Content Typography', 'imigrat'),
                'selector' => 
                    '{{WRAPPER}} .imi-feature-item-2 .imi-feature-hover-item .feature-dec-text p',               
                'separator' => 'before',
				'condition'             => [
					'show_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'content_color',
            [
                'label' => __('Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-feature-item-2 .imi-feature-hover-item .feature-dec-text p' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_content_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
		
		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);
		$this->start_controls_tabs( 'imigrat_tabs_btn' );
		
			$this->start_controls_tab(
				'imigrat_tab_btn_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .read-more-btn',				
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .read-more-btn' => 'width: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .read-more-btn' => 'height: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .read-more-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],
						
						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type',
						'selector' => 
							'{{WRAPPER}} .read-more-btn',				
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' => 
							'{{WRAPPER}} .read-more-btn',				
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .read-more-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'btn_title_typography',
						'label' => __('Button Text Typography', 'imigrat'),
						'selector' => 
							'{{WRAPPER}} .read-more-btn',				
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .read-more-btn' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'imigrat_tab_btn_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);
			
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => 
							'{{WRAPPER}} .read-more-btn:hover',				
					]
				);
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .read-more-btn:hover' => 'border-color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .read-more-btn:hover' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
			
			$this->end_controls_tab();
			
		$this->end_controls_tabs();   
		$this->end_controls_section();
	}
	

	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
	
	?>
    
    <?php if($layout == 2 ):?>
    
    <div class="imi-feature-item-2 position-relative">
        <span class="imi-feature-shape position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
        <div class="imi-feature-hover-item position-absolute">
            <div class="feature-icon-title d-flex align-items-center">
                <div class="feature-icon">
                    <img src="<?php echo esc_url(wp_get_attachment_url($settings['icon_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
                </div>
                <?php if($settings['title']) { ?>
                <div class="feature-title headline-2">
                    <h3><a href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo wp_kses($settings['title'], true); ?></a></h3>
                </div> 
                <?php } ?>
            </div>
            <div class="feature-dec-text pera-content">
                <p><?php echo wp_kses($settings['text'], true); ?></p>
                <a class="read-more-btn text-uppercase" href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo wp_kses($settings['button_title'], true); ?> <i class="fal fa-long-arrow-right"></i></a>
            </div>
        </div>
        <div class="imi-feature-img">
            <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
        </div>
        <div class="imi-feature-text position-absolute">
            <div class="feature-icon">
                <img src="<?php echo esc_url(wp_get_attachment_url($settings['icon_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
            </div>
            <?php if($settings['title']) { ?>
            <div class="feature-title headline-2">
                <h3><?php echo wp_kses($settings['title'], true); ?></h3>
            </div>
            <?php } ?>
        </div>
    </div>
    
    <?php else: ?>
    
    <div class="imi-benifit-service-item position-relative">
        <span class="imi-benifit-ser-shape position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
        <span class="imi-benifit-ser-shape2 position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
        <div class="imi-benifit-arrow position-absolute">
            <a href="<?php echo esc_url($settings['designation_link']['url']);?>"><i class="fas fa-long-arrow-right"></i></a>
        </div>
        <div class="imi-benifit-service-img">
            <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
        </div>
        <div class="imi-benifit-service-text headline">
            <?php if($settings['title']) { ?><h3><a href="<?php echo esc_url($settings['title_link']['url']);?>"><?php echo wp_kses($settings['title'], true); ?></a></h3><?php } ?>
            <?php if($settings['designation']) { ?><span class="imi-bn-category text-uppercase"><a href="<?php echo esc_url($settings['designation_link']['url']);?>"> <?php echo wp_kses($settings['designation'], true); ?></a></span><?php } ?>
        </div>
    </div>
    
	<?php endif;

	}
}