<?php

// Control core classes for avoid errors


//
// Create a widget 1
//
CSF::createWidget('yt_about_company_4', array(
    'title'       => esc_html__('YT About Company 4', 'imigrat-plugin'),
    'classname'   => 'yt-about-company-4',
    'description' => esc_html__('Show about the company', 'imigrat-plugins'),
    'fields'      => array(
        array(
            'id'      => 'widget_logo_img',
            'type'    => 'media',
            'title'   => esc_html__( 'Logo', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'content2',
            'type'    => 'textarea',
            'title'   => esc_html__( 'Content', 'imigrat-plugin'),
        ),
	)
));

//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_about_company_4') ) {
    function yt_about_company_4($args, $instance) {

        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/about-company-4.php';
    }
}
