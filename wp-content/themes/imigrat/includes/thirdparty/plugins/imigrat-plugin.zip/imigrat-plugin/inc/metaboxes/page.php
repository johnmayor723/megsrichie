<?php
//
// Set a unique slug-like ID
$prefix = 'imigrat_meta';
//
// Create a metabox
CSF::createMetabox( $prefix, array(
	'title'      => 'Imigrat Setting',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_type' => array( 'page', 'post', 'team', 'product', 'service', 'project', 'visa','country', 'jobs' ),
	'show_restore'       => false,
	'context'            => 'advanced',
	'nav'                => 'normal',
	'theme'              => 'dark',
	'class'              => '',
) );
require IMIGRATPLUGIN_PLUGIN_PATH . '/inc/metaboxes/header.php';
require IMIGRATPLUGIN_PLUGIN_PATH . '/inc/metaboxes/banner.php';
require IMIGRATPLUGIN_PLUGIN_PATH . '/inc/metaboxes/sidebar.php';
require IMIGRATPLUGIN_PLUGIN_PATH . '/inc/metaboxes/footer.php';
