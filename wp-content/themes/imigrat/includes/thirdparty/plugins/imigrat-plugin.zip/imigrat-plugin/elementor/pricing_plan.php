<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Pricing_Plan extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_pricing_plan';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Pricing Plan', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'pricing_plan',
            [
                'label' => esc_html__( 'Pricing Plan', 'imigrat' ),
            ]
        );

		// actvie
		$this->add_control(
			'active',
			[
				'label' => __( 'Active', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'imigrat' ),
				'label_off' => __( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Enter your Title', 'imigrat' ),

			]
		);
		$this->add_control(
			'shape_image',
			[
				'label' => esc_html__('Shape Image', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'price',
			[
				'label' => esc_html__( 'Price', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Price', 'imigrat' ),
				'default' => esc_html__( '$542.00', 'imigrat' ),

			]
		);
		$this->add_control(
			'price_designation',
			[
				'label' => esc_html__( 'Price Designation', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Price Designation', 'imigrat' ),
				'default' => esc_html__( '/visa', 'imigrat' ),

			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'For most businesses that want to optiimize web queries', 'imigrat' ),
				'condition' => [
					'style' => 'style1',
				],

			]
		);
		$this->add_control(
			'features_list',
			[
				'label' => esc_html__('Feature List', 'imigrat'),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'imigrat' ),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title Here', 'imigrat' ),
			]
		);
		$this->add_control(
            'btn_link',
			[
				'label' => __( 'External Url', 'imigrat' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->end_controls_section();


	/************************************************************************
								Tab Style Start
	*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item',
			]
		);
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'btn_border_type',
                'selector' =>
					'{{WRAPPER}} .imi-pricing-feed-item',
				'separator' => 'before',
			]
        );
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .price-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .price-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .price-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-pricing-feed-item .price-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .price-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .price-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .price-title',
			]
		);
		$this->end_controls_section();

		//Price Style
		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'price__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'price_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'price_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3',
			]
		);

		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'price_text_stroke',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'price_text_shadow',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3',
			]
		);
		$this->end_controls_section();

		//Price Designation Style
		$this->start_controls_section(
			'price_designation_style',
			[
				'label' => esc_html__( 'Price Designation', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'price_designation__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'price_designation_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'price_designation_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span',
			]
		);

		$this->add_control(
			'price_designation_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_designation_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'price_designation_text_stroke',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'price_designation_text_shadow',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text h3 span',
			]
		);
		$this->end_controls_section();

		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-value-text p',
			]
		);
		$this->end_controls_section();


		//Feature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-list-area li',
			]
		);
		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-pricing-feed-item .imi-price-list-area li' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_shadow',
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-list-area li',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_border_bgtype',
				'label' => __( 'Border BG Color', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-pricing-feed-item .imi-price-list-area li:before',
			]
		);
		$this->end_controls_section();

		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'imigrat_tabs_btn' );

			$this->start_controls_tab(
				'imigrat_tab_btn_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a',
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a' => 'width: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a' => 'height: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],

						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type2',
						'selector' =>
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' =>
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],
					]
				);
				$this->add_group_control(
					Group_Control_Typography::get_type(),
					[
						'name' => 'btn_title_typography',
						'label' => __('Button Text Typography', 'imigrat'),
						'selector' =>
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'imigrat_tab_btn_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a:hover',
					]
				);
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a:hover' => 'border-color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-pricing-feed-item .imi-price-btn a:hover' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if($settings['style'] == 'style2' ) : ?>
	<div class="price-block_one <?php if($settings['active']) {echo 'active';} ?>">
		<div class="price-block_one-inner"
			<?php if(!empty( $settings['shape_image']['id'] )) : ?>
			style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>)"
			<?php endif; ?>
			>
			<div class="price-block_one-title">
				<?php if($settings['title']){ ?>
				<h4><?php echo wp_kses($settings['title'], true); ?></h4>
				<?php } ?>
				<div class="price"><?php echo wp_kses($settings['price'], true); ?>
				<span>
					<?php echo wp_kses($settings['price_designation'], true); ?></span>
				</div>
			</div>
			<div class="price-block_one-content">
				<?php $features_list = $settings['features_list'];
					if(!empty($features_list)){
					$features_list = explode("\n", ($features_list));
				?>
				<ul class="price-block_one-list">
					<?php foreach($features_list as $features): ?>
                    <li><?php echo wp_kses($features, true); ?></li>
                    <?php endforeach; ?>
				</ul>
				<?php } ?>
				<?php if($settings['btn_link']['url'] || $settings['btn_title']){ ?>
				<div class="button-box text-center">
					<a class="start-btn theme-btn" href="<?php echo esc_url($settings['btn_link']['url']); ?>">
					<?php echo wp_kses($settings['btn_title'], true); ?>
						<i class="fal fa-angle-double-right fa-fw"></i>
					</a>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>
	<?php else : ?>
	<section class="imi-pricing-feed-section inner-page-padding p-0 m-0">

        <div class="imi-pricing-feed-item text-center">
            <?php if($settings['title']){ ?>
            <div class="price-title">
                <?php echo wp_kses($settings['title'], true); ?>
            </div>
            <?php } ?>

            <div class="imi-price-value-text headline pera-content" <?php if($settings['shape_image']['id']){ ?>data-background="<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>"<?php } ?>>
                <h3><?php echo wp_kses($settings['price'], true); ?>
					<span>
						<?php echo wp_kses($settings['price_designation'], true); ?>
					</span>
				</h3>
                <p><?php echo wp_kses($settings['text'], true); ?></p>
            </div>

            <?php $features_list = $settings['features_list'];
                if(!empty($features_list)){
                $features_list = explode("\n", ($features_list));
            ?>
            <div class="imi-price-list-area ul-li-block">
                <ul>
                    <?php foreach($features_list as $features): ?>
                    <li><?php echo wp_kses($features, true); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php } ?>

            <?php if($settings['btn_link']['url'] || $settings['btn_title']){ ?>
            <div class="imi-price-btn">
                <a href="<?php echo esc_url($settings['btn_link']['url']); ?>"><?php echo wp_kses($settings['btn_title'], true); ?> <i class="fal fa-long-arrow-right"></i></a>
            </div>
            <?php } ?>
        </div>

    </section>
    <?php
		endif;
    }
}