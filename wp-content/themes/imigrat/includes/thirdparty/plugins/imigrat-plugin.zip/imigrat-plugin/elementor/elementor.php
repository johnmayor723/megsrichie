<?php
namespace IMIGRATPLUGIN\Element;
class Elementor {
	static $widgets = array(
		//Home Page
		'banner_1',
		'why_choose_us',
		'case_study',
		'social_links',
		'client_section',
		'hero_title',
		'feature_list_widget',
		'feature_box',
		'form',
		'button',
		'video_icon',
		'call_to_action',
		'services_carousel',
		'feature_tab',
		'icon_box',
		'phone_info',
		'testimonials',
		'experiance_section',
		'float_image',
		'author_info',
		'funfacts',
		'blog_grid',
		'skill_bar',
		'services_grid',
		'visa_carousel',
		'shape_images',
		'country',
		'team_grid',
		'about_us',
		'pricing_plan',
		'faqs',
		'testimonials_grid',
		'country_grid',
		'visa_grid',
		'jobs_grid',
		'portfolio'
	);
	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}
	static function loader() {
		foreach ( self::$widgets as $widget ) {
			$file = IMIGRATPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}
			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}
	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\IMIGRATPLUGIN\\Element\\' . ucwords( $widget );
			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}
	static function register_cats( $elements_manager ) {
		$elements_manager->add_category(
			'imigrat',
			[
				'title' => esc_html__( 'imigrat', 'imigrat' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'templatepath',
			[
				'title' => esc_html__( 'Template Path', 'imigrat' ),
				'icon'  => 'fa fa-plug',
			]
		);
	}
}
Elementor::init();