<?php
namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Call_To_Action extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_call_to_action';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Call To Action', 'imigrat' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-library-open';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat'),
				),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'call_to_action',
			[
				'label' => esc_html__( 'Call To Action', 'imigrat' ),
			]
		);

		$this->add_control(
			'cta_bg_image',
			[
			  	'label' => __( 'BG Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control' => ['2','3'],
				]
			]
	    );
		$this->add_control(
			'feature_image',
			[
			  	'label' => __( 'Feature Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2']
				]
			]
	    );
		$this->add_control(
			'animation_image',
			[
			  	'label' => __( 'Animation Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2']
				]
			]
	    );
		$this->add_control(
			'animation_image2',
			[
			  	'label' => __( 'Animation Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2']
				]
			]
	    );
		$this->add_control(
			 'sub_title',
			[
				'label'       => __( 'Sub Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1','2']
				]
			]
		);
		$this->add_control(
			 'title',
			[
				'label'       => __( 'Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1','2','3']
				]
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title Here', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1','2','3']
				]
			]
		);
		$this->add_control(
            'btn_link',
			[
				'label' => __( 'External Url', 'imigrat' ),
				'type' => Controls_Manager::URL,
				'label_block' => true,
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
					'layout_control'      => ['1','2','3']
				]
			]
		);
		$this->add_control(
			'phone_title',
			[
				'label'       => __( 'Phone Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Phone Title Here', 'imigrat' ),
				'condition' => [
					'layout_control'      => '1',
				]
			]
		);
		$this->add_control(
			'phone_no',
			[
				'label'       => __( 'Phone No', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Phone No Here', 'imigrat' ),
				'condition' => [
					'layout_control'      => '1',
				]
			]
		);
		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'GENERAL SETTING', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-work-process-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-2-footer-cta-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-work-process-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-2-footer-cta-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
						{{WRAPPER}} .imi-work-process-section:before,
						{{WRAPPER}} .imi-work-process-contnet',
			]
		);
		$this->end_controls_section();

		/**Sub Title Style**/
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__('SUB TITLE STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '1'
				]
			]
		);
		$this->add_control(
			'show_sub_title_style',
			[
				'label'       => __( 'ON/OFF Sub Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'sub_title_typography',
                'label' => __('Sub Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-text .imi-section-title-1 .sub-title',
                'separator' => 'before',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'sub_title_color',
            [
                'label' => __('Sub Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-text .imi-section-title-1 .sub-title' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		/**Title Style**/
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__('TITLE STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'show_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-section-title-1 h2,
					 {{WRAPPER}} .imi-section-title-2 h2',
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-text .imi-section-title-1 .sub-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();


		/**Content Style**/
		$this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__('CONTENT STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '2'
				]
			]
		);
		$this->add_control(
			'show_content_style',
			[
				'label'       => __( 'ON/OFF Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __('Content Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-2-footer-cta-content .imi-section-title-2 p',
                'separator' => 'before',
				'condition'             => [
					'show_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'content_color',
            [
                'label' => __('Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-2-footer-cta-content .imi-section-title-2 p' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_content_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		/**Button Style One**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('BUTTON STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'show_btn_style',
			[
				'label'       => __( 'ON/OFF Button Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'yt_btn_background',
			[
				'label'                 => __( 'Button Background', 'imigrat' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_bgtype',
				'label' => __( 'Button Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' =>
					'{{WRAPPER}} .imi-btn-1 a,
					 {{WRAPPER}} .imi-btn-2 a
					',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'hover_background',
			[
				'label'                 => __( 'Button Hover Background', 'imigrat' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_hover_bg_bgtype',
				'label' => __( 'Button Hover Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' =>
					'{{WRAPPER}} .imi-btn-1 a:hover:before,
					 {{WRAPPER}} .imi-btn-2 a:hover:before
					',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'show_border_radius',
			[
				'label'       => __( 'ON/OFF Button Radius Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_control(
            'btn_border_radius',
            [
                'label' => esc_html__('Border Radius', 'imigrat'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .imi-btn-1 a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-btn-2 a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
				'condition'             => [
					'show_border_radius'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_border_type',
			[
				'label'       => __( 'ON/OFF Border Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'btn_border_type',
                'selector' =>
					'{{WRAPPER}} .imi-btn-1 a,
					 {{WRAPPER}} .imi-btn-2 a
					',
				'separator' => 'before',
				'condition'             => [
					'show_border_type'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'btn_border_hover_color',
            [
                'label' => __('Button Border Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-btn-1 a:hover' => 'border-color: {{VALUE}}!important',
					'{{WRAPPER}} .imi-btn-2 a:hover' => 'border-color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_border_type'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_box_shadow',
			[
				'label'       => __( 'ON/OFF Box Shadow Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'border_box_shadow',
                'selector' =>
					'{{WRAPPER}} .imi-btn-1 a,
					 {{WRAPPER}} .imi-btn-2 a',
				'separator' => 'before',
				'condition'             => [
					'show_box_shadow'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_btn_padding',
			[
				'label'       => __( 'ON/OFF Padding Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_responsive_control(
            'btn_padding',
            [
                'label'              => __( 'Padding', 'imigrat' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .imi-btn-1 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-btn-2 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],

                'frontend_available' => true,
				'condition'             => [
					'show_btn_padding'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_typo_color',
			[
				'label'       => __( 'ON/OFF Typography and Color Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_title_typography',
                'label' => __('Button Text Typography', 'imigrat'),
                'selector' =>
					'{{WRAPPER}} .imi-btn-1 a,
					 {{WRAPPER}} .imi-btn-2 a',
                'separator' => 'before',
				'condition'             => [
					'show_typo_color'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'btn_title_color',
            [
                'label' => __('Button Text Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-btn-1 a' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .imi-btn-2 a' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_typo_color'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'btn_title_hover_color',
            [
                'label' => __('Button Text Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-btn-1 a:hover' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .imi-btn-2 a:hover' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_typo_color'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();


		/**Phone Info Style**/
		$this->start_controls_section(
			'phone_info_style',
			[
				'label' => esc_html__('PHONE INFO STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '1'
				]
			]
		);
		//Icon Color
		$this->add_control(
			'show_phone_icon_style',
			[
				'label'       => __( 'ON/OFF Phone Icon Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'phone_icon_color',
            [
                'label' => __('Phone Icon Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-btn-grp .imi-work-process-cta .inner-icon i' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_phone_icon_style'    => 'yes',
				]
            ]
        );
		//Phone TItle
		$this->add_control(
			'show_phone_title_style',
			[
				'label'       => __( 'ON/OFF Phone Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'phone_title_typography',
                'label' => __('Phone Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-btn-grp .imi-work-process-cta .inner-text span',
                'separator' => 'before',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'phone_title_color',
            [
                'label' => __('Phone Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-btn-grp .imi-work-process-cta .inner-text span' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
            ]
        );
		//Phone No Style
		$this->add_control(
			'show_phone_no_style',
			[
				'label'       => __( 'ON/OFF Phone No Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'phone_no_typography',
                'label' => __('Phone No Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-btn-grp .imi-work-process-cta .inner-text h3',
                'separator' => 'before',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'phone_no_color',
            [
                'label' => __('Phone No Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-work-process-contnet .imi-work-process-btn-grp .imi-work-process-cta .inner-text h3' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
	}
	/**
	 * Render button widget output on the frontend.
	* Written in PHP and used to generate the final HTML.
	*
	* @since  1.0.0
	* @access protected
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
	?>

    <?php if( $layout == 3 ):?>
	<section class="cta-one"
		<?php if(!empty( $settings['cta_bg_image']['id'] )) : ?>
		style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['cta_bg_image']['id'])); ?>)"
		<?php endif; ?>
		>
		<div class="container">
			<div class="d-flex align-items-center justify-content-between flex-wrap">
				<h3><?php echo wp_kses($settings['title'], true); ?></h3>
				<!-- Button Box -->
				<div class="button-box">
					<a class="btn-style-three theme-btn" href="<?php echo esc_url($settings['btn_link']['url']);?>">
						<div class="btn-wrap">
							<span class="text-one">
								<?php echo wp_kses($settings['btn_title'], true);?>
								<i><img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-1.png" alt="" /></i></span>
							<span class="text-two">
								<?php echo wp_kses($settings['btn_title'], true);?>
								<i><img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" /></i></span>
						</div>
					</a>
				</div>
			</div>
		</div>
	</section>
    <?php elseif( $layout == 2 ):?>

    <section id="imi-2-footer-cta" class="imi-2-footer-cta-section position-relative">
		<div class="container">
			<div class="imi-2-footer-cta-content position-relative" data-background="<?php echo esc_url(wp_get_attachment_url($settings['cta_bg_image']['id'])); ?>">
				<span class="imi-2-cta-img position-absolute wow slideInRight" data-wow-delay="200ms" data-wow-duration="1500ms"><img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
				<div class="imi-2-cta-text-area-wrap">
					<div class="imi-testimonial-shape1 position-absolute">
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['animation_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
					</div>
					<div class="imi-testimonial-shape2 position-absolute">
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['animation_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
					</div>
					<div class="imi-section-title-2 headline-2 pera-content position-relative">
						<h2><?php echo wp_kses($settings['sub_title'], true); ?></h2>
						<p><?php echo wp_kses($settings['title'], true); ?></p>
					</div>
					<div class="imi-btn-2 text-uppercase">
						<a href="<?php echo esc_url($settings['btn_link']['url']);?>"><?php echo wp_kses($settings['btn_title'], true);?> <i class="fal fa-long-arrow-right"></i></a>
					</div>
				</div>
			</div>
		</div>
	</section>

    <?php else: ?>
    <!-- Start of Work Process section
	============================================= -->
	<section id="imi-work-process" class="imi-work-process-section position-relative p-0 m-0">
		<div class="container">
			<div class="imi-work-process-contnet position-relative">
				<div class="imi-work-process-img position-absolute  wow fadeInRight" data-wow-delay="600ms" data-wow-duration="1500ms">
					<img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
					<div class="imi-work-process-badge position-absolute">
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['animation_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
					</div>
				</div>
				<div class="imi-work-process-text">
					<div class="imi-section-title-1 pera-content headline  wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                    	<?php if($settings['sub_title']) { ?>
						<div class="sub-title text-uppercase position-relative">
							<?php echo wp_kses($settings['sub_title'], true); ?>
						</div>
                        <?php } ?>
						<h2>
							<span><?php echo wp_kses($settings['title'], true); ?></span>
						</h2>
					</div>
					<div class="imi-work-process-btn-grp d-flex align-items-center  wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
						<div class="imi-btn-1 text-uppercase">
							<a href="<?php echo esc_url($settings['btn_link']['url']);?>"><?php echo wp_kses($settings['btn_title'], true);?></a>
						</div>
						<div class="imi-work-process-cta d-flex align-items-center">
							<div class="inner-icon">
								<i class="fas fa-phone-alt"></i>
							</div>
							<div class="inner-text headline">
								<span><?php echo wp_kses($settings['phone_title'], true); ?></span>
								<h3><?php echo wp_kses($settings['phone_no'], true); ?></h3>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Work Process section
	============================================= -->

	<?php endif;
	}
}