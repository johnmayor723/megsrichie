<?php



$query_string = 'posts_per_page=' . $instance['number'];

if ($instance['cat']) {

    $query_string .= '&cat=' . $instance['cat'];

}

$query = new WP_Query($query_string);



extract($args);

$title = apply_filters('widget_title', $instance['title']);



echo wp_kses_post($before_widget); ?>

<div class="footer-one__widget--gallery">

	<?php echo wp_kses_post($before_title . $title . $after_title); ?>

    <ul class="list-unstyled footer-one__widget__gallery">

        <?php if( $query->have_posts() ):?>

            

            <!-- Title -->

            <?php 

                global $post;

                while( $query->have_posts() ): $query->the_post(); 

                $post_thumbnail_id = get_post_thumbnail_id($post->ID);

                $post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);

            ?>

            <li>

                <a href="<?php echo esc_url( $post_thumbnail_url );?>" class="img-popup">

                    <?php the_post_thumbnail('towngov_70x70'); ?>

                    <span class="footer-one__widget__gallery__hover">

                        <i class="fab fa-instagram"></i>

                    </span><!-- /.footer-one__widget__gallery__hover -->

                </a>

            </li>    

            <?php endwhile; ?>

            

        <?php endif; ?>

    </ul><!-- /.blog-sidebar__post -->

</div>

<?php echo wp_kses_post($after_widget);

