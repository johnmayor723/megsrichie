(function ($) {
	"use strict";
	var clients_carousels_js = function ($scope, $) {

		$(document).ready(function () {
			var swiper = new Swiper(".imi-sponsor-slider-area", {
				slidesPerView: 6,
				spaceBetween: 50,
				loop: true,
				pagination: false,
				autoplay: {
					delay: 3000,
				},
				breakpoints: {
					1500: {
						slidesPerView: 6,
					},
					1199: {
						slidesPerView: 6,
					},
					991: {
						slidesPerView: 4,
					},
					767: {
						slidesPerView: 4,
					},
					575: {
						slidesPerView: 3,
					},
					450: {
						slidesPerView: 2,
					},
					0: {
						slidesPerView: 0,
					},
				},
			});
		});

		$(document).ready(function () {
			var swiper = new Swiper(".imi-sponsor-slider-2", {
				slidesPerView: 5,
				spaceBetween: 50,
				loop: true,
				pagination: false,
				autoplay: {
					delay: 3000,
				},
				breakpoints: {
					1500: {
						slidesPerView: 5,
					},
					1199: {
						slidesPerView: 5,
					},
					991: {
						slidesPerView: 4,
					},
					767: {
						slidesPerView: 4,
					},
					575: {
						slidesPerView: 2,
					},
					500: {
						slidesPerView: 1,
					},
					0: {
						slidesPerView: 2,
					},
				},
			});
		});

		$(document).ready(function () {
			var swiper = new Swiper(".imi-sponsor-slider-area_two", {
				slidesPerView: 5,
				spaceBetween: 50,
				loop: true,
				pagination: false,
				autoplay: {
					delay: 3000,
				},
				breakpoints: {
					1500: {
						slidesPerView: 5,
					},
					1199: {
						slidesPerView: 5,
					},
					991: {
						slidesPerView: 4,
					},
					767: {
						slidesPerView: 4,
					},
					575: {
						slidesPerView: 3,
					},
					450: {
						slidesPerView: 2,
					},
					0: {
						slidesPerView: 0,
					}
				},
			});
		});

	};

	$(window).on("elementor/frontend/init", function () {
		elementorFrontend.hooks.addAction(
			"frontend/element_ready/imigrat_client_section.default",
			clients_carousels_js
		);
	});
})(window.jQuery);
