<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Feature_List_Widget extends Widget_Base {

    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_feature_list_widget';
    }

    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Feature List', 'imigrat' );
    }

    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-bullet-list';
    }

    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }

    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function _register_controls() {
        $this->start_controls_section(
            'feature_list_widget',
            [
                'label' => esc_html__( 'Imigrat Feature List', 'imigrat' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat'),
				),
			]
		);
		//Feature List
		$repeater = new Repeater();	

		$repeater->add_control(
			'list_title',
			[
				'label'       => __( 'List Items', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your List', 'imigrat' ),
			]
		);
		$this->add_control(
			'list',
			[
				'label'                 => __('Add List Item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [
					'layout_control'      => ['1','3']
				],
			]
		);

		//Feature List
		$repeater = new Repeater();
		$repeater->add_control(
			'list_title',
			[
				'label'       => __( 'List Items', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your List', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'list_count_value',
			[
				'label'       => __( 'List Count Value', 'imigrat' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Count Value', 'imigrat' ),
			]
		);
		$this->add_control(
			'list_v2',
			[
				'label'                 => __('Add List Item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [
					'layout_control'      => '2',
				],
			]
		);




		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		//Feature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => ['1', '2', '3']
				],
			]
		);

		$this->add_responsive_control(
            'feature_list__margin',
            [
                'label'      => esc_html__( 'Margin', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-about-feature-list-2 li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'feature_list_padding',
            [
                'label'      => esc_html__( 'Padding', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-about-feature-list-2 li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-feature-list li,
						{{WRAPPER}} .imi-about-feature-list-2 li
				',
			]
		);

		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list li' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-about-feature-list-2 li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'cleanex'),
				'selector' => '{{WRAPPER}} .imi-about-feature-list li,
							   {{WRAPPER}} .imi-about-feature-list-2 li',
			]
		);

		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list li:before' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-about-feature-list-2 li:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'feature_list_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 li:before' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'layout_control'      => '3'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'feature_list_text_stroke',
				'selector' => '
					{{WRAPPER}} .imi-about-feature-list li,
					{{WRAPPER}} .imi-about-feature-list-2 li
				',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_text_shadow',
				'selector' => '
						{{WRAPPER}} .imi-about-feature-list li,
						{{WRAPPER}} .imi-about-feature-list-2 li',
			]
		);

		$this->end_controls_section();


		//Counter Style
		$this->start_controls_section(
			'counter_style',
			[
				'label' => esc_html__( 'Feature List Counter', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => '2'
				],
			]
		);
		$this->add_responsive_control(
            'feature_list_counter_margin',
            [
                'label'      => esc_html__( 'Margin', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list li span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
        $this->add_responsive_control(
            'feature_list_counter_padding',
            [
                'label'      => esc_html__( 'Padding', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list li span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_counter_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-feature-list li span',
			]
		);
		$this->add_control(
			'feature_list_counter_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list li span' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_counter_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-about-feature-list li span',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'feature_list_counter_text_stroke',
				'selector' => '{{WRAPPER}} .imi-about-feature-list li span',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_counter_text_shadow',
				'selector' => '{{WRAPPER}} .imi-about-feature-list li span',
			]
		);
		$this->end_controls_section();
    }

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
    ?>
    <?php if($layout == 3 ): ?>

    <div class="imi-about-feature-list-2 ul-li-block wow fadeInUp" data-wow-delay="500ms" data-wow-duration="1500ms">
        <ul>
        	<?php foreach($settings['list'] as $key => $item):?>
            <li><?php echo wp_kses($item['list_title'], true);?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <?php elseif( $layout == 2 ):?>

    <div class="imi-about-feature-list ul-li-block p-0 m-0 wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
        <ul>
            <?php foreach($settings['list_v2'] as $key => $item):?>
            <li><?php echo wp_kses($item['list_title'], true);?> <span><?php echo wp_kses($item['list_count_value'], true);?></span></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <?php else: ?>

    <div class="imi-about-feature-list ul-li-block p-0 m-0  wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
        <ul>
            <?php foreach($settings['list'] as $key => $item):?>
            <li><?php echo wp_kses($item['list_title'], true);?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <?php endif;
    }
}
