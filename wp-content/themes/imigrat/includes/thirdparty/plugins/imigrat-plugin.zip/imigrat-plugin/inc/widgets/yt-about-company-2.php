<?php

// Control core classes for avoid errors


//
// Create a widget 1
//
CSF::createWidget('yt_about_company_two', array(
    'title'       => esc_html__('YT About Company Two', 'imigrat-plugin'),
    'classname'   => 'yt-about-company-two',
    'description' => esc_html__('Show about the company Two', 'imigrat-plugins'),
    'fields'      => array(
         array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   => 'Title',
        ),
		array(
            'id'      => 'content',
            'type'    => 'textarea',
            'title'   => esc_html__( 'Content', 'imigrat-plugin'),
        ),
		array(
			'id'      => 'social_links_group',
			'type'    => 'group',
			'title'   => 'Group',
			'fields'    => array(
				array(
					'id'      => 'social_title',
					'type'    => 'text',
					'title'   => esc_html__('Social Title', 'imigrat'),
				),
				array(
					'id'	=> 'social_icon',
					'type'  => 'icon',
					'title' => esc_html__('Social Icon', 'imigrat'),
				),
				array(
					'id'      => 'social_link',
					'type'    => 'text',
					'title'   => esc_html__('Social URL'),
					'default' => '#',
				),
			)
		),
	)
));

//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_about_company_two') ) {
    function yt_about_company_two($args, $instance) {

        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/about-company-2.php';
    }
}
