<?php
namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Funfacts extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_get_funfacts';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Funfacts', 'imigrat' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	public function get_script_depends() {
		wp_register_script( 'fun-facts', YT_URL . 'assets/js/fun-facts.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'fun-facts' ];
	}


	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		// design style section
		$this->start_controls_section(
			'design_style_section',
			[
				'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
			]
		);

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'funfacts',
			[
				'label' => esc_html__( 'Imigrat Funfacts', 'imigrat' ),
			]
		);
		//Our Slider
		$repeater = new Repeater();

		$repeater->add_control(
			'slide_style',
			[
				'label' => __( 'Slide Style', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$repeater->add_control(
			'icons',
			[
				'label' => esc_html__('Select Icon', 'imigrat'),
				'label_block' => true,
				'type' => Controls_Manager::SELECT2,
				'options' => get_fontawesome_icons(),
				'condition' => [
					'slide_style' => 'style1',
				],
			]
		);

		// icon image
		$repeater->add_control(
			'icon_image',
			[
				'label' => __( 'Icon Image', 'imigrat' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'slide_style' => 'style2',
				],
			]
		);

		$repeater->add_control(
			'block_title',
			[
				'label'       => __( 'Block Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Block Title', 'imigrat' ),
			]
		);

		$repeater->add_control(
			'counter_sign',
			[
				'label'       => __( 'Counter Sign', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Counter Sign', 'imigrat' ),
				'condition' => [
					'slide_style' => 'style2',
				],
			]
		);

		$repeater->add_control(
			'counter_stop',
			[
				'label' => esc_html__('Counter Value', 'imigrat'),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Counter Value', 'imigrat' ),
			]
		);
		$this->add_control(
			'slides',
			[
				'label'                 => __('Add Slide Item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('LOOP CONTENT STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		//Title Style
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-counter-item h3',
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-counter-item h3' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'funfact_borders_color',
            [
                'label' => __('Left/Right Border Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-counter-item h3' => 'border-color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		//Content Style
		$this->add_control(
			'show_loop_value_style',
			[
				'label'       => __( 'ON/OFF  Counter Value Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_value_typography',
                'label' => __('Counter Value Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-counter-item p',
                'separator' => 'before',
				'condition'             => [
					'show_loop_value_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_value_color',
            [
                'label' => __('Counter Value Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-counter-item p' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_value_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
	}
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>
		<?php if($settings['style'] == 'style2' ) : ?>

		<?php foreach($settings['slides'] as $key => $item):?>
		<div class="counter-two_column">
			<div class="counter-two_counter-box">
				<?php if(!empty( $item['icon_image']['id'] )) : ?>
				<div class="counter-two_counter-icon">
					<img src="<?php echo esc_url(wp_get_attachment_url($item['icon_image']['id'])); ?>" alt="" />
				</div>
				<?php endif; ?>
				<div class="counter-two_count-box">
					<span class="counter"><?php echo esc_attr($item['counter_stop']);?></span>

					<i><?php echo esc_attr($item['counter_sign']);?></i> <br>
					<?php echo wp_kses($item['block_title'], true) ;?>
				</div>
			</div>
		</div>
		<?php endforeach;?>

		<?php else : ?>

    	<?php foreach($settings['slides'] as $key => $item):?>
        <div class="imi-counter-item d-flex align-items-center headline-2 pera-content">
            <p class="counter"><?php echo esc_attr($item['counter_stop']);?></p>
            <h3><?php echo wp_kses($item['block_title'], true) ;?></h3>
        </div>
    	<?php endforeach;?>

    <?php
		endif;
	}
}