<?php

extract($args);
echo wp_kses_post($before_widget); ?>

<div class="need-help-widget" <?php if ($instance['widget_bg_img2']) { ?>data-background="<?php echo esc_url(wp_get_attachment_url($instance['widget_bg_img2']['id'])); ?>"<?php } ?>>
    <h3><?php echo wp_kses_post($instance['help_title']); ?></h3>
    <p><?php echo wp_kses_post($instance['help_description']); ?></p>
    <?php if($instance['help_btn_link']['url'] || $instance['help_btn_title']){ ?>
    <div class="imi-btn-2">
        <a href="<?php echo esc_url($instance['help_btn_link']['url']); ?>"><?php echo wp_kses_post($instance['help_btn_title']); ?></a>
    </div>
    <?php } ?>
</div>

<?php
echo wp_kses_post($after_widget);
