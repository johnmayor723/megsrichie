<?php

// Control core classes for avoid errors
//
// Create a widget 1
//
CSF::createWidget('yt_contact_us', array(
    'title'       => esc_html__('YT Contact Us', 'imigrat-plugin'),
    'classname'   => 'yt-contact-us',
    'description' => esc_html__('Show Contact Us', 'imigrat-plugin'),
    'fields'      => array(
        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   => 'Title',
        ),
		array(
            'id'      => 'contact_address',
            'type'    => 'textarea',
            'title'   => esc_html__( 'Address', 'imigrat-plugin'),
        ),
        array(
            'id'      => 'contact_phone',
            'type'    => 'text',
            'title'   => esc_html__( 'Phone Number', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'opening_hours_title',
            'type'    => 'text',
            'title'   => esc_html__( 'Opening Hours Title', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'opening_hours_days',
            'type'    => 'text',
            'title'   => esc_html__( 'Opening Hours and Days', 'imigrat-plugin'),
        ),
    )
));

//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_contact_us') ) {
    function yt_contact_us($args, $instance) {

        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/contact-us.php';
    }
}
