<?php





//

// Set a unique slug-like ID

$prefix = 'imigrat_meta_testimonials';



//

// Create a metabox

CSF::createMetabox( $prefix, array(

	'title'      	=> 'Imigrat Testimonial Setting',

	'icon'       	=> 'el el-cogs',

	'position'   	=> 'normal',

	'priority'   	=> 'core',

	'post_type' 	=> array( 'testimonials' ),

	'show_restore'       => false,

	'context'            => 'advanced',

	'nav'                => 'normal',

	'theme'              => 'dark',

	'class'              => '',

) );



//

// Create a section

CSF::createSection($prefix, array(

	'fields' => array(

		array(

			'id'    => 'test_designation',

			'type'  => 'text',

			'title' => esc_html__( 'Author Designation', 'imigrat-plugin' ),

		),

		array(

			'id'    => 'testimonial_rating',

			'type'  => 'select',

			'title' => esc_html__( 'Choose the Rating', 'imigrat-plugin' ),

			'options'  => array(

				'1' => '1',

				'2' => '2',

				'3' => '3',

				'4' => '4',

				'5' => '5',

			),

		),

		array(

			'id'    => 'social_profile3',

			'type'  => 'group',

			'title' => esc_html__( 'Social Profiles', 'imigrat-plugin' ),

			'fields'	=> array(

				array(

					'id'    => 'url',

					'type'  => 'text',

					'title' => esc_html__( 'URL', 'imigrat-plugin' ),

				),

				array(

					'id'    => 'icon',

					'type'  => 'icon',

					'title' => esc_html__( 'Icon', 'imigrat-plugin' ),

				),

				array(

					'id'    => 'background',

					'type'  => 'color',

					'title' => esc_html__( 'Background Color', 'imigrat-plugin' ),

				),

				array(

					'id'    => 'color',

					'type'  => 'color',

					'title' => esc_html__( 'Color', 'imigrat-plugin' ),

				),

			)

		),

	)

));



