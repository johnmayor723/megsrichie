<?php

namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Team_Grid extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_team_grid';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Team Grid', 'imigrat' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-parallax';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	public function get_script_depends() {
		wp_register_script( 'team-slider', YT_URL . 'assets/js/team-slider.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'team-slider' ];
	}

	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
					'style3' => __( 'Style 3', 'imigrat' ),
					'style4' => __( 'Style 4', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'style' => ['style2', 'style3', 'style4'],
				],
            ]
        );

		$this->add_control(
			'shape',
			[
				'label' => esc_html__('Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'shape2',
			[
				'label' => esc_html__('Shape 2 Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style3'],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
				'condition' => [
					'style' => ['style2', 'style3', 'style4'],
				],
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'team_grid',
			[
				'label' => esc_html__( 'Team Grid', 'imigrat' ),
			]
		);
		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'three',
				'options' => array(
					'one' => esc_html__( 'One Column Grid ', 'imigrat'),
					'two'  => esc_html__( 'Two Column Grid', 'imigrat' ),
					'three'  => esc_html__( 'Three Column Grid', 'imigrat' ),
					'four'  => esc_html__( 'Four Column Grid', 'imigrat' ),
					'five'  => esc_html__( 'Six Column Grid', 'imigrat' ),
				),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label' => esc_html__( 'Button Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter button title', 'imigrat' ),
				'default' => esc_html__( 'Read More', 'imigrat' ),
			]
		);
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'imigrat' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 12,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'imigrat' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'imigrat' ),
                    'title'      => esc_html__( 'Title', 'imigrat' ),
                    'menu_order' => esc_html__( 'Menu Order', 'imigrat' ),
                    'rand'       => esc_html__( 'Random', 'imigrat' ),
                ),
            ]
        );
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'imigrat' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'imigrat' ),
                    'ASC'  => esc_html__( 'ASC', 'imigrat' ),
                ),
            ]
        );
		$this->add_control(
            'query_category',
			[
			  'type' => Controls_Manager::SELECT,
			  'label_block' => true,
			  'label' => esc_html__('Category', 'imigrat'),
			  'options' => get_team_categories()
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'style' => ['style2', 'style4'],
				],
            ]
        );

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		/************************************************************************
								Tab Style Start
		*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-team-section-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-team-section-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-team-section-3',
			]
		);
		$this->end_controls_section();

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .color-layer',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);
		$this->end_controls_section();

		/**Team Box Style**/
		$this->start_controls_section(
			'team_box_style',
			[
				'label' => esc_html__('Box Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'imigrat_team_box_tab' );

			$this->start_controls_tab(
				'imigrat_team_box_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'team_box_bgtype',
						'label' => __( 'Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'
							{{WRAPPER}} .imi-team-item-3,
							{{WRAPPER}} .team-block_one-content
							',
					]
				);
				$this->add_responsive_control(
					'team_box_space',
					[
						'label'              => __( 'Space', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-team-item-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],

						'frontend_available' => true,
					]
				);
				$this->add_responsive_control(
					'team_box_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-team-item-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],

						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'team_box_border_type',
						'selector' =>
							'
								{{WRAPPER}} .imi-team-item-3,
								{{WRAPPER}} .team-block_one-content
							',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'team_box_shadow',
						'selector' =>
							'{{WRAPPER}} .team-card__content,
							 {{WRAPPER}} .team-card__hover',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'team_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'imigrat_teams_box_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'team_hover_bg_bgtype',
						'label' => __( 'Hover Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'
								{{WRAPPER}} .imi-team-item-3:hover,
								{{WRAPPER}} .team-block_one-inner:hover .team-block_one-content
							',
					]
				);

				$this->add_control(
					'team_background_hover_transition',
					[
						'label' => esc_html__( 'Transition Duration', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'range' => [
							'px' => [
								'max' => 3,
								'step' => 0.1,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3:hover' => 'transition-duration: {{SIZE}}s',
						],
					]
				);

				$this->add_control(
					'hover_animation',
					[
						'label' => esc_html__( 'Hover Animation', 'imigrat' ),
						'type' => Controls_Manager::HOVER_ANIMATION,
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'name_style',
			[
				'label' => esc_html__( 'Name Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'name__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-team-item-3 .imi-team-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team-block_one-heading a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'name_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-team-item-3 .imi-team-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .team-block_one-heading a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' =>
					'
					{{WRAPPER}} .imi-team-item-3 .imi-team-text h3,
					{{WRAPPER}} .team-block_one-heading a

					',
			]
		);
		$this->add_control(
			'name_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-team-item-3 .imi-team-text h3 a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .team-block_one-heading a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'name_hover_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-team-item-3 .imi-team-text h3:hover a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .team-block_one-heading:hover a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'name_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-team-item-3 .imi-team-text h3,
				{{WRAPPER}} .team-block_one-heading a
				',

			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'name_text_shadow',
				'selector' =>
					'
					{{WRAPPER}} .imi-team-item-3 .imi-team-text h3,
					{{WRAPPER}} .team-block_one-heading a
					',
			]
		);

		$this->end_controls_section();

		//Designation Style
		$this->start_controls_section(
			'designation_style',
			[
				'label' => esc_html__( 'Designation Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'designation_text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-team-item-3 .imi-team-text span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    '{{WRAPPER}} .team-block_one-designation' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'designation_text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-team-item-3 .imi-team-text span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                    '{{WRAPPER}} .team-block_one-designation' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_control(
			'designation_text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-team-item-3 .imi-team-text span' => 'color: {{VALUE}};',
					'{{WRAPPER}} .team-block_one-designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' =>
				'
				{{WRAPPER}} .imi-team-item-3 .imi-team-text span,
				{{WRAPPER}} .team-block_one-designation
				',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'designation_text_text_shadow',
				'selector' =>
					'
					{{WRAPPER}} .imi-team-item-3 .imi-team-text span
					{{WRAPPER}} .team-block_one-designation',
			]
		);

		$this->end_controls_section();

		/**Icon Box Style**/
		$this->start_controls_section(
			'icon_box_style',
			[
				'label' => esc_html__('Social Icon Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'imigrat_social_icon_tab' );

			$this->start_controls_tab(
				'imigrat_social_icon_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'icon_box_bgtype',
						'label' => __( 'Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a,
							{{WRAPPER}} .team-block_one .left-social a,
							{{WRAPPER}} .team-block_one .right-social a,
						',

					]
				);
				$this->add_control(
					'social_icon_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a' => 'color: {{VALUE}}',
							'{{WRAPPER}} .team-block_one .left-social a' => 'color: {{VALUE}}',
							'{{WRAPPER}} .team-block_one .right-social a' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
				$this->add_responsive_control(
					'icon_box_space',
					[
						'label'              => __( 'Space', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one .left-social a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one .right-social a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],

						'frontend_available' => true,
					]
				);
				$this->add_responsive_control(
					'icon_box_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one .left-social a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one .right-social a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],

						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'social_icon_border_type',
						'selector' =>
							'
							{{WRAPPER}} .imi-team-item-3 .imi-team-social a,
							{{WRAPPER}} .team-block_one .left-social a,
							{{WRAPPER}} .team-block_one .right-social a,
							',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'social_icon_box_shadow',
						'selector' =>
							'
							{{WRAPPER}} .imi-team-item-3 .imi-team-social a,
							{{WRAPPER}} .team-block_one .left-social a,
							{{WRAPPER}} .team-block_one .right-social a,
							',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'social_icon_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one .left-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .team-block_one .right-social a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],
					]
				);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'imigrat_socials_icon_box_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'social_icon_hover_bg_bgtype',
						'label' => __( 'Hover Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a:hover,
							{{WRAPPER}} .team-block_one .left-social a:hover
							{{WRAPPER}} .team-block_one .right-social a:hover',
					]
				);

				$this->add_control(
					'icon_hover_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a:hover' => 'color: {{VALUE}}',
							'{{WRAPPER}} .team-block_one .left-social a:hover' => 'color: {{VALUE}}',
							'{{WRAPPER}} .team-block_one .right-social a:hover' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);

				$this->add_control(
					'social_icon_hover_transition',
					[
						'label' => esc_html__( 'Transition Duration', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'range' => [
							'px' => [
								'max' => 3,
								'step' => 0.1,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-social a:hover' => 'transition-duration: {{SIZE}}s',
							'{{WRAPPER}} .team-block_one .left-social a:hover' => 'transition-duration: {{SIZE}}s',
							'{{WRAPPER}} .team-block_one .right-social a:hover' => 'transition-duration: {{SIZE}}s',
						],
					]
				);

				$this->add_control(
					'social_icon_hover_animation',
					[
						'label' => esc_html__( 'Hover Animation', 'imigrat' ),
						'type' => Controls_Manager::HOVER_ANIMATION,
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

		/**Button Style**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'imigrat_tabs_btn' );

			$this->start_controls_tab(
				'imigrat_tab_btn_normal',
				[
					'label' => __( 'Normal', 'imigrat' ),
				]
			);
				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_bgtype',
						'label' => __( 'Button Background', 'imigrat' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'
							{{WRAPPER}} .imi-team-item-3 .imi-team-btn a,
							{{WRAPPER}} .btn-style-one
							',
					]
				);
				$this->add_responsive_control(
					'btn_width_size',
					[
						'label' => __( 'Width', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a' => 'width: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_height_size',
					[
						'label' => __( 'Height', 'imigrat' ),
						'type' => Controls_Manager::SLIDER,
						'size_units' => [ 'px', 'em', '%', 'custom' ],
						'range' => [
							'px' => [
								'min' => 0,
								'max' => 500,
							],
							'%' => [
								'min' => 0,
								'max' => 100,
							],
						],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a' => 'height: {{SIZE}}{{UNIT}};'
						],
					]
				);
				$this->add_responsive_control(
					'btn_padding',
					[
						'label'              => __( 'Padding', 'imigrat' ),
						'type'               => Controls_Manager::DIMENSIONS,
						'size_units'         => [ 'px', 'em', '%' ],
						'selectors'          => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .btn-style-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],

						'frontend_available' => true,
					]
				);
				$this->add_group_control(
					Group_Control_Border::get_type(),
					[
						'name' => 'btn_border_type',
						'selector' =>
							'
							{{WRAPPER}} .imi-team-item-3 .imi-team-btn a,
							{{WRAPPER}} .btn-style-one
							',
						'separator' => 'before',
					]
				);
				$this->add_group_control(
					Group_Control_Box_Shadow::get_type(),
					[
						'name' => 'border_box_shadow',
						'selector' =>
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a',
							'{{WRAPPER}} .btn-style-one',
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_border_radius',
					[
						'label' => esc_html__('Border Radius', 'imigrat'),
						'type' => Controls_Manager::DIMENSIONS,
						'separator' => 'before',
						'size_units' => ['px'],
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .btn-style-one' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
						],
					]
				);
				$this->add_control(
					'btn_title_color',
					[
						'label' => __('Button Text Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a' => 'color: {{VALUE}}',
							'{{WRAPPER}} .btn-style-one span' => 'color: {{VALUE}}'
						],
						'separator' => 'before',
					]
				);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'imigrat_tab_btn_hover',
				[
					'label' => __( 'Hover', 'imigrat' ),
				]
			);

				$this->add_group_control(
					Group_Control_Background::get_type(),
					[
						'name' => 'btn_hover_bg_bgtype',
						'label' => __( 'Button Hover Background', 'imigrat' ),

						'types' => [ 'classic', 'gradient' ],
						'selector' =>
							'
							{{WRAPPER}} .imi-team-item-3 .imi-team-btn a:hover,
							{{WRAPPER}} .btn-style-one:hover,
							{{WRAPPER}} .btn-style-one:hover::before
							',
					]
				);
				$this->add_control(
					'btn_border_hover_color',
					[
						'label' => __('Button Border Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a:hover' => 'border-color: {{VALUE}}',
							'{{WRAPPER}} .btn-style-one:hover' => 'border-color: {{VALUE}}',

						],
						'separator' => 'before',
					]
				);
				$this->add_control(
					'btn_title_hover_color',
					[
						'label' => __('Button Text Hover Color', 'imigrat'),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .imi-team-item-3 .imi-team-btn a:hover' => 'color: {{VALUE}}',
							'{{WRAPPER}} .btn-style-one:hover span' => 'color: {{VALUE}}',
						],
						'separator' => 'before',
					]
				);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();

	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
        $btn_title = $settings[ 'btn_title' ];

		$grid_col = $settings[ 'col_grid' ];
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}elseif( $grid_col == 'five' ){
			$classes = 'col-lg-2 col-md-6 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}

		$paged = imigrat_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-imigrat' );
		$args = array(
			'post_type'      =>  'team',
			'posts_per_page' => imigrat_set( $settings, 'query_number' ),
			'orderby'        => imigrat_set( $settings, 'query_orderby' ),
			'order'          => imigrat_set( $settings, 'query_order' ),
			'paged'         => $paged
		);

		if( imigrat_set( $settings, 'query_category' ) ) $args['team_cat'] = imigrat_set( $settings, 'query_category' );
			$query = new \WP_Query( $args );
			if ( $query->have_posts() ) :
	?>

	<?php if($settings['style'] == 'style4' ) : ?>
		<section class="team-three"
			<?php if(!empty( $settings['shape']['id'] )) : ?>
			style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape']['id'])); ?>)"
			<?php endif; ?>
			>
		<div class="container">
			<div class="row clearfix">
				<!-- Team Three Title Column -->
				<div class="team-three_title-column col-lg-4 col-md-12 col-sm-12">
					<div class="team-three_title-inner">
						<div class="sec-title-three">
							<?php if(!empty( $settings['sub_title'] )) : ?>
							<div class="title"><?php echo wp_kses($settings['sub_title'], true); ?></div>
							<?php endif; ?>

							<?php if(!empty( $settings['title'] )) : ?>
							<h2><?php echo wp_kses($settings['title'], true); ?></h2>
							<?php endif; ?>

							<?php if(!empty( $settings['text'] )) : ?>
							<div class="text">
								<?php echo wp_kses($settings['text'], true); ?>
							</div>
							<?php endif; ?>
						</div>

						<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
						<div class="button-box">
							<a class="btn-style-eight theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
								<div class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['button_text'], true); ?>
									 <i class="fal fa-angle-double-right fa-fw"></i></span>
									<span class="text-two"><?php echo wp_kses($settings['button_text'], true); ?>
									 <i class="fal fa-angle-double-right fa-fw"></i></span>
								</div>
							</a>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<!-- Team Three Carousel Column -->
				<div class="team-three_carousel-column col-lg-8 col-md-12 col-sm-12">
					<div class="team-three_carousel-inner">
						<div class="imi-team_carousel swiper">
							<div class="swiper-wrapper">
								<?php while ( $query->have_posts() ) : $query->the_post(); ?>
								<?php $imigrat_team_meta = get_post_meta( get_the_ID(), 'imigrat_meta_team', true );?>
								<div class="swiper-slide">
									<div class="team-block_three">
										<div class="team-block_three-inner">
											<div class="team-block_three-image">
												<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
												<?php if(has_post_thumbnail()) : ?>
													<?php the_post_thumbnail('imigrat_410x448'); ?>
												<?php endif; ?>
												</a>

												<?php
													$icons = $imigrat_team_meta['social_profile'];
													if ( ! empty( $icons ) ) :
												?>
												<div class="team-three_social-box">
													<?php foreach ( $icons as $h_icon ) {
														$icon_class = explode( '-', imigrat_set( $h_icon, 'icon' ) );
													?>
														<a href="<?php echo esc_url(imigrat_set( $h_icon, 'url' )); ?>" <?php if( imigrat_set( $h_icon, 'background' ) || imigrat_set( $h_icon, 'color' ) ):?>style="background-color:<?php echo esc_attr(imigrat_set( $h_icon, 'background' )); ?>; color: <?php echo esc_attr(imigrat_set( $h_icon, 'color' )); ?>"<?php endif;?> class="fab <?php echo esc_attr( imigrat_set( $h_icon, 'icon' ) ); ?>"></a>
													<?php } ?>
												</div>
												<?php endif; ?>

											</div>
											<div class="team-block_three-content">
												<a class="arrow" href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
													<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-5.png" alt="" />
												</a>
												<h4 class="team-block_three-heading"><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
												<div class="team-block_three-designation">
													<?php echo wp_kses($imigrat_team_meta['designation'], true ); ?>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php endwhile; ?>
							</div>
						</div>
						<div class="next-prev-btn">
							<div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
							<div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($settings['style'] == 'style3' ) : ?>
	<section class="team-two">
		<?php if(!empty( $settings['shape']['id'] )) : ?>
		<div class="team-two_icon" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['shape2']['id'] )) : ?>
		<div class="team-two_icon-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape2']['id'])); ?>)"></div>
		<?php endif; ?>

		<div class="container">
			<div class="sec-title-two">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span> <?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>

					</div>
					<!-- Text -->
					<?php if(!empty( $settings['text'] )) : ?>
					<div class="text">
						<?php echo wp_kses($settings['text'], true); ?>
					</div>
					<?php endif; ?>

				</div>
			</div>
			<div class="imi-service-content position-relative">
				<div class="imi-service-slider swiper">
					<div class="swiper-wrapper">
						<?php while ( $query->have_posts() ) : $query->the_post(); ?>
						<?php $imigrat_team_meta = get_post_meta( get_the_ID(), 'imigrat_meta_team', true );?>
						<!-- Swiper Slide -->
						<div class="swiper-slide">
							<div class="team-block_two">
								<div class="team-block_two-inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
									<div class="team-block_two-image">
										<?php if(has_post_thumbnail()) : ?>
										<?php the_post_thumbnail('imigrat_410x448'); ?>
										<?php endif; ?>
										<div class="team-block_two-content">
											<h4 class="team-block_two-heading">
												<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a>
											</h4>
											<div class="team-block_two-designation">
												<?php echo wp_kses($imigrat_team_meta['designation'], true ); ?>
											</div>
										</div>
									</div>
									<?php
										$icons = $imigrat_team_meta['social_profile'];
										if ( ! empty( $icons ) ) :
									?>
									<div class="team-two_social-box">
										<?php foreach ( $icons as $h_icon ) {
											$icon_class = explode( '-', imigrat_set( $h_icon, 'icon' ) );
										?>
											<a href="<?php echo esc_url(imigrat_set( $h_icon, 'url' )); ?>" <?php if( imigrat_set( $h_icon, 'background' ) || imigrat_set( $h_icon, 'color' ) ):?>style="background-color:<?php echo esc_attr(imigrat_set( $h_icon, 'background' )); ?>; color: <?php echo esc_attr(imigrat_set( $h_icon, 'color' )); ?>"<?php endif;?> class="fab <?php echo esc_attr( imigrat_set( $h_icon, 'icon' ) ); ?>"></a>
										<?php } ?>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<?php endwhile; ?>
					</div>
				</div>
				<div class="next-prev-btn">
					<div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
					<div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($settings['style'] == 'style2' ) : ?>
	<section class="team-one">
		<?php if(!empty( $settings['shape']['id'] )) : ?>
		<div class="team-one_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape']['id'])); ?>)"></div>
		<?php endif; ?>
		<div class="container">
			<div class="sec-title">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box">

						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>

					</div>
					<!-- Text -->
					<?php if(!empty( $settings['text'] )) : ?>
					<div class="text d-block"><?php echo wp_kses($settings['text'], true); ?></div>
					<?php endif; ?>
				</div>
			</div>
			<div class="row clearfix">
				<?php while ( $query->have_posts() ) : $query->the_post(); ?>
				<?php $imigrat_team_meta = get_post_meta( get_the_ID(), 'imigrat_meta_team', true );?>
				<!-- Team Block One -->
				<div class="team-block_one <?php echo esc_attr( $classes );?>">
					<div class="team-block_one-inner wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1000ms">
						<?php if(has_post_thumbnail()) : ?>
						<div class="team-block_one-image">
							<?php the_post_thumbnail('imigrat_410x448'); ?>
						</div>
						<?php endif; ?>
						<div class="team-block_one-content">
							<?php
								$icons = $imigrat_team_meta['social_profile'];
								if ( ! empty( $icons ) ) :
							?>
							<div class="left-social">
								<?php foreach ( $icons as $h_icon ) {
									$icon_class = explode( '-', imigrat_set( $h_icon, 'icon' ) );
								?>
									<a href="<?php echo esc_url(imigrat_set( $h_icon, 'url' )); ?>" <?php if( imigrat_set( $h_icon, 'background' ) || imigrat_set( $h_icon, 'color' ) ):?>style="background-color:<?php echo esc_attr(imigrat_set( $h_icon, 'background' )); ?>; color: <?php echo esc_attr(imigrat_set( $h_icon, 'color' )); ?>"<?php endif;?> class="fab <?php echo esc_attr( imigrat_set( $h_icon, 'icon' ) ); ?>"></a>
								<?php } ?>
							</div>
							<?php endif; ?>
							<h4 class="team-block_one-heading">
								<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h4>
							<div class="team-block_one-designation"><?php echo wp_kses($imigrat_team_meta['designation'], true ); ?></div>
							<?php
								$icons = $imigrat_team_meta['social_profile'];
								if ( ! empty( $icons ) ) :
							?>
							<div class="right-social">
								<?php foreach ( $icons as $h_icon ) {
									$icon_class = explode( '-', imigrat_set( $h_icon, 'icon' ) );
								?>
									<a href="<?php echo esc_url(imigrat_set( $h_icon, 'url' )); ?>" <?php if( imigrat_set( $h_icon, 'background' ) || imigrat_set( $h_icon, 'color' ) ):?>style="background-color:<?php echo esc_attr(imigrat_set( $h_icon, 'background' )); ?>; color: <?php echo esc_attr(imigrat_set( $h_icon, 'color' )); ?>"<?php endif;?> class="fab <?php echo esc_attr( imigrat_set( $h_icon, 'icon' ) ); ?>"></a>
								<?php } ?>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<?php endwhile; ?>

			</div>

			<!-- Button Box -->
			<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
			<div class="button-box text-center">
				<a class="btn-style-one theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
					<div class="btn-wrap">
						<span class="text-one">
							<?php echo wp_kses($settings['button_text'], true);?> <i><img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" /></i></span>
						<span class="text-two">
							<?php echo wp_kses($settings['button_text'], true);?> <i><img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" /></i></span>
					</div>
				</a>
			</div>
			<?php endif; ?>

		</div>
	</section>
	<?php else : ?>

    <!-- Start of Team section
	============================================= -->
	<section id="imi-team-3" class="imi-team-section-3 p-0 m-0">
		<div class="container">

			<div class="imi-team-content-3">
				<div class="row justify-content-center">

					<?php while ( $query->have_posts() ) : $query->the_post(); ?>
        			<?php $imigrat_team_meta = get_post_meta( get_the_ID(), 'imigrat_meta_team', true );?>
                    <div class="<?php echo esc_attr( $classes );?>">
						<div class="imi-team-item-3">
							<div class="imi-team-img-social-btn position-relative">
								<div class="imi-team-img">
									<?php the_post_thumbnail('imigrat_410x448'); ?>
								</div>
								<div class="imi-team-btn text-uppercase">
									<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>">
                                    <?php if( !empty( $btn_title ) ):?>
										<?php echo wp_kses( $btn_title, true );?>
                                    <?php else:?>
                                        <?php esc_html_e('MORE DETAILS', 'imigrat');?>
                                    <?php endif;?>
                                    <i class="fal fa-long-arrow-right"></i></a>
								</div>
								<?php
									$icons = $imigrat_team_meta['social_profile'];
									if ( ! empty( $icons ) ) :
								?>
                                <div class="imi-team-social">
									 <?php foreach ( $icons as $h_icon ) {
										$icon_class = explode( '-', imigrat_set( $h_icon, 'icon' ) );
									?>
									<a href="<?php echo esc_url(imigrat_set( $h_icon, 'url' )); ?>" <?php if( imigrat_set( $h_icon, 'background' ) || imigrat_set( $h_icon, 'color' ) ):?>style="background-color:<?php echo esc_attr(imigrat_set( $h_icon, 'background' )); ?>; color: <?php echo esc_attr(imigrat_set( $h_icon, 'color' )); ?>"<?php endif;?> class="fab <?php echo esc_attr( imigrat_set( $h_icon, 'icon' ) ); ?>"></a>
									<?php } ?>
								</div>
                                <?php endif; ?>
							</div>
							<div class="imi-team-text text-center headline">
								<h3 class="text-uppercase">
									<a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title(); ?></a></h3>
								<span><?php echo wp_kses($imigrat_team_meta['designation'], true ); ?></span>
							</div>
						</div>
					</div>
					<?php endwhile; ?>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Team section
	============================================= -->
    <?php
		endif;
		endif;
		wp_reset_postdata();
	}
}