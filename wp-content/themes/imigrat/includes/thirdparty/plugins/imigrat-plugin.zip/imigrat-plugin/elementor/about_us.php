<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class About_Us extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_about_us';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat About Us', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
					'style3' => __( 'Style 3', 'imigrat' ),
					'style4' => __( 'Style 4', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'style' => ['style2', 'style3' , 'style4'],
				],
            ]
        );

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Section Bg Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image1',
			[
				'label' => esc_html__('Image 1', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image2',
			[
				'label' => esc_html__('Image 2', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image3',
			[
				'label' => esc_html__('Image 3', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
            ]
        );
		$this->add_control(
			'about_image',
			[
				'label' => esc_html__('About Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style1'],
				],
			]
		);
		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);
		$this->add_control(
			'exp_icon_image',
			[
				'label' => esc_html__(' Exp Icon Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style1'],
				],
			]
		);
		$this->add_control(
			'experiance_year',
			[
				'label' => esc_html__( 'Experiance Year', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Experiance Year', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),
				'condition' => [
					'style' => ['style1', 'style4'],
				],

			]
		);
		$this->add_control(
			'experiance_title',
			[
				'label' => esc_html__( 'Experiance Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Experiance Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),
				'condition' => [
					'style' => ['style1', 'style4'],
				],

			]
		);
		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);
		$this->add_control(
			'features_list',
			[
				'label' => esc_html__('Feature List', 'imigrat'),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'imigrat' ),
				'condition' => [
					'style' => ['style1', 'style2', 'style3'],
				],
			]
		);
		$this->add_control(
			'experiance_image',
			[
				'label' => esc_html__('Choose Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style1'],
				],
			]
		);


		$repeater = new Repeater();

		// icon image
		$repeater->add_control(
			'icon_image',
			[
				'label' => esc_html__('Icon Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$repeater->add_control(
			'list_title',
			[
				'label'       => __( 'List Items', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your List', 'imigrat' ),
			]
		);

		$this->add_control(
			'lists',
			[
				'label'     => __('Add List Item', 'imigrat'),
				'type'      => Controls_Manager::REPEATER,
				'fields'    => $repeater->get_controls(),
				'title_field' => '{{{ list_title }}}',
				'condition' => [
					'style' => ['style4'],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'style' => ['style2', 'style3', 'style4'],
				],
            ]
        );

		// video button text
		$this->add_control(
			'video_button_text',
			[
				'label' => esc_html__('Video Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Watch Video', 'imigrat'),
				'condition' => [
					'style' => ['style4'],
				],
			]
		);

		// video button link
		$this->add_control(
			'video_button_link',
			[
				'label' => esc_html__('Video Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
					'style' => ['style3'],
				],
			]
		);

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'call_info_section',
			[
				'label' => esc_html__( 'CALL INFO', 'imigrat' ),
				'condition' => [
					'style' => ['style2'],
				],
			]
        );

		// call info text
		$this->add_control(
			'call_info_text',
			[
				'label' => esc_html__('Call Info Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Call Us Now', 'imigrat'),
			]
		);

		// call info number
		$this->add_control(
			'call_info_number',
			[
				'label' => esc_html__('Call Info Number', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('+123 456 7890', 'imigrat'),
			]
		);

		$this->end_controls_section();


	/************************************************************************
								Tab Style Start
	*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-about-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-about-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-page-about-section',
			]
		);
		$this->end_controls_section();

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .color-layer',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);
		$this->end_controls_section();

		//Experiance box Style
		$this->start_controls_section(
			'experiance_box_style',
			[
				'label' => esc_html__( 'Experiance Box Style', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style1', 'style4'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'experiance_box_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'experiance_box_year_typography',
				'label' => __('Year Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area h3',
			]
		);
		$this->add_control(
			'experiance_box_year_color',
			[
				'label' => esc_html__( 'Experiance Year Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area h3' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'experiance_box_title_typography',
				'label' => __('Text Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area p',
			]
		);
		$this->add_control(
			'experiance_box_title_color',
			[
				'label' => esc_html__( 'Experiance Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		//Feature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'feature_list__margin',
            [
                'label'      => esc_html__( 'Margin', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list-2 ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .about-one_check' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'feature_list_padding',
            [
                'label'      => esc_html__( 'Padding', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list-2 ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .about-one_check' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
					{{WRAPPER}} .imi-about-feature-list-2 ul,
					{{WRAPPER}} .about-one_check
				',
			]
		);

		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li' => 'color: {{VALUE}};',
					'{{WRAPPER}} .about-one_check li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'cleanex'),
				'selector' => '
				{{WRAPPER}} .imi-about-feature-list-2 ul li
				{{WRAPPER}} .about-one_check li',
			]
		);

		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'feature_list_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'feature_list_text_stroke',
				'selector' => '
					{{WRAPPER}} .imi-about-feature-list-2 ul li,
					{{WRAPPER}} .about-one_check li
				',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_text_shadow',
				'selector' => '
						{{WRAPPER}} .imi-about-feature-list-2 ul li,
						{{WRAPPER}} .about-one_check li',
			]
		);
		$this->end_controls_section();

		// button style
		$this->start_controls_section(
			'btn_style',
			[
				'label' => __( 'BUTTON STYLE', 'imigrat-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// enable button style
		$this->add_control(
			'show_btn_style2',
			[
				'label'       => __( 'ON/OFF Button Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		// button typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_title_typography2',
				'label' => __('Button Text Typography', 'imigrat-plugin'),
				'selector' =>
					'
						{{WRAPPER}} .btn-style-one span,
						{{WRAPPER}} .btn-style-two span,
						{{WRAPPER}} .btn-style-four span,
						{{WRAPPER}} .btn-style-seven span
					',
				'separator' => 'before',
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// border radius
		$this->add_responsive_control(
			'btn_border_radius2',
			[
				'label'              => __( 'Border Radius', 'imigrat-plugin' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .btn-style-one' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-two' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-four' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-seven' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],

				'frontend_available' => true,
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->start_controls_tabs( '_tabs_button-' );

		$this->start_controls_tab(
            '_tab_button_normal',
            [
                'label' => __( 'Normal', 'elementhelper' ),
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
            ]
        );

		// button color
		$this->add_control(
			'btn_title_color2',
			[
				'label' => __( 'Button Text Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven span' => 'color: {{VALUE}}!important',
				],
				'condition' => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg color
		$this->add_control(
			'btn_bg_color2',
			[
				'label' => __( 'Button Background Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
            'button_hover',
            [
                'label' => __( 'Hover', 'elementhelper' ),
            ]
        );

		// button hover color
		$this->add_control(
			'btn_title_hover_color2',
			[
				'label' => __( 'Button Text Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover span' => 'color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg hover color
		$this->add_control(
			'btn_bg_hover_color2',
			[
				'label' => __( 'Button Background Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover::before' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();
        $this->end_controls_tabs();

		$this->end_controls_section();

		// Call to action button style
		$this->start_controls_section(
			'cta_btn_style',
			[
				'label' => __( 'Call Info Style', 'imigrat-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// icon bg color
		$this->add_control(
			'icon_bg_color',
			[
				'label' => __( 'Icon Background Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .about-one_phone .icon' => 'background-color: {{VALUE}}!important',
				],
			]
		);

		// border color
		$this->add_control(
			'border_color',
			[
				'label' => __( 'Border Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .about-one_phone .icon::after' => 'border-color: {{VALUE}}!important',
				],
			]
		);

		// info label color
		$this->add_control(
			'info_label_color',
			[
				'label' => __( 'Info Label Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .about-one_phone' => 'color: {{VALUE}}!important',
				],
			]
		);

		// info label typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'info_label_typography',
				'label' => __( 'Info Label Typography', 'imigrat-plugin' ),
				'selector' => '{{WRAPPER}} .about-one_phone',
			]
		);

		// info text color
		$this->add_control(
			'info_text_color',
			[
				'label' => __( 'Number Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .about-one_phone strong' => 'color: {{VALUE}}!important',
				],
			]
		);

		// info text typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'info_text_typography',
				'label' => __( 'Number Typography', 'imigrat-plugin' ),
				'selector' => '{{WRAPPER}} .about-one_phone strong',
			]
		);

		$this->end_controls_section();


	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if($settings['style'] == 'style4' ) : ?>

	<section class="about-two">
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		<div class="about-two_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['image1']['id'] )) : ?>
		<div class="about-two_pattern-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)"></div>
		<?php endif; ?>
		<div class="container">
			<div class="row clearfix">
				<!-- Image Column -->
				<div class="image-column col-lg-6 col-md-12 col-sm-12">
					<div class="image">
						<div class="about-two_counter">
							<?php if(!empty( $settings['experiance_year'] )) : ?>
							<span class="counter"><?php echo wp_kses($settings['experiance_year'], true); ?></span><i>+</i>
							<?php endif; ?>

							<?php if(!empty( $settings['experiance_title'] )) : ?>
							<div class="text"><?php echo wp_kses($settings['experiance_title'], true); ?></div>
							<?php endif; ?>
						</div>
						<?php if(!empty( $settings['image2']['id'] )) : ?>
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="" />
						<?php endif; ?>
					</div>

					<?php if(!empty( $settings['image3']['id'] )) : ?>
					<div class="image-two">
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>" alt="" />
					</div>
					<?php endif; ?>
				</div>
				<!-- Content Column -->
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="sec-title-three">
							<?php if(!empty( $settings['sub_title'] )) : ?>
							<div class="title"><?php echo wp_kses($settings['sub_title'], true); ?></div>
							<?php endif; ?>

							<?php if(!empty( $settings['title'] )) : ?>
							<h2><?php echo wp_kses($settings['title'], true); ?></h2>
							<?php endif; ?>

						</div>
						<div class="content">
							<?php if(!empty( $settings['text'] )) : ?>
							<p><?php echo wp_kses($settings['text'], true); ?></p>
							<?php endif; ?>

							<?php if(!empty( $settings['lists'] )) : ?>
							<div class="about-two_options">
								<ul class="about-two_list split-in-half">
									<?php foreach($settings['lists'] as $list) : ?>
									<li>
										<?php if(!empty( $list['icon_image']['id'] )) : ?>
										<span class="icon">
											<img src="<?php echo esc_url(wp_get_attachment_url($list['icon_image']['id'])); ?>" alt="" />
										</span>
										<?php endif; ?>

										<?php echo wp_kses($list['list_title'], true); ?>
									</li>
									<?php endforeach; ?>
								</ul>
							</div>
							<?php endif; ?>

							<div class="d-flex align-items-center flex-wrap">
								<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
								<!-- Button Box -->
								<div class="button-box">
									<a class="btn-style-eight theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
										<div class="btn-wrap">
											<span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
												<i class="fal fa-angle-double-right fa-fw"></i></span>
											<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
												<i class="fal fa-angle-double-right fa-fw"></i></span>
										</div>
									</a>
								</div>
								<?php endif; ?>

								<?php if(!empty( $settings['video_button_link']['url'] || $settings['video_button_text'] )) : ?>
								<div class="about-two_video">
									<a href="<?php echo esc_url($settings['video_button_link']['url']); ?>">
									<span class="fa fa-play"></span></a> <?php echo wp_kses($settings['video_button_text'], true);?>
								</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<?php elseif($settings['style'] == 'style3' ) : ?>
	<section class="company-one">
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		<div class="company-one_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)">
		</div>
		<?php endif; ?>
		<div class="container">
			<div class="inner-container">
				<?php if(!empty( $settings['image1']['id'] )) : ?>
				<div class="company-one_pattern-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)">
				</div>
				<?php endif; ?>
				<div class="row clearfix">
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<div class="sec-title-two">
							<?php if(!empty( $settings['sub_title'] )) : ?>
							<div class="title"><?php echo wp_kses($settings['sub_title'], true); ?></div>
							<?php endif; ?>

							<?php if(!empty( $settings['title'] )) : ?>
							<h2><?php echo wp_kses($settings['title'], true); ?></h2>
							<?php endif; ?>
						</div>

						<div class="image">
							<?php if(!empty( $settings['image2']['id'] )) : ?>
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="" />
							<?php endif; ?>

							<?php if(!empty( $settings['video_button_link']['url'] )) : ?>
							<a href="<?php echo esc_url($settings['video_button_link']['url']); ?>" class="video_box company-one_video-box">
								<span class="icon"><i class="fas fa-play"></i></span>
							<i class="ripple"></i></a>
							<?php endif; ?>

						</div>
					</div>
					<!-- Column -->
					<div class="column col-lg-6 col-md-12 col-sm-12">
						<?php if(!empty( $settings['image3']['id'] )) : ?>
						<div class="image">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>" alt="" />
						</div>
						<?php endif; ?>

						<?php if(!empty( $settings['text'] )) : ?>
						<div class="text"><?php echo wp_kses($settings['text'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
						<!-- Button Box -->
						<div class="button-box">
							<a class="btn-style-five theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
								<div class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
									 <i class="fas fa-arrow-circle-right fa-fw"></i></span>
									<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
									 <i class="fas fa-arrow-circle-right fa-fw"></i></span>
								</div>
							</a>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($settings['style'] == 'style2' ) : ?>
	<section class="about-one"
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"
		<?php endif; ?>
	>
		<div class="container">
			<div class="row clearfix">
				<!-- Image Column -->
				<div class="about-one_image-column col-lg-6 col-md-12 col-sm-12">
					<div class="about-one_image-inner">
						<div class="row clearfix">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<?php if(!empty( $settings['image1']['id'] )) : ?>
								<div class="image">
									<img src="<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>" alt="" />
								</div>
								<?php endif; ?>

								<?php if(!empty( $settings['image2']['id'] )) : ?>
								<div class="image">
									<img src="<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>" alt="" />
								</div>
								<?php endif; ?>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<?php if(!empty( $settings['image3']['id'] )) : ?>
								<div class="image">
									<img src="<?php echo esc_url(wp_get_attachment_url($settings['image3']['id'])); ?>" alt="" />
								</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<!-- Content Column -->
				<div class="about-one_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="about-one_content-inner">
						<div class="sec-title">
							<?php if(!empty( $settings['sub_title'] )) : ?>
							<div class="title"><span class="color-layer"></span> <?php echo wp_kses($settings['sub_title'], true); ?></div>
							<?php endif; ?>

							<?php if(!empty( $settings['title'] )) : ?>
							<h2><?php echo wp_kses($settings['title'], true); ?></h2>
							<?php endif; ?>

							<?php if(!empty( $settings['text'] )) : ?>
							<div class="text"><?php echo wp_kses($settings['text'], true); ?></div>
							<?php endif; ?>
						</div>

						<div class="about-one_list">
							<?php $features_list = $settings['features_list'];
								if(!empty($features_list)){
								$features_list = explode("\n", ($features_list));
							?>
							<ul class="about-one_check split-in-half">
							<?php foreach($features_list as $features): ?>
								<li><?php echo wp_kses($features, true); ?></li>
								<?php endforeach; ?>
							</ul>
							<?php } ?>
						</div>

						<!-- Button Box -->
						<div class="button-box d-flex align-items-center flex-wrap">
							<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
							<a class="btn-style-one theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
								<div class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
										<i>
											<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" />
										</i>
									</span>
									<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
										<i>
											<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" />
										</i>
									</span>
								</div>
							</a>
							<?php endif; ?>

							<?php if(!empty( $settings['call_info_text'] || $settings['call_info_number'] )) : ?>
							<div class="about-one_phone">
								<div class="icon fas fa-phone-volume fa-fw"></div>
								<?php echo wp_kses($settings['call_info_text'], true);?>
								<strong><?php echo wp_kses($settings['call_info_number'], true);?></strong>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php else :
	?>
    <!-- Start of About Page About section
	============================================= -->
	<section id="imi-about-page-about" class="imi-about-page-about-section">
		<div class="container">
			<div class="imi-section-title-2 headline pera-content">
            	<?php if($settings['sub_title']) { ?>
				<div class="imi-subtitle text-uppercase">
					<?php echo wp_kses($settings['sub_title'], true); ?>
				</div>
                <?php } ?>
				<?php if($settings['title']) { ?><h2><?php echo wp_kses($settings['title'], true); ?></h2><?php } ?>
			</div>
			<div class="imi-about-page-about-content">
				<div class="row">
					<div class="col-lg-6">
						<div class="imi-about-page-img-wrapper position-relative">
							<div class="imi-about-page-img">
								<img src="<?php echo esc_url(wp_get_attachment_url($settings['about_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							</div>
							<div class="imi-about-exp-area headline pera-content position-absolute">
								<span class="trophy-icon position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['exp_icon_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
								<?php if($settings['experiance_year']) { ?><h3><?php echo wp_kses($settings['experiance_year'], true); ?></h3><?php } ?>
								<?php if($settings['experiance_title']) { ?><p><?php echo wp_kses($settings['experiance_title'], true); ?></p><?php } ?>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="imi-about-page-text-area pera-content">
							<?php if($settings['text']) { ?>
                            <div class="imi-about-text-desc">
								<?php echo wp_kses($settings['text'], true); ?>
							</div>
                            <?php } ?>
							<div class="imi-about-text-list-exprience d-flex justify-content-between align-items-center flex-wrap">
								<div class="imi-about-feature-list-2 ul-li-block">
									<?php $features_list = $settings['features_list'];
                                        if(!empty($features_list)){
                                        $features_list = explode("\n", ($features_list));
                                    ?>
									<ul>
										 <?php foreach($features_list as $features): ?>
                                            <li><?php echo wp_kses($features, true); ?></li>
                                         <?php endforeach; ?>
									</ul>
                                    <?php } ?>
								</div>
								<div class="imi-about-experince-img position-relative pera-content">
									<img src="<?php echo esc_url(wp_get_attachment_url($settings['experiance_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <?php
		endif;
    }
}