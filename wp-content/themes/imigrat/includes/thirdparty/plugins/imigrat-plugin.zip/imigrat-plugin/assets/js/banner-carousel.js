(function($) {

	"use strict";
	var banner_script_js = function($scope, $) {


		$(document).ready(function () {
			var swiper = new Swiper(".imi-slider-wrapper", {
				slidesPerView: 1,
				spaceBetween: 0,
				loop: true,
				effect: 'fade',
				pagination: false,
				navigation: {
					nextEl: ".swiper-main-next",
					prevEl: ".swiper-main-prev",
				},
			});

		});

		$(document).ready(function () {
			var swiper = new Swiper(".imi-slider-wrapper-3", {
				slidesPerView: 1,
				spaceBetween: 0,
				loop: true,
				effect: 'fade',
				pagination: false,
				navigation: {
					nextEl: ".swiper-main-next",
					prevEl: ".swiper-main-prev",
				},
			});
		});
		var	tpj = jQuery;
			if(window.RS_MODULES === undefined) window.RS_MODULES = {};
			if(RS_MODULES.modules === undefined) RS_MODULES.modules = {};
			RS_MODULES.modules["revslider321"] = {once: RS_MODULES.modules["revslider321"]!==undefined ? RS_MODULES.modules["revslider321"].once : undefined, init:function() {
				window.revapi32 = window.revapi32===undefined || window.revapi32===null || window.revapi32.length===0  ? document.getElementById("rev_slider_32_1") : window.revapi32;
				if(window.revapi32 === null || window.revapi32 === undefined || window.revapi32.length==0) { window.revapi32initTry = window.revapi32initTry ===undefined ? 0 : window.revapi32initTry+1; if (window.revapi32initTry<20) requestAnimationFrame(function() {RS_MODULES.modules["revslider321"].init()}); return;}
				window.revapi32 = jQuery(window.revapi32);
				if(window.revapi32.revolution==undefined){ revslider_showDoubleJqueryError("rev_slider_32_1"); return;}
				revapi32.revolutionInit({
						revapi:"revapi32",
						DPR:"dpr",
						sliderLayout:"fullwidth",
						visibilityLevels:"1240,1024,778,480",
						gridwidth:"1320,1024,778,480",
						gridheight:"790,768,560,500",
						perspective:600,
						perspectiveType:"global",
						editorheight:"790,768,560,500",
						responsiveLevels:"1240,1024,778,480",
						progressBar:{disableProgressBar:true},
						navigation: {
							wheelCallDelay:1000,
							onHoverStop:false,
							bullets: {
								enable:true,
								tmp:"",
								style:"persephone",
								v_offset:30
							}
						},
						viewPort: {
							global:false,
							globalDist:"-200px",
							enable:false
						},
						fallbacks: {
							allowHTML5AutoPlayOnAndroid:true
						},
				});

			}}

	};

	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_banner_1.default', banner_script_js);
    });

})(window.jQuery);