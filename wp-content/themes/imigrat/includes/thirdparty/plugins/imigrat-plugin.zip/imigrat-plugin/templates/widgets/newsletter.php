<?php
extract($args);
$title = apply_filters('widget_title', $instance['title']);

echo wp_kses_post($before_widget); ?>

<div class="privacy-form_box">
    <?php echo wp_kses_post($before_title . $title . $after_title); ?>

    <?php if ($instance['short_description']) { ?>
    <div class="text">
        <?php echo wp_kses_post($instance['short_description']); ?>
    </div>
    <?php } ?>

    <?php if(!empty( $instance['newsletter_shortcode'] )) : ?>
    <div class="privacy-form_box">
        <?php echo do_shortcode($instance['newsletter_shortcode']); ?>
    </div>
    <?php endif; ?>

</div>

<?php

echo wp_kses_post($after_widget);
