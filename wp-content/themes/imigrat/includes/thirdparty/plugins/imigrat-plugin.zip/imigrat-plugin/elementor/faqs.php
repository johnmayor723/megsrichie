<?php

namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Css_Filter;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;


/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Faqs extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_faqs';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Faqs', 'imigrat' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tools';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	public function get_script_depends() {
		wp_register_script( 'faq', YT_URL . 'assets/js/faq.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'faq' ];
	}

	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'style' => ['style2'],
				],
            ]
        );

		$this->add_control(
			'image1',
			[
				'label' => esc_html__('Image 1', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image2',
			[
				'label' => esc_html__('Image 2', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            '_section_slides',
            [
                'label' => __('Faq List', 'elementhelper'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __('Tab Title', 'elementhelper'),
                'default' => __('Tab Title', 'elementhelper'),
                'placeholder' => __('Type title here', 'elementhelper'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'tab_content_info',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'show_label' => false,
                'default' => __('Content Here', 'elementhelper'),
                'placeholder' => __('Type subtitle here', 'elementhelper'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // REPEATER
        $this->add_control(
            'slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(tab_title || "Carousel Item"); #>',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
            '_section_slides_2',
            [
                'label' => __('Faq List 2', 'elementhelper'),
				'condition' => [
					'style' => 'style1',
				],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'label' => __('Tab Title', 'elementhelper'),
                'default' => __('Tab Title', 'elementhelper'),
                'placeholder' => __('Type title here', 'elementhelper'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'tab_content_info',
            [
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'show_label' => false,
                'default' => __('Content Here', 'elementhelper'),
                'placeholder' => __('Type subtitle here', 'elementhelper'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        // REPEATER
        $this->add_control(
            'slides2',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(tab_title || "Carousel Item"); #>',
            ]
        );

        $this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .color-layer',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);
		$this->end_controls_section();

		/**Faq Item Style Style**/
		$this->start_controls_section(
			'loop_item_style',
			[
				'label' => esc_html__('LOOP ITEM STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		//Plus Icon
		$this->add_control(
			'show_loop_plus_icon_style',
			[
				'label'       => __( 'ON/OFF Faq Icon Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_icon_color',
            [
                'label' => __('Faq Icon Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-faq-feed-accordion .accordion-button::after' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .accordion-box .block .icon-outer .icon' => 'color: {{VALUE}}'

                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_plus_icon_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_icon_active_color',
            [
                'label' => __('Faq Icon Active Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-faq-feed-accordion .accordion-button:not(.collapsed)::after' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .accordion-box .block .acc-btn.active .icon-outer .icon-plus' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_plus_icon_style'    => 'yes',
				]
            ]
        );
		//Title
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF Faq Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Faq Title Typography', 'imigrat'),
                'selector' =>
                    '
					{{WRAPPER}} .imi-faq-feed-accordion .accordion-header button,
					{{WRAPPER}} .accordion-box .block .acc-btn
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		// title bg color
		$this->add_control(
			'loop_title_bg_color',
			[
				'label' => __('Faq Title Background Color', 'imigrat'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .imi-faq-feed-accordion .accordion-header button' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .accordion-box .block .acc-btn' => 'background-color: {{VALUE}}'
				],
				'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Faq Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-faq-feed-accordion .accordion-header button' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .accordion-box .block .acc-btn' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_active_title_color',
            [
                'label' => __('Faq Active Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-faq-feed-accordion .accordion-button:not(.collapsed)' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .accordion-box .block .acc-btn.active' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		// active bg color
		$this->add_control(
			'loop_active_bg_color',
			[
				'label' => __('Faq Active Background Color', 'imigrat'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .imi-faq-feed-accordion .accordion-button:not(.collapsed)' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .accordion-box .block .acc-btn.active' => 'background-color: {{VALUE}}'
				],
				'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
			]
		);

		//Content
		$this->add_control(
			'show_loop_content_style',
			[
				'label'       => __( 'ON/OFF Faq Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_content_typography',
                'label' => __('Faq Content Typography', 'imigrat'),
                'selector' =>
                    '
					{{WRAPPER}} .imi-faq-feed-accordion .accordion-body,
					{{WRAPPER}} .accordion-box .block .content p
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_content_color',
            [
                'label' => __('Faq Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-faq-feed-accordion .accordion-body' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .accordion-box .block .content p' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );

		// content bg color
		$this->add_control(
			'loop_content_bg_color',
			[
				'label' => __('Faq Content Background Color', 'imigrat'),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .imi-faq-feed-accordion .accordion-body' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .accordion-box .block .content' => 'background-color: {{VALUE}}'
				],
				'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
			]
		);

		$this->add_control(
            'loop_content_border_color',
            [
                'label' => __('Faq Content border Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-faq-feed-accordion .accordion-body:before' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
	}

	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
	?>
	<?php if($settings['style'] == 'style2' ) : ?>
	<section class="faq-one">

		<?php if(!empty( $settings['image2']['id'] )) : ?>
		<div class="faq-one_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['image2']['id'] )) : ?>
		<div class="faq-one_pattern-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"></div>
		<?php endif; ?>

		<div class="container">
			<!-- Sec Title -->
			<div class="sec-title centered">

				<?php if(!empty( $settings['sub_title'] )) : ?>
				<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
				<?php endif; ?>

				<?php if(!empty( $settings['title'] )) : ?>
				<h2><?php echo wp_kses($settings['title'], true); ?></h2>
				<?php endif; ?>

				<?php if(!empty( $settings['text'] )) : ?>
				<div class="text">
					<?php echo wp_kses($settings['text'], true); ?>
				</div>
				<?php endif; ?>
			</div>
			<div class="inner-container">

				<!-- Accordion Box -->
				<ul class="accordion-box">
					<?php foreach ($settings['slides'] as $id => $slide) :
						$active = ($id == 0) ? 'active' : '';
						$current = ($id == 0) ? 'current' : '';
					?>
					<!-- Block -->
					<li class="accordion block">
						<div class="acc-btn <?php echo esc_attr($active); ?>">
							<div class="icon-outer">
								<span class="icon icon-plus fal fa-angle-double-right fa-fw"></span>
							</div><?php echo wp_kses($slide['tab_title'], true); ?></div>
						<div class="acc-content <?php echo esc_attr($current); ?>">
							<div class="content">
								<?php echo wp_kses($slide['tab_content_info'], true); ?>
							</div>
						</div>
					</li>
					<?php endforeach; ?>
				</ul>

			</div>
		</div>
	</section>
	<?php else : ?>
	<section id="imi-faq" class="imi-faq-section">
		<div class="container">
			<div class="imi-section-top-content d-flex flex-wrap justify-content-between align-items-center">
				<div class="imi-section-title-2 headline pera-content">
					<?php if(!empty( $settings['sub_title'] )) : ?>
					<div class="imi-subtitle text-uppercase">
						<?php echo wp_kses($settings['sub_title'], true); ?>
					</div>
					<?php endif; ?>

					<?php if(!empty( $settings['title'] )) : ?>
					<h2><?php echo wp_kses($settings['title'], true); ?></h2>
					<?php endif; ?>
				</div>

				<?php if(!empty( $settings['text'] )) : ?>
				<div class="imi-title-top-text pera-content">
					<p><?php echo wp_kses($settings['text'], true); ?></p>
				</div>
				<?php endif; ?>

			</div>
			<div class="imi-faq-content">
				<div class="row">
					<div class="col-lg-6">
						<?php $rnad_id = rand( 1245, 6698 ); ?>
						<div class="imi-faq-feed-accordion">
							<div class="accordion" id="accordionExample<?php print esc_attr( $rnad_id );?>">
								<?php foreach ($settings['slides'] as $id => $slide) :
									// active class
									$collapsed_tab = ($id == 0) ? 'collapsed' : '';
									$area_expanded = ($id == 0) ? 'true' : 'false';
									$active_show_tab = ($id == 0) ? 'show' : '';
								?>
								<div class="accordion-item faq_bg headline pera-content wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
									<h2 class="accordion-header" id="headingOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>">
										<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>" aria-expanded="<?php echo esc_attr($area_expanded); ?>" aria-controls="collapseOne">
											<?php echo wp_kses($slide['tab_title'], true); ?>
										</button>
									</h2>
									<div id="collapseOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>" class="accordion-collapse collapse <?php echo esc_attr($active_show_tab); ?>" aria-labelledby="headingOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>" data-bs-parent="#accordionExample<?php print esc_attr( $rnad_id );?>">
										<div class="accordion-body">
											<?php echo wp_kses($slide['tab_content_info'], true); ?>
										</div>
									</div>
								</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<?php $rnad_id = rand( 1245, 6698 ); ?>
						<div class="imi-faq-feed-accordion">
							<div class="accordion" id="accordionExample<?php print esc_attr( $rnad_id );?>">
								<?php foreach ($settings['slides2'] as $id => $slide) :
									// active class
									$collapsed_tab = ($id == 0) ? 'collapsed' : '';
									$area_expanded = ($id == 0) ? 'true' : 'false';
									$active_show_tab = ($id == 0) ? 'show' : '';
								?>
								<div class="accordion-item faq_bg headline pera-content wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
									<h2 class="accordion-header" id="headingOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>">
										<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>" aria-expanded="<?php echo esc_attr($area_expanded); ?>" aria-controls="collapseOne">
											<?php echo wp_kses($slide['tab_title'], true); ?>
										</button>
									</h2>
									<div id="collapseOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>" class="accordion-collapse collapse <?php echo esc_attr($active_show_tab); ?>" aria-labelledby="headingOne<?php print esc_attr( $rnad_id );?>-<?php echo esc_attr( $id ); ?>" data-bs-parent="#accordionExample<?php print esc_attr( $rnad_id );?>">
										<div class="accordion-body">
											<?php echo wp_kses($slide['tab_content_info'], true); ?>
										</div>
									</div>
								</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
		endif;
	}
}