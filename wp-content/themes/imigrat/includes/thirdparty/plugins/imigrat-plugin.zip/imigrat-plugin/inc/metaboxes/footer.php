<?php

//

// Create a section

CSF::createSection( $prefix, [

    'title'  => esc_html__( "Imigrat footer Settings", "imigrat-plugin" ),

    'fields' => [

        [

            'id'      => 'footer_source_type',

            'type'    => 'button_set',

            'title'   => esc_html__( 'Footer Source Type', 'imigrat-plugin' ),

            'options' => [

                'd' => esc_html__( 'Default', 'imigrat-plugin' ),

                'e' => esc_html__( 'Elementor', 'imigrat-plugin' ),

            ],

            'default' => '',

        ],

        [
            'id'         => 'footer_elementor_template',
            'type'       => 'select',
            'title'      => __( 'Template', 'viral-buzz' ),
            'options'    => 'posts',
            'query_args' => [
                'post_type'      => ['elementor_library'],
                'posts_per_page' => -1,
                'orderby'        => 'title',
                'order'          => 'DESC',
            ],
            'dependency' => ['footer_source_type', '==', 'e'],
        ],

        [
            'id'         => 'footer_style_settings',
            'type'       => 'image_select',
            'title'      => esc_html__( 'Choose Footer Styles', 'imigrat-plugin' ),
            'options'    => [

                'footer_v1' => get_template_directory_uri() . '/assets/images/redux/footer/footer1.png',
                'footer_v2' => get_template_directory_uri() . '/assets/images/redux/footer/footer2.png',
                'footer_v3' => get_template_directory_uri() . '/assets/images/redux/footer/footer3.png',
                'footer_v4' => get_template_directory_uri() . '/assets/images/redux/footer/footer4.png',
                'footer_v5' => get_template_directory_uri() . '/assets/images/redux/footer/footer5.png',
                'footer_v6' => get_template_directory_uri() . '/assets/images/redux/footer/footer6.png',
            ],
            'dependency' => [ [ 'footer_source_type', '==', 'd' ] ],
        ],

    ],

] );
