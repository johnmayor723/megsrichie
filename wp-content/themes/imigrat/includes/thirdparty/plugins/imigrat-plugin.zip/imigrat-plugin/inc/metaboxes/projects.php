<?php
//
// Set a unique slug-like ID
$prefix = 'imigrat_meta_projects';
//
// Create a metabox
CSF::createMetabox( $prefix, array(
	'title'      	=> 'Imigrat Project Setting',
	'icon'       	=> 'el el-cogs',
	'position'   	=> 'normal',
	'priority'   	=> 'core',
	'post_type' 	=> array( 'project' ),
	'show_restore'       => false,
	'context'            => 'advanced',
	'nav'                => 'normal',
	'theme'              => 'dark',
	'class'              => '',
) );
//
// Create a section
CSF::createSection($prefix, array(
	'fields' => array(
		array(
			'id'    => 'dimension',
			'type'  => 'select',
			'title' => esc_html__( 'Choose the Extra width and Extra height', 'imigrat-plugin' ),
			'options'  => array(
				'extra_big_height' => esc_html__( 'Extra Big Height', 'imigrat-plugin' ),
				'extra_height' => esc_html__( 'Extra Height', 'imigrat-plugin' ),
				'medium_height' => esc_html__( 'Medium Height', 'imigrat-plugin' ),
				'normal_height' => esc_html__( 'Normal Height', 'imigrat-plugin' ),
			),
			'default'  => 'normal_height',
		),		
	)
));
