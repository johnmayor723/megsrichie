<?php

// Control core classes for avoid errors


//
// Create a widget 1
//
CSF::createWidget('yt_about_company_three', array(
    'title'       => esc_html__('YT About Company Three', 'imigrat-plugin'),
    'classname'   => 'yt-about-company-three',
    'description' => esc_html__('Show about the company', 'imigrat-plugins'),
    'fields'      => array(
        array(
            'id'      => 'widget_logo_img',
            'type'    => 'media',
            'title'   => esc_html__( 'Logo', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'content2',
            'type'    => 'textarea',
            'title'   => esc_html__( 'Content', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'widget_author_name',
            'type'    => 'text',
            'title'   => 'Author Name',
        ),
		array(
            'id'      => 'widget_email_address',
            'type'    => 'text',
            'title'   => 'Author Email Address',
        ),
	)
));

//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_about_company_three') ) {
    function yt_about_company_three($args, $instance) {

        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/about-company-3.php';
    }
}
