<?php
namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Testimonials extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */

	public function get_name() {
		return 'imigrat_testimonials';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Testimonials ', 'imigrat' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial-carousel';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	public function get_script_depends() {
		wp_register_script( 'testimonial-carousel', YT_URL . 'assets/js/testimonial-carousel.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'testimonial-carousel' ];
	}

	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// design style section
		$this->start_controls_section(
			'design_style_section',
			[
				'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
			]
		);

		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat'),
					'4' => esc_html__( 'Style Four ', 'imigrat'),
					'5' => esc_html__( 'Style Five ', 'imigrat'),
					'6' => esc_html__( 'Style Six ', 'imigrat'),
				),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1','2','3'],
				],
            ]
        );

		$this->add_control(
			'bg_image',
			[
			  	'label' => __( 'BG Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => '1',
				],
			]
	    );
		$this->add_control(
			'feature_image',
			[
			  	'label' => __( 'BG Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['2','3']
				],
			]
	    );
		$this->add_control(
			'shape_image1',
			[
			  	'label' => __( 'Shape Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['2','3']
				],
			]
	    );
		$this->add_control(
			'shape_image2',
			[
			  	'label' => __( 'Shape Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['2','3']
				],
			]
	    );

		$this->end_controls_section();

		$this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['2','3','5','6']
				],

			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['2','3','5','6']
				],

			]
		);

		// text
		$this->add_control(
			'text',
			[
				'label' => esc_html__('Text', 'imigrat'),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et', 'imigrat'),
				'condition' => [
					'layout_control' => ['5','6'],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'layout_control' => ['5'],
				],
            ]
        );

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'testimonials',
			[
				'label' => esc_html__( 'Imigrat Testimonials ', 'imigrat' ),
			]
		);

		$this->add_control(
			'col_grid',
			[
				'label'   => esc_html__( 'Choose Column', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'three',
				'options' => array(
					'one' => esc_html__( 'One Column Grid ', 'imigrat'),
					'two'  => esc_html__( 'Two Column Grid', 'imigrat' ),
					'three'  => esc_html__( 'Three Column Grid', 'imigrat' ),
					'four'  => esc_html__( 'Four Column Grid', 'imigrat' ),
					'five'  => esc_html__( 'Six Column Grid', 'imigrat' ),
				),
				'condition'   => [ 'layout_control'  =>  '4' ]
			]
		);

		$this->add_control(
            'text_limit',
            [
                'label'   => esc_html__( 'Text Limit', 'greenture' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 6,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
		$this->add_control(
			'query_number',
			[
				'label'   => esc_html__( 'Number of post', 'imigrat' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
			]
		);
		$this->add_control(
			'query_orderby',
			[
				'label'   => esc_html__( 'Order By', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => esc_html__( 'Date', 'imigrat' ),
					'title'      => esc_html__( 'Title', 'imigrat' ),
					'menu_order' => esc_html__( 'Menu Order', 'imigrat' ),
					'rand'       => esc_html__( 'Random', 'imigrat' ),
				),
			]
		);
		$this->add_control(
			'query_order',
			[
				'label'   => esc_html__( 'Order', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => array(
					'DESC' => esc_html__( 'DESC', 'imigrat' ),
					'ASC'  => esc_html__( 'ASC', 'imigrat' ),
				),
			]
		);
		$this->add_control(
            'query_category',
			[
			  'type' => Controls_Manager::SELECT,
			  'label' => esc_html__('Category', 'imigrat'),
			  'label_block' => true,
			  'options' => get_testimonials_categories()
			]
		);
		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-testimonial-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-testimonial-section-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-testimonial-section-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-testimonial-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-testimonial-section-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-testimonial-section-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
						{{WRAPPER}} .imi-testimonial-section,
						{{WRAPPER}} .imi-testimonial-section-2,
						{{WRAPPER}} .imi-testimonial-section-3',
			]
		);
		$this->end_controls_section();

		//Small Title Style
		$this->start_controls_section(
			'small_title_style',
			[
				'label' => esc_html__( 'Small Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => ['2','3']
				],
			]
		);
		$this->add_responsive_control(
            'small_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'small_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'small_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle
						',
			]
		);

		$this->add_control(
			'small_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'small_title_typography',
				'label' => __('Typography', 'cleanex'),
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'small_title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'small_title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);

		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => ['2','3']
				],
			]
		);

		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
						{{WRAPPER}} .imi-section-title-2 h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
					{{WRAPPER}} .imi-section-title-2 h2
				',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
						{{WRAPPER}} .imi-section-title-2 h2',
			]
		);
		$this->end_controls_section();


		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('Loop Content Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		//Content Style
		$this->add_control(
			'show_loop_content_style',
			[
				'label'       => __( 'ON/OFF Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_content_typography',
                'label' => __('Content Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-testimonial-slider-item .testimonial-desc,
					{{WRAPPER}} .imi-testimonial-slider-content-2 .imi-testimonial-slider-item-2 .testimonial-text
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_content_color',
            [
                'label' => __('Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-slider-item .testimonial-desc' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-slider-content-2 .imi-testimonial-slider-item-2 .testimonial-text' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );

		//Title Style
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-testimonial-slider-item .testimonial-author h3,
					 {{WRAPPER}} .imi-testimonial-slider-content-2 .imi-testimonial-slider-item-2 .testimonial-author .author-text p
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-slider-item .testimonial-author h3' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-slider-content-2 .imi-testimonial-slider-item-2 .testimonial-author .author-text p' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );

		//Designation Style
		$this->add_control(
			'show_loop_designation_style',
			[
				'label'       => __( 'ON/OFF Designation Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_designation_typography',
                'label' => __('Designation Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-testimonial-slider-item .testimonial-author span,
					 {{WRAPPER}} .imi-testimonial-slider-content-2 .imi-testimonial-slider-item-2 .testimonial-author .author-text span
					',
                'separator' => 'before',
				'condition'             => [
					'show_loop_designation_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_designation_color',
            [
                'label' => __('Designation Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-slider-item .testimonial-author span' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-slider-content-2 .imi-testimonial-slider-item-2 .testimonial-author .author-text span' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_designation_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		//swiper pagination Style
		$this->start_controls_section(
			'loop_pagination_style',
			[
				'label' => esc_html__('Bullet Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => ['2','3']
				]
			]
		);
		$this->add_control(
			'show_loop_pagination_btn_style',
			[
				'label'       => __( 'ON/OFF Bullet Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_pagination_btn_color',
            [
                'label' => __('Bullet Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_pagination_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_pagination_btn_hover_color',
            [
                'label' => __('Bullet Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .swiper-pagination-bullet:hover' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_pagination_btn_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		//Arrow Button Style
		$this->start_controls_section(
			'loop_arrow_style',
			[
				'label' => esc_html__('Loop Next Prev Style Setting', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => '1'
				]
			]
		);
		$this->add_control(
			'show_loop_arrow_btn_style',
			[
				'label'       => __( 'ON/OFF Arrow Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_arrow_btn_bgcolor',
            [
                'label' => __('Arrow Background Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-next' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-prev' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_arrow_btn_color',
            [
                'label' => __('Arrow Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-next' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-prev' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_arrow_btn_hover_bgcolor',
            [
                'label' => __('Arrow Background Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-next:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-prev:hover' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_arrow_btn_hover_color',
            [
                'label' => __('Button Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-next:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-testimonial-content-area .next-prev-btn .swiper-button-prev:hover' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();


	}
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');
        $paged = imigrat_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;
		$this->add_render_attribute( 'wrapper', 'class', 'templatepath-imigrat' );
		$layout = $settings[ 'layout_control' ];

		$grid_col = $settings[ 'col_grid' ];
		if( $grid_col == 'one' ){
			$classes = 'col-lg-12 col-md-12 col-sm-12';
		}elseif( $grid_col == 'two' ){
			$classes = 'col-lg-6 col-md-6 col-sm-12';
		}elseif( $grid_col == 'three' ){
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}elseif( $grid_col == 'four' ){
			$classes = 'col-lg-3 col-md-6 col-sm-12';
		}elseif( $grid_col == 'six' ){
			$classes = 'col-lg-2 col-md-6 col-sm-12';
		}else{
			$classes = 'col-lg-4 col-md-6 col-sm-12';
		}

		$args = array(
			'post_type'      => 'testimonials',
			'posts_per_page' => imigrat_set( $settings, 'query_number' ),
			'orderby'        => imigrat_set( $settings, 'query_orderby' ),
			'order'          => imigrat_set( $settings, 'query_order' ),
			'paged'         => $paged
		);
		if( imigrat_set( $settings, 'query_category' ) ) $args['testimonials_cat'] = imigrat_set( $settings, 'query_category' );
		$query = new \WP_Query( $args );
		if ( $query->have_posts() )
		{
	?>

    <?php if( $layout == 6 ):?>
	<section class="testimonial-two">
		<div class="container">
			<!-- Sec Title Three -->
			<div class="sec-title-three centered">

				<?php if(!empty( $settings['sub_title'] )) : ?>
				<div class="title"><?php echo wp_kses($settings['sub_title'], true);?></div>
				<?php endif;?>

				<?php if(!empty( $settings['title'] )) : ?>
				<h2><?php echo wp_kses($settings['title'], true);?></h2>
				<?php endif;?>

				<?php if(!empty( $settings['text'] )) : ?>
				<div class="text"><?php echo wp_kses($settings['text'], true);?></div>
				<?php endif;?>

			</div>
			<div class="position-relative">
				<div class="imi-testimonial-slider-h5 swiper">
					<div class="swiper-wrapper">
						<?php
							while ( $query->have_posts() ) : $query->the_post();
							$imigrat_testimonials_meta = get_post_meta( get_the_ID(), 'imigrat_meta_testimonials', true );
						?>
						<div class="swiper-slide">
							<div class="testimonial-block_two">
								<div class="testimonial-block_two-inner">
									<div class="upper-box">
										<div class="d-flex align-items-center">
											<?php if(has_post_thumbnail()) : ?>
											<div class="image">
												<?php the_post_thumbnail('imigrat_206x261'); ?>
											</div>
											<?php endif;?>
											<div class="author-info">
												<div class="quote fas fa-quote-right fa-fw"></div>
												<h6><?php the_title(); ?></h6>
												<?php if(!empty( $imigrat_testimonials_meta['test_designation'] )) : ?>
												<div class="designation">
													<?php echo wp_kses($imigrat_testimonials_meta['test_designation'], true ); ?>
												</div>
												<?php endif;?>
											</div>
										</div>
									</div>
									<div class="lower-box">
										<div class="text"><?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?></div>
									</div>
								</div>
							</div>
						</div>
						<?php
							endwhile;
						?>
					</div>

					<div class="next-prev-btn">
						<div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
						<div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
					</div>

				</div>
			</div>

		</div>
	</section>
    <?php elseif( $layout == 5 ):?>
	<section class="testimonial-one">
		<div class="container">
			<div class="row clearfix">
				<!-- Title Column -->
				<div class="title-column col-lg-4 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="sec-title-two light">
							<?php if(!empty( $settings['sub_title'] )) : ?>
							<div class="title"><?php echo wp_kses($settings['sub_title'], true);?></div>
							<?php endif;?>

							<?php if(!empty( $settings['title'] )) : ?>
							<h2><?php echo wp_kses($settings['title'], true);?></h2>
							<?php endif;?>

							<?php if(!empty( $settings['text'] )) : ?>
							<div class="text"><?php echo wp_kses($settings['text'], true);?></div>
							<?php endif;?>
						</div>

						<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
						<div class="button-box">
							<a class="btn-style-four theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
								<div class="btn-wrap">
									<span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
										 <i class="fas fa-arrow-circle-right fa-fw"></i></span>
									<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
										 <i class="fas fa-arrow-circle-right fa-fw"></i></span>
								</div>
							</a>
						</div>
						<?php endif;?>
					</div>
				</div>
				<!-- Carousel Column -->
				<div class="carousel-column col-lg-8 col-md-12 col-sm-12">
					<div class="inner-column">

						<div class="imi-testimonial-slider-3 swiper">
							<div class="swiper-wrapper">
								<?php
									while ( $query->have_posts() ) : $query->the_post();
									$imigrat_testimonials_meta = get_post_meta( get_the_ID(), 'imigrat_meta_testimonials', true );
								?>
								<div class="swiper-slide">
									<div class="testimonial-block_one">
										<div class="testimonial-block_one-author">
											<?php if(has_post_thumbnail()) : ?>
											<div class="testimonial-block_one-author_image">
												<?php the_post_thumbnail('imigrat_64x64'); ?>
											</div>
											<?php endif;?>
											<strong><?php the_title(); ?></strong>
											<?php if(!empty( $imigrat_testimonials_meta['test_designation'] )) : ?>
											<?php echo wp_kses($imigrat_testimonials_meta['test_designation'], true ); ?>
											<?php endif;?>
										</div>
										<div class="testimonial-block_one-inner">
											<div class="testimonial-block_one-text"><span class="quote fas fa-quote-left fa-fw"></span>
												<?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?>
											</div>
											<div class="big-quote fas fa-quote-right fa-fw"></div>
										</div>
									</div>
								</div>
								<?php endwhile;?>
							</div>
							<div class="swiper-pagination"></div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>
    <?php elseif( $layout == 4 ):?>

    <!-- Start of Testimonial Feed section
	============================================= -->
	<section id="imi-testimonial-feed" class="imi-testimonial-feed-section inner-page-padding">
		<div class="container">

			<div class="imi-testimonial-feed-content">
				<div class="row justify-content-center">
					<?php
						while ( $query->have_posts() ) : $query->the_post();
						$imigrat_testimonials_meta = get_post_meta( get_the_ID(), 'imigrat_meta_testimonials', true );
					?>
                    <div class="<?php echo esc_attr( $classes );?>">
						<div class="imi-testimonial-feed-item">
							<div class="qt-icon">
								<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icon/qt2.png" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
							</div>
							<div class="testimonial-text">
								<?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?>
							</div>
							<div class="testimonial-author d-flex align-items-center">
								<div class="author-img">
									<?php the_post_thumbnail('imigrat_44x44'); ?>
								</div>
								<div class="author-text headline">
									<h4><?php the_title(); ?></h4>
									<span><?php echo wp_kses($imigrat_testimonials_meta['test_designation'], true ); ?></span>
								</div>
							</div>
						</div>
					</div>
                    <?php endwhile; ?>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Testimonial Feed section
	============================================= -->

	<?php elseif( $layout == 3 ):?>

    <!-- Start of Testimonial section
	============================================= -->
	<section id="imi-testimonial-3" class="imi-testimonial-section-3 position-relative">
		<?php if($settings['shape_image1']['id']){ ?>
        <span class="imi-visa-category-shape3 position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
		<?php } ?>
        <div class="container">
			<div class="imi-testimonial-content-3">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<div class="imi-testimonial-img-2 position-relative">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							<div class="imi-testimonial-shape1 position-absolute">
								<img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							</div>
						</div>
					</div>

					<div class="col-lg-6">
						<div class="imi-testimonial-slider-content-2 position-relative">
							<div class="imi-section-title-2 headline pera-content">
								<?php if($settings['sub_title']) { ?>
								<div class="imi-subtitle text-uppercase">
									<?php echo wp_kses($settings['sub_title'], true);?>
								</div>
                                <?php } ?>
								<?php if($settings['title']) { ?><h2><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
							</div>
							<div class="imi-testimonial-slider-area-2">
								<div class="imi-testimonial-slider-2 swiper">
									<div class="swiper-wrapper">
										<?php
                                            while ( $query->have_posts() ) : $query->the_post();
											$imigrat_testimonials_meta = get_post_meta( get_the_ID(), 'imigrat_meta_testimonials', true );
                                        ?>
                                        <div class="swiper-slide">
											<div class="imi-testimonial-slider-item-2">
												<div class="qoute-icon">
													<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icon/qt2.png" alt="">
												</div>
												<div class="testimonial-text">
													<?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?>
												</div>
												<div class="testimonial-author d-flex align-items-center">
													<div class="author-img">
														<?php the_post_thumbnail('imigrat_105x90'); ?>
													</div>
													<div class="author-text pera-content">
														<p><?php the_title();?></p>
														<span><?php echo wp_kses($imigrat_testimonials_meta['test_designation'], true ); ?></span>
													</div>
												</div>
											</div>
										</div>
										<?php endwhile; ?>
									</div>
								</div>
								<div class="swiper-paginations_3"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Testimonial section
	============================================= -->

	<?php elseif( $layout == 2 ):?>
    <!-- Start of Testimonial section
	============================================= -->
	<section id="imi-testimonial-2" class="imi-testimonial-section-2 position-relative">
		<span class="imi-visa-category-shape2 position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span>
		<div class="container">
			<div class="imi-testimonial-content-2">
				<div class="row align-items-center">
					<div class="col-lg-6 wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1000ms">
						<div class="imi-testimonial-img-2 position-relative">
							<img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							<div class="imi-testimonial-shape1 position-absolute">
								<img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							</div>
						</div>
					</div>
					<div class="col-lg-6 wow fadeInRight" data-wow-delay="400ms" data-wow-duration="1000ms">
						<div class="imi-testimonial-slider-content-2 position-relative">
							<div class="imi-section-title-2 headline-2 pera-content">
                            	<?php if($settings['sub_title']) { ?>
								<div class="imi-subtitle text-uppercase">
									<?php echo wp_kses($settings['sub_title'], true);?>
								</div>
                                <?php } ?>
								<?php if($settings['title']) { ?><h2><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
							</div>
							<div class="imi-testimonial-slider-area-2">
								<div class="imi-testimonial-slider-2 swiper">
									<div class="swiper-wrapper">
										<?php
                                            while ( $query->have_posts() ) : $query->the_post();
											$imigrat_testimonials_meta = get_post_meta( get_the_ID(), 'imigrat_meta_testimonials', true );
                                        ?>
										<div class="swiper-slide">
											<div class="imi-testimonial-slider-item-2">
												<div class="qoute-icon">
													<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/icon/qt1.png" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
												</div>
												<div class="testimonial-text">
													<?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?>
												</div>
												<div class="testimonial-author d-flex align-items-center">
													<div class="author-img">
														<?php the_post_thumbnail('imigrat_105x90'); ?>
													</div>
													<div class="author-text pera-content">
														<p><?php the_title();?></p>
														<span><?php echo wp_kses($imigrat_testimonials_meta['test_designation'], true ); ?></span>
													</div>
												</div>
											</div>
										</div>
                                        <?php endwhile; ?>
									</div>
								</div>
								<div class="swiper-paginations_3"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Testimonial section
	============================================= -->

    <?php else: ?>
    <!-- Start of Testimonial section
	============================================= -->
	<section id="imi-testimonial" class="imi-testimonial-section" data-background="<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>">
		<div class="container">
			<div class="imi-testimonial-content d-flex justify-content-end">
				<div class="imi-testimonial-content-area position-relative">
					<div class="imi-testimonial-slider swiper">
						<div class="swiper-wrapper">
							 <?php
                                while ( $query->have_posts() ) : $query->the_post();
								$imigrat_testimonials_meta = get_post_meta( get_the_ID(), 'imigrat_meta_testimonials', true );
                            ?>
							<div class="swiper-slide">
								<div class="imi-testimonial-slider-item d-flex align-items-center">
									<div class="testimonial-img">
										<?php the_post_thumbnail('imigrat_157x157'); ?>
									</div>
									<div class="testimonial-text-area">
										<div class="quote-icon">
											<img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/logo/qt.png" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
										</div>
										<div class="testimonial-desc">
											<?php print wp_trim_words( get_the_content(), $settings['text_limit'], '' );?>
										</div>
										<div class="testimonial-author-arrow d-flex justify-content-between align-items-center">
											<div class="testimonial-author headline">
												<h3><?php the_title();?></h3>
												<span><?php echo wp_kses($imigrat_testimonials_meta['test_designation'], true ); ?></span>
											</div>
										</div>
									</div>
								</div>
							</div>
                            <?php endwhile; ?>
						</div>
					</div>
					<div class="next-prev-btn">
						<div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
						<div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Testimonial section
	============================================= -->

	<?php endif;?>
	<?php }
	wp_reset_postdata();

	}
}