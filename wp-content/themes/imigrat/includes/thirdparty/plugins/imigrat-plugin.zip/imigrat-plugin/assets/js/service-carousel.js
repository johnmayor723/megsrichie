(function($) {
	
	"use strict";
	var service_script_js = function($scope, $) {
		
		
		$(document).ready(function () {
			var swiper = new Swiper(".imi-service-slider", {
				slidesPerView: 3,
				spaceBetween: 35,                  
				loop: true,
				pagination: false,
				navigation: {
					nextEl: ".swiper-button-next",
					prevEl: ".swiper-button-prev",
				},
				breakpoints: {
					1500: {
						slidesPerView: 3,
					},
					1199: {
						slidesPerView: 3,
					},
					991: {
						slidesPerView: 3,
					},
					920: {
						slidesPerView: 2,
					},
					767: {
						slidesPerView: 2,
					},
					600: {
						slidesPerView: 2,
					},
					500: {
						slidesPerView: 1,
					}
				},
			});
		});
		
	};
	
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_services_carousel.default', service_script_js);
    });	

})(window.jQuery);