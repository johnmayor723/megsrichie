<?php
namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;
use \Elementor\Group_Control_Background;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Client_Section extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_client_section';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Clients', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-parallax';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return ['imigrat'];
    }

    public function get_script_depends() {
        wp_register_script( 'client-carousel-script', YT_URL . 'assets/js/client-carousel.js', ['elementor-frontend'], '1.0.0', true );
        return ['client-carousel-script'];
    }

    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'client_section',
            [
                'label' => esc_html__( 'Imigrat Clients', 'imigrat' ),
            ]
        );
        $this->add_control(
            'layout_control',
            [
                'label'       => esc_html__( 'Layout Style', 'imigrat' ),
                'label_block' => true,
                'type'        => Controls_Manager::SELECT,
                'default'     => '1',
                'options'     => [
                    '1' => esc_html__( 'Style One ', 'imigrat' ),
                    '2' => esc_html__( 'Style Two ', 'imigrat' ),
                    '3' => esc_html__( 'Style Three ', 'imigrat' ),
                ],
            ]
        );
        $this->add_control(
            'sub_title',
            [
                'label'       => __( 'Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic'     => [
                    'active' => true,
                ],
                'placeholder' => __( 'Enter your Title', 'imigrat' ),
                'condition'   => [
                    'layout_control' => '1',
                ],
            ]
        );
        //Our Slider
        $repeater = new Repeater();
        $repeater->add_control(
            'block_img',
            [
                'name'    => 'block_img',
                'label'   => esc_html__( 'Slide BG Image ', 'imigrat' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );
        $this->add_control(
            'slides',
            [
                'label'  => __( 'Add Item', 'imigrat' ),
                'type'   => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
        $this->end_controls_section();

        /** Style Tab **/
        $this->register_style_background_controls();
    }

    /************************************************************************
    Tab Style Start
     *************************************************************************/

    protected function register_style_background_controls() {

        //General Style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__( 'GENERAL SETTING', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-sponsor-slider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-sponsor-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'general_bgtype',
                'label'    => __( 'Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .imi-sponsor-slider',
            ]
        );
        $this->end_controls_section();

        /**Title Style**/
        $this->start_controls_section(
            'title_style',
            [
                'label' => esc_html__( 'TITLE STYLE SETTING', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'show_title_style',
            [
                'label'        => __( 'ON/OFF  Title Style', 'imigrat' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'imigrat' ),
                'label_off'    => esc_html__( 'Hide', 'imigrat' ),
                'return_value' => 'yes',
                'default'      => 'no',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'title_typography',
                'label'     => __( 'Title Typography', 'imigrat' ),
                'selector'  =>
                '{{WRAPPER}} .imi-sponsor-title h3',
                'separator' => 'before',
                'condition' => [
                    'show_title_style' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label'     => __( 'Title Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-sponsor-title h3' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
                'condition' => [
                    'show_title_style' => 'yes',
                ],
            ]
        );
        $this->end_controls_section();

    }

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html( 'post' );
        $layout = $settings['layout_control'];
        ?>

    <?php if ( $layout == 3 ): ?>
	<div class="imi-sponsor-slider_two" class="imi-sponsor-slider-section">
		<div class="container">
			<div class="inner-container">
				<div class="swiper imi-sponsor-slider-area_two">
					<div class="swiper-wrapper">
						<?php foreach ( $settings['slides'] as $key => $item ): ?>
						<div class="swiper-slide">
							<div class="sponsor-img-item">
								<div class="inner-img">
									<img src="<?php echo esc_url( wp_get_attachment_url( $item['block_img']['id'] ) ); ?>" alt="<?php esc_attr_e( 'Awesome Image', 'imigrat' );?>">
								</div>
							</div>
						</div>
						<?php endforeach;?>
					</div>
				</div>
			</div>
		</div>
	</div>
    <?php elseif ( $layout == 2 ): ?>

    <!-- Start  of Sponsor  section
	============================================= -->
	<section id="imi-sponsor" class="imi-sponsor-section">
		<div class="container">
			<div class="imi-sponsor-content">
				<div class="imi-sponsor-slider-2 swiper">
					<div class="swiper-wrapper">
						<?php foreach ( $settings['slides'] as $key => $item ): ?>
                        <div class="swiper-slide">
							<div class="imi-slider-item">
								<div class="imi-sponsor-item">
									<img src="<?php echo esc_url( wp_get_attachment_url( $item['block_img']['id'] ) ); ?>" alt="<?php esc_attr_e( 'Awesome Image', 'imigrat' );?>">
								</div>
							</div>
						</div>
						<?php endforeach;?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End  of Sponsor  section
	============================================= -->

    <?php else: ?>

    <!-- Start of sponsor Slider section
	============================================= -->
	<div class="imi-sponsor-slider imi-sponsor-slider-section">
		<div class="container">
			<div class="imi-sponsor-title text-uppercase headline">
				<?php if ( $settings['sub_title'] ) {?><h3><?php echo wp_kses( $settings['sub_title'], true ); ?></h3><?php }?>
            </div>
			<div class="swiper imi-sponsor-slider-area">
				<div class="swiper-wrapper">
                	<?php foreach ( $settings['slides'] as $key => $item ): ?>
					<div class="swiper-slide">
						<div class="sponsor-img-item">
							<div class="inner-img">
								<img src="<?php echo esc_url( wp_get_attachment_url( $item['block_img']['id'] ) ); ?>" alt="<?php esc_attr_e( 'Awesome Image', 'imigrat' );?>">
							</div>
						</div>
					</div>
                    <?php endforeach;?>
				</div>
			</div>
		</div>
	</div>
	<!-- End of sponsor Slider section
	============================================= -->
      <?php endif;
    }
}