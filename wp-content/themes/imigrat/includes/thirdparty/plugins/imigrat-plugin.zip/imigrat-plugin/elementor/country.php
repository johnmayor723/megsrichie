<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Country extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_country';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Country', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }


	public function get_script_depends() {
		wp_register_script( 'country-scripts', YT_URL . 'assets/js/country-carousel.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'country-scripts' ];
	}
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'style' => ['style2'],
				],
            ]
        );

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Section Bg Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image1',
			[
				'label' => esc_html__('Image 1', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image2',
			[
				'label' => esc_html__('Image 2', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'style' => ['style2'],
				],
            ]
        );

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'title_section',
            [
                'label' => esc_html__( 'SECTION TITLE', 'imigrat' ),
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'country',
            [
                'label' => esc_html__( 'Imigrat Country', 'imigrat' ),
            ]
        );

		//Our Slider
		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__('Country Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'features_list',
			[
				'label' => esc_html__('Feature List', 'imigrat'),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'imigrat' ),
			]
		);

		$repeater->add_control(
			'ext_link',
			[
				'label' => esc_html__('External Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'slides',
			[
				'label'                 => __('Add Slide Item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();


		/************************************************************************
									Tab Style Start
		*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-country-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-country-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-country-list-item',
			]
		);
		$this->end_controls_section();

		// subtitle Style
		$this->start_controls_section(
			'subtitle_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// sub title color
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}}',
				],
			]
		);

		// subtitle bg color
		$this->add_control(
			'subtitle_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sec-title .color-layer' => 'background-color: {{VALUE}}',
				],
			]
		);

		// typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'label' => esc_html__( 'Typography', 'imigrat' ),
				'selector' => '{{WRAPPER}} .sec-title .title',
			]
		);


		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-country-list-item .country-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-country-list-item .country-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
					{{WRAPPER}} .imi-country-list-item .country-text h3,
					{{WRAPPER}} .sec-title h2
				',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-country-list-item .country-text h3 a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-country-list-item .country-text h3:hover a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-country-list-item .country-text h3',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-country-list-item .country-text h3',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-country-list-item .country-text h3',
			]
		);
		$this->end_controls_section();


		//Feature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'feature_list__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .ul-li ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .country-block_one h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'feature_list_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .ul-li ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .country-block_one h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
					{{WRAPPER}} .ul-li ul,
					{{WRAPPER}} .country-block_one h5
				',
			]
		);

		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Feature List Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-country-list-item .country-text li' => 'color: {{VALUE}};',
					'{{WRAPPER}} .country-block_one h5' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Feature List Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-country-list-item .country-text li:before' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-country-list-item .country-text li:after' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-country-list-item .country-text li',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'feature_list_stroke',
				'selector' => '{{WRAPPER}} .imi-country-list-item .country-text li',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_shadow',
				'selector' => '{{WRAPPER}} .imi-country-list-item .country-text li',
			]
		);

		// text color
		$this->add_control(
			'feature_list_text_color',
			[
				'label' => esc_html__( 'Feature Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .country-block_one .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		// button style
		$this->start_controls_section(
			'btn_style',
			[
				'label' => __( 'BUTTON STYLE', 'imigrat-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// enable button style
		$this->add_control(
			'show_btn_style2',
			[
				'label'       => __( 'ON/OFF Button Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		// button typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_title_typography2',
				'label' => __('Button Text Typography', 'imigrat-plugin'),
				'selector' =>
					'
						{{WRAPPER}} .btn-style-one span,
						{{WRAPPER}} .btn-style-two span,
						{{WRAPPER}} .btn-style-four span,
						{{WRAPPER}} .btn-style-seven span
					',
				'separator' => 'before',
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// border radius
		$this->add_responsive_control(
			'btn_border_radius2',
			[
				'label'              => __( 'Border Radius', 'imigrat-plugin' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .btn-style-one' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-two' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-four' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-seven' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],

				'frontend_available' => true,
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->start_controls_tabs( '_tabs_button-' );

		$this->start_controls_tab(
            '_tab_button_normal',
            [
                'label' => __( 'Normal', 'elementhelper' ),
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
            ]
        );

		// button color
		$this->add_control(
			'btn_title_color2',
			[
				'label' => __( 'Button Text Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven span' => 'color: {{VALUE}}!important',
				],
				'condition' => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg color
		$this->add_control(
			'btn_bg_color2',
			[
				'label' => __( 'Button Background Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
            'button_hover',
            [
                'label' => __( 'Hover', 'elementhelper' ),
            ]
        );

		// button hover color
		$this->add_control(
			'btn_title_hover_color2',
			[
				'label' => __( 'Button Text Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover span' => 'color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg hover color
		$this->add_control(
			'btn_bg_hover_color2',
			[
				'label' => __( 'Button Background Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-one:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-two:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover::before' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();
        $this->end_controls_tabs();

		$this->end_controls_section();

	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if($settings['style'] == 'style2' ) : ?>

		<section class="country-one"
			<?php if(!empty( $settings['bg_image']['id'] )) : ?>
			style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"
			<?php endif; ?>
			>
		<?php if(!empty( $settings['image1']['id'] )) : ?>
		<div class="country-one_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['image2']['id'] )) : ?>
		<div class="country-one_pattern-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['image2']['id'])); ?>)"></div>
		<?php endif; ?>

		<div class="container">
			<div class="sec-title light">
				<div class="d-flex align-items-center justify-content-between flex-wrap">
					<div class="left-box">
						<?php if(!empty( $settings['sub_title'] )) : ?>
						<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
						<?php endif; ?>

						<?php if(!empty( $settings['title'] )) : ?>
						<h2><?php echo wp_kses($settings['title'], true); ?></h2>
						<?php endif; ?>
					</div>
					<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
					<!-- Button Box -->
					<div class="button-box">
						<a class="btn-style-two theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
							<div class="btn-wrap">
								<span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
									<i><img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" /></i></span>
								<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
									<i><img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-1.png" alt="" /></i></span>
							</div>
						</a>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<div class="row clearfix">
				<?php foreach($settings['slides'] as $key => $item):?>
				<div class="country-block_one col-lg-6 col-md-12 col-sm-12">
					<div class="country-block_one-inner">
						<div class="country-block_one-content">
							<?php if(!empty( $item['image']['id'] )) : ?>
							<div class="flag-icon">
								<img src="<?php echo esc_url(wp_get_attachment_url($item['image']['id'])); ?>" alt="" />
							</div>
							<?php endif; ?>

							<?php if(!empty( $item['title'] )) : ?>
							<h5><?php echo wp_kses($item['title'], true); ?></h5>
							<?php endif; ?>

							<?php if(!empty( $item['features_list'] )) : ?>
							<div class="text"><?php echo wp_kses($item['features_list'], true); ?></div>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<?php endforeach;?>

			</div>
		</div>
	</section>
	<?php else : ?>

    <div class="imi-country-list-slider-area position-relative">
        <div class="imi-country-list-slider swiper">
            <div class="swiper-wrapper">
                <?php foreach($settings['slides'] as $key => $item):?>
                <div class="swiper-slide">
                    <div class="imi-country-list-item d-flex align-items-center">
                        <div class="country-flag">
                            <img src="<?php echo esc_url(wp_get_attachment_url($item['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
                        </div>
                        <div class="country-text headline-2 ul-li">
							<?php if(!empty( $item['ext_link']['url'] || $item['title'] )) : ?>
                            <h3>
								<a href="<?php echo esc_url($item['ext_link']['url']);?>">
								<?php echo wp_kses($item['title'], true);?></a>
							</h3>
							<?php endif; ?>

                            <?php $features_list = $item['features_list'];
								if(!empty($features_list)){
								$features_list = explode("\n", ($features_list));
							?>
                            <ul>
                                <?php foreach($features_list as $features): ?>
                                <li><?php echo wp_kses($features, true); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php endforeach;?>
            </div>
        </div>
        <div class="swiper-paginations_2"></div>
    </div>

    <?php
		endif;
    }
}