<?php

namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Services_Carousel extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_services_carousel';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Services Carousel', 'imigrat' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-tools';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}
	
	public function get_script_depends() {
		wp_register_script( 'service-carousel-script', YT_URL . 'assets/js/service-carousel.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'service-carousel-script' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'services_carousel',
			[
				'label' => esc_html__( 'Imigrat Services Carousel', 'imigrat' ),
			]
		);
		
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Choose Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'one' => esc_html__( 'Style One', 'imigrat'),
					'two'  => esc_html__( 'Style Two', 'imigrat' ),
				),
			]
		);
		
		$this->add_control(
            'text_limit',
            [
                'label'   => esc_html__( 'Text Limit', 'imigrat' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 6,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
		
		$this->add_control(
            'query_number',
            [
                'label'   => esc_html__( 'Number of post', 'greenture' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 5,
                'min'     => 1,
                'max'     => 100,
                'step'    => 1,
            ]
        );
		
        $this->add_control(
            'query_orderby',
            [
                'label'   => esc_html__( 'Order By', 'greenture' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => array(
                    'date'       => esc_html__( 'Date', 'greenture' ),
                    'title'      => esc_html__( 'Title', 'greenture' ),
                    'menu_order' => esc_html__( 'Menu Order', 'greenture' ),
                    'rand'       => esc_html__( 'Random', 'greenture' ),
                ),
            ]
        );
		
        $this->add_control(
            'query_order',
            [
                'label'   => esc_html__( 'Order', 'greenture' ),
				'label_block' => true,
                'type'    => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => array(
                    'DESC' => esc_html__( 'DESC', 'greenture' ),
                    'ASC'  => esc_html__( 'ASC', 'greenture' ),
                ),
            ]
        );
		
        $this->add_control(
            'query_category',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Category', 'greenture'),
				'label_block' => true,
                'options' => get_service_categories(),
            ]
        );
		
		$this->end_controls_section();
		
		/** Style Tab **/
		$this->register_style_background_controls();
    }
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
	protected function register_style_background_controls()
	{
		
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'GENERAL SETTINGS', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-service-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-service-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-service-content',				
			]
		);

		$this->end_controls_section();
		
		
		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('LOOP CONTENT STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		//Counter Style
		$this->add_control(
			'show_loop_counter_style',
			[
				'label'       => __( 'ON/OFF Counter Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_counter_color',
            [
                'label' => __('Counter Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .service-serial' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_counter_style'    => 'yes',
				]
            ]
        );	
		$this->add_control(
            'loop_counter_bgcolor',
            [
                'label' => __('Counter BG Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .service-serial' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_counter_style'    => 'yes',
				]
            ]
        );
		
		//Icon Style
		$this->add_control(
			'show_loop_icon_style',
			[
				'label'       => __( 'ON/OFF  Icon Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_icon_color',
            [
                'label' => __('Icon Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .imi-service-link a' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_icon_style'    => 'yes',
				]
            ]
        );	
		$this->add_control(
            'loop_icon_bgcolor',
            [
                'label' => __('Icon BG Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .imi-service-link a' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_icon_style'    => 'yes',
				]
            ]
        );
		//Title Style
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' => 
                    '{{WRAPPER}} .imi-service-item .imi-service-text h3',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .imi-service-text h3 ' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_hover_color',
            [
                'label' => __('Title Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .imi-service-text h3 a:hover' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_bg_color',
            [
                'label' => __('Title BG Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item .imi-service-text h3' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_bg_hover_color',
            [
                'label' => __('Title BG Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-item:hover .imi-service-text h3:after' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		//Content Style
		$this->add_control(
			'show_loop_content_style',
			[
				'label'       => __( 'ON/OFF  Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_content_typography',
                'label' => __('Content Typography', 'imigrat'),
                'selector' => 
                    '{{WRAPPER}} .service-card-five__text',                 
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_content_color',
            [
                'label' => __('Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .service-card-five__text' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_content_style'    => 'yes',
				]
            ]
        );
		//Arrow Button Style
		$this->add_control(
			'show_loop_arrow_btn_style',
			[
				'label'       => __( 'ON/OFF Arrow Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
            'loop_arrow_btn_bgcolor',
            [
                'label' => __('Arrow Background Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-content .swiper-button-next' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .imi-service-content .swiper-button-prev' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_arrow_btn_color',
            [
                'label' => __('Arrow Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-content .swiper-button-next' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-service-content .swiper-button-prev' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_arrow_btn_hover_bgcolor',
            [
                'label' => __('Arrow Background Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-content .swiper-button-next:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .imi-service-content .swiper-button-prev:hover' => 'background-color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_arrow_btn_hover_color',
            [
                'label' => __('Button Hover Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-service-content .swiper-button-prev:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-service-content .swiper-button-prev:hover' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_arrow_btn_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
		
	}

	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post');

        $paged = imigrat_set($_POST, 'paged') ? esc_attr($_POST['paged']) : 1;

        $this->add_render_attribute( 'wrapper', 'class', 'templatepath-greenture' );
        $args = array(
            'post_type'      => 'service',
            'posts_per_page' => imigrat_set( $settings, 'query_number' ),
            'orderby'        => imigrat_set( $settings, 'query_orderby' ),
            'order'          => imigrat_set( $settings, 'query_order' ),
            'paged'         => $paged
        );

        if( imigrat_set( $settings, 'query_category' ) ) $args['service_cat'] = imigrat_set( $settings, 'query_category' );
        $query = new \WP_Query( $args );		
        if ( $query->have_posts() ) { 
	?>
    
    
		
        <div class="imi-service-content position-relative">
            <div class="imi-service-slider swiper">
                <div class="swiper-wrapper">
					<?php $i = 1; while ( $query->have_posts() ) : $query->the_post(); ?>
                    <?php $imigrat_service_meta = get_post_meta( get_the_ID(), 'imigrat_meta_service', true );?>
                    <div class="swiper-slide">
                        <div class="imi-service-item position-relative">
                            <div class="imi-service-img">
                                <?php the_post_thumbnail('imigrat_365x452'); ?>
                            </div>
                            <div class="service-serial d-flex justify-content-center align-items-center position-absolute">
                                <?php $i = sprintf('%02d', $i); echo $i; ?>
                            </div>
                            <div class="imi-service-text d-flex headline text-uppercase position-absolute">
                                <h3><a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><?php the_title();?></a></h3>
                                <div class="imi-service-link">
                                    <a href="<?php echo esc_url( the_permalink( get_the_id() ) );?>"><i class="far fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $i++; endwhile; ?>
                </div>
            </div>
            <div class="next-prev-btn">
                <div class="swiper-button-prev"><i class="fas fa-arrow-left"></i></div>
                <div class="swiper-button-next"><i class="fas fa-arrow-right"></i></div>
            </div>
        </div>
		<?php }

		wp_reset_postdata();

	}

}