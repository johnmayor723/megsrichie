<?php
if ( ! function_exists( "imigrat_add_metaboxes_codestar" ) ) {
	function imigrat_add_metaboxes_codestar() {
		$directories_array = array(
			'page.php',
			'projects.php',
			'service.php',
			'team.php',
			'testimonials.php',
			'visa.php',
			'country.php',
			'jobs',
		);
		foreach ( $directories_array as $dir ) {
			require_once IMIGRATPLUGIN_PLUGIN_PATH . '/inc/metaboxes/' . $dir;
		}
	}
	imigrat_add_metaboxes_codestar();
}
