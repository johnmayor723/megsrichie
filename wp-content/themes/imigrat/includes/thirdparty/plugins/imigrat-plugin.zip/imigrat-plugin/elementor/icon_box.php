<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Icon_Box extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_icon_box';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Icon Box', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'icon_box',
            [
                'label' => esc_html__( 'Imigrat Icon Box', 'imigrat' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat'),
					'4' => esc_html__( 'Style Four ', 'imigrat'),
				),
			]
		);
		$this->add_control(
			'icon_image',
			[
			  	'label' => __( 'Icon Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['2','4'],
				],
			]
	    );
		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Enter The icons', 'imigrat'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				'condition' => [
					'layout_control'      => ['1','3']
				]

			]

		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),
			]
		);

		$this->add_control(
			'link',
			[
				'label'       => __( 'Link', 'imigrat' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Link', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['4']
				]
			]
		);


		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1','2','4']
				]

			]
		);
		$this->end_controls_section();

	/************************************************************************
								Tab Style Start
	*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-why-choose-us-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-benifit-feature-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-contact-item-box-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-why-choose-us-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-benifit-feature-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-contact-item-box-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_control(
			'shape_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .imi-why-choose-us-section' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .imi-benifit-feature-item' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .imi-contact-item-box-1' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'shape_bg_hover_color',
			[
				'label' => esc_html__( 'Background Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-contact-item-box-1:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .imi-why-choose-us-section:hover' => 'background-color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'icon_style',
			[
				'label' => esc_html__( 'Icon Style', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => ['1','3']
				]
			]
		);
		$this->add_responsive_control(
            'icon__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-contact-item-box-1 .item-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'icon_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-contact-item-box-1 .item-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-contact-item-box-1 .item-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-icon i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'icon_hover_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-contact-item-box-1:hover .item-icon' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-icon i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'icon_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
						{{WRAPPER}} .imi-why-choose-us-ft-list .feature-icon,
						{{WRAPPER}} .imi-contact-item-box-1 .item-icon
				',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-benifit-feature-item h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-contact-item-box-1 .item-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature-block_one h3 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-benifit-feature-item h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-contact-item-box-1 .item-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .feature-block_one h3 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3,
				{{WRAPPER}} .imi-benifit-feature-item h3,
				 {{WRAPPER}} .imi-contact-item-box-1 .item-text,
				 {{WRAPPER}} .feature-block_one h3 a
				',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-benifit-feature-item h3' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-contact-item-box-1 .item-text' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-block_one h3 a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-benifit-feature-item h3:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-contact-item-box-1:hover .item-text' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-block_one h3 a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
						{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3,
						{{WRAPPER}} .imi-benifit-feature-item h3,
						{{WRAPPER}} .imi-contact-item-box-1 .item-text,
						{{WRAPPER}} .feature-block_one h3 a
				',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '
					{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3,
					{{WRAPPER}} .imi-benifit-feature-item h3,
					{{WRAPPER}} .feature-block_one h3 a,
					{{WRAPPER}} .imi-contact-item-box-1 .item-text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
						{{WRAPPER}} .imi-why-choose-us-ft-list .feature-text h3,
						{{WRAPPER}} .imi-benifit-feature-item h3,
						{{WRAPPER}} .feature-block_one h3 a,
						{{WRAPPER}} .imi-contact-item-box-1 .item-text',

			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_control'      => ['1','2', '4']
				]
			]
		);
		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .pera-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .feature-block_one-inner .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .pera-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .feature-block_one-inner .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
						{{WRAPPER}} .pera-content p,
						{{WRAPPER}} .feature-block_one-inner .text,
						{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text
				',
			]
		);
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pera-content p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .feature-block_one-inner .text' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
						{{WRAPPER}} .pera-content p,
						{{WRAPPER}} .feature-block_one-inner .text,
						{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text
				',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
						{{WRAPPER}} .pera-content p,
						{{WRAPPER}} .feature-block_one-inner .text,
						{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text
				',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
					{{WRAPPER}} .pera-content p,
					{{WRAPPER}} .feature-block_one-inner .textp,
					{{WRAPPER}} .imi-benifit-feature-item .imi-bt-feature-icon-text .bt-feature-text
				',
			]
		);
		$this->end_controls_section();

	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$icon = $settings[ 'icon' ];
		$layout = $settings[ 'layout_control' ];
	?>

    <?php if($layout == 4 ): ?>
	<div class="feature-block_one">
		<div class="feature-block_one-inner">
			<?php if(!empty( $settings['icon_image']['id'] )) : ?>
			<div class="feature-block_one-icon">
				<img src="<?php echo esc_url(wp_get_attachment_url($settings['icon_image']['id'])); ?>" alt="" />
			</div>
			<?php endif; ?>

			<?php if(!empty( $settings['title'] || $settings['link']['url'] )) : ?>
			<h3><a href="<?php echo esc_url($settings['link']['url']); ?>">
				<?php echo wp_kses($settings['title'], true); ?></a>
			</h3>
			<?php endif; ?>

			<?php if(!empty( $settings['text'] )) : ?>
			<div class="text"><?php echo wp_kses($settings['text'], true); ?></div>
			<?php endif; ?>
		</div>
	</div>
    <?php elseif($layout == 3 ): ?>

	<div class="imi-contact-item-box-1 text-center">
        <div class="item-icon">
            <?php if( !empty( $icon ) ):?>
                <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
            <?php else:?>
                <i class="fas fa-map-marker-alt"></i>
            <?php endif;?>
        </div>
        <div class="item-text">
            <?php echo wp_kses($settings['title'], true); ?>
        </div>
    </div>

	<?php elseif($layout == 2 ): ?>

    <div class="imi-benifit-feature-item wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1000ms">
        <?php if($settings['title']) { ?><h3 class="bt-feature-title"><?php echo wp_kses($settings['title'], true); ?></h3><?php } ?>
        <div class="imi-bt-feature-icon-text d-flex align-items-center">
            <div class="bt-feature-icon position-relative">
                <img src="<?php echo esc_url(wp_get_attachment_url($settings['icon_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
            </div>
            <?php if($settings['text']) { ?>
            <div class="bt-feature-text">
                <?php echo wp_kses($settings['text'], true); ?>
            </div>
            <?php } ?>
        </div>
    </div>

    <?php else: ?>
    <div class="imi-why-choose-us-ft-list d-flex align-items-center wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
        <div class="feature-icon d-flex align-items-center justify-content-center">
			<?php if( !empty( $icon ) ):?>
                <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
            <?php else:?>
                <i class="fas fa-box"></i>
            <?php endif;?>
        </div>
        <div class="feature-text headline pera-content">
            <h3><?php echo wp_kses($settings['title'], true); ?></h3>
            <p><?php echo wp_kses($settings['text'], true); ?></p>
        </div>
    </div>

    <?php endif;
    }
}