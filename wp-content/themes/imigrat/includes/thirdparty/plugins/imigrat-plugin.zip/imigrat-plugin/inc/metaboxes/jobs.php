<?php

//
// Set a unique slug-like ID
$prefix = 'imigrat_meta_jobs';

//
// Create a metabox
CSF::createMetabox( $prefix, array(
	'title'      	=> 'Imigrat Jobs Setting',
	'icon'       	=> 'el el-cogs',
	'position'   	=> 'normal',
	'priority'   	=> 'core',
	'post_type' 	=> array( 'jobs' ),
	'show_restore'       => false,
	'context'            => 'advanced',
	'nav'                => 'normal',
	'theme'              => 'dark',
	'class'              => '',
) );


// Create a section
CSF::createSection($prefix, array(
	'fields' => array(
		//Detail Image
		array(
			'id'    => 'jobs_detail_image',
			'type'  => 'media',
			'url'      => true,
			'title' => esc_html__( 'Choose Detail Image Url', 'imigrat-plugin' ),
			'default'  => array(
				'url' => get_template_directory_uri() . '',
			),
		),
		
		//Icon Image
		array(
			'id'    => 'imigrat_social_icon_image',
			'type'  => 'media',
			'url'      => true,
			'title' => esc_html__( 'Choose Social Icon Image', 'imigrat-plugin' ),
			'default'  => array(
				'url' => get_template_directory_uri() . '',
			),
		),
		
		
		//Feature Box Section
		array(
			'id' => 'show_job_info',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Feature Box', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Feature Box', 'imigrat-plugin'),
			'default'  => false,
		),
		//Feature Box Info 
		array(
			'id'    => 'jobs_features',
			'type'  => 'group',
			'title' => esc_html__( 'Job Information', 'imigrat-plugin' ),
			'dependency' => array( 'show_job_info', '==', true ),
			'fields'	=> array(
				array(
					'id'    => 'job_info_icon',
					'type'  => 'icon',
					'title' => esc_html__( 'Icon', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'job_info_title',
					'type'     => 'text',
					'title'    => esc_html__( 'Title', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Title', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'job_info_description',
					'type'     => 'textarea',
					'title'    => esc_html__( 'Description', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Description', 'imigrat-plugin' ),
				),
			),
		),
		
		array(
			'id' => 'show_apply_button',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Apply Button', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Apply Button', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'    => 'job_btn_title',
			'type'  => 'text',
			'title' => esc_html__( 'Button Title', 'imigrat-plugin' ),
			'dependency' => array( 'show_apply_button', '==', true ),
		),
		array(
			'id'    => 'job_btn_link',
			'type'  => 'text',
			'title' => esc_html__( 'Button URL', 'imigrat-plugin' ),
			'dependency' => array( 'show_apply_button', '==', true ),
		),
		
		
		
		
	)
));
