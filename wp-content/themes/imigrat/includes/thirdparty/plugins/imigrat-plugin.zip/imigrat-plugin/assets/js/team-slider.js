(function($) {

	"use strict";
	var team_slider = function($scope, $) {

		$(document).ready(function () {
            var swiper = new Swiper(".imi-service-slider", {
                slidesPerView: 3,
                spaceBetween: 35,
                loop: true,
                pagination: false,
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                breakpoints: {
                    1500: {
                        slidesPerView: 3,
                    },
                    1199: {
                        slidesPerView: 3,
                    },
                    991: {
                        slidesPerView: 3,
                    },
                    920: {
                        slidesPerView: 2,
                    },
                    767: {
                        slidesPerView: 2,
                    },
                    600: {
                        slidesPerView: 2,
                    },
                    500: {
                        slidesPerView: 1,
                    }
                },
            });
        });

        $(document).ready(function () {
            var swiper = new Swiper(".imi-team_carousel", {
                slidesPerView: 2,
                spaceBetween: 30,
                loop: true,
                //pagination: false,
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
                autoplay: {
                    delay: 3000,
                },
                breakpoints: {
                    1500: {
                        slidesPerView: 2,
                    },
                    1199: {
                        slidesPerView: 2,
                    },
                    991: {
                        slidesPerView: 2,
                    },
                    767: {
                        slidesPerView: 2,
                    },
                    600: {
                        slidesPerView: 1,
                    },
                    500: {
                        slidesPerView: 1,
                    },
                    0: {
                        slidesPerView: 1,
                    }
                },
            });
        });

	};

	$(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_team_grid.default', team_slider);
    });

})(window.jQuery);