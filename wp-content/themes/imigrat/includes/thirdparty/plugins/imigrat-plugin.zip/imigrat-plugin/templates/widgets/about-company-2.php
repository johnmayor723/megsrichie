<?php
extract($args);
$title = apply_filters('widget_title', $instance['title']);

echo wp_kses_post($before_widget); ?>

<div class="address-widget">
    <?php echo wp_kses_post($before_title . $title . $after_title); ?>

	<?php if ($instance['content']) { ?>
    <p><?php echo wp_kses_post($instance['content']); ?></p><!-- /.footer-widget__text -->
	<?php } ?>

    <?php
    $social_group = $instance['social_links_group'];

    if (!empty($social_group)):
    ?>
    <div class="footer-social">
        <?php foreach ($social_group as $social): ?>
            <a href="<?php echo esc_url($social['social_link']); ?>">
                <i class="fab <?php echo esc_attr($social['social_icon']); ?>"></i>
            </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>


</div>

<?php

echo wp_kses_post($after_widget);
