<?php

$query_string = 'posts_per_page=' . $instance['number'];
if ($instance['cat']) {
    $query_string .= '&cat=' . $instance['cat'];
}
$query = new WP_Query($query_string);

extract($args);
$title = apply_filters('widget_title', $instance['title']);

echo wp_kses_post($before_widget); ?>

<div class="rcp-post-widget-wrapper">
    <?php echo wp_kses_post($before_title . $title . $after_title); ?>
    <div class="rcp-post-wrapper">
        <?php
			global $post;
			while( $query->have_posts() ): $query->the_post();
			$post_thumbnail_id = get_post_thumbnail_id($post->ID);
			$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
		?>
        <div class="news-widget-block">
            <div class="news-widget_image">
                <?php the_post_thumbnail('imigrat_94x82'); ?>
            </div>
            <h6 class="news-widget_title"><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h6>
            <div class="news-widget_post-date"><?php echo get_the_date(); ?></div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<?php echo wp_kses_post($after_widget);
