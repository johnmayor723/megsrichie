<?php

//
// Set a unique slug-like ID
$prefix = 'imigrat_meta_country';

//
// Create a metabox
CSF::createMetabox( $prefix, array(
	'title'      	=> 'Imigrat Country Setting',
	'icon'       	=> 'el el-cogs',
	'position'   	=> 'normal',
	'priority'   	=> 'core',
	'post_type' 	=> array( 'country' ),
	'show_restore'       => false,
	'context'            => 'advanced',
	'nav'                => 'normal',
	'theme'              => 'dark',
	'class'              => '',
) );

//
// Create a section
CSF::createSection($prefix, array(
	'fields' => array(
		array(
			'id'    => 'imigrat_icon_image',
			'type'  => 'media',
			'url'      => true,
			'title' => esc_html__( 'Choose Icon Image', 'imigrat-plugin' ),
			'default'  => array(
				'url' => get_template_directory_uri() . '',
			),
		),
		
		//Detail Image
		array(
			'id'    => 'country_detail_image',
			'type'  => 'media',
			'url'      => true,
			'title' => esc_html__( 'Choose Detail Image Url', 'imigrat-plugin' ),
			'default'  => array(
				'url' => get_template_directory_uri() . '',
			),
		),
		
		//Feature Box Section
		array(
			'id' => 'show_country_feature_box',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Feature Box', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Feature Box', 'imigrat-plugin'),
			'default'  => false,
		),
		//Feature Box Info 
		array(
			'id'    => 'country_features',
			'type'  => 'group',
			'title' => esc_html__( 'Feature Box Information', 'imigrat-plugin' ),
			'dependency' => array( 'show_country_feature_box', '==', true ),
			'fields'	=> array(
				array(
					'id'    => 'country_info_icon',
					'type'  => 'icon',
					'title' => esc_html__( 'Icon', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'country_feature_title',
					'type'     => 'text',
					'title'    => esc_html__( 'Title', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Title', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'country_feature_description',
					'type'     => 'textarea',
					'title'    => esc_html__( 'Description', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Description', 'imigrat-plugin' ),
				),
			),
		),
		
		array(
			'id'    => 'country_sub_content',
			'type'  => 'textarea',
			'title' => esc_html__( 'Description/Raw HTML', 'imigrat-plugin' ),
		),
		
		//Accordion Section
		array(
			'id' => 'show_country_step_box',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Step Information', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Step Information', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'    => 'country_step_box',
			'type'  => 'group',
			'title' => esc_html__( 'Step Information', 'imigrat-plugin' ),
			'dependency' => array('show_country_step_box', '==', true),
			'fields'	=> array(
				array(
					'id'    => 'country_step_title',
					'type'  => 'text',
					'title' => esc_html__( 'Step Title', 'imigrat-plugin' ),
				),
				array(
					'id'    => 'country_step_deacription',
					'type'  => 'textarea',
					'title' => esc_html__( 'Step Description', 'imigrat-plugin' ),
				),
			)
		),
		
		//Description
		array(
			'id'    => 'country_sub_deacription',
			'type'  => 'textarea',
			'title' => esc_html__( 'Description', 'imigrat-plugin' ),
		),
		
		
		//Customer Benefits
		array(
			'id' => 'show_customer_benefits',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Customer Benefits', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Customer Benefits', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'       => 'customer_image',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__('Choose Image URL', 'imigrat-plugin'),
			'dependency' => array( 'show_customer_benefits', '==', true ),
			'default'  => '',
		),
		array(
			'id'    => 'customer_benefits_title',
			'type'  => 'text',
			'title' => esc_html__( 'Benefits Heading', 'imigrat-plugin' ),
			'dependency' => array('show_customer_benefits', '==', true),
		),
		array(
			'id'    => 'customer_benefits_text',
			'type'  => 'textarea',
			'title' => esc_html__( 'Benefits Description', 'imigrat-plugin' ),
			'dependency' => array('show_customer_benefits', '==', true),
		),
		array(
			'id'    => 'customer_feature_list',
			'type'  => 'textarea',
			'title' => esc_html__( 'Feature List', 'imigrat-plugin' ),
			'dependency' => array('show_customer_benefits', '==', true),
		),
			
	)
));
