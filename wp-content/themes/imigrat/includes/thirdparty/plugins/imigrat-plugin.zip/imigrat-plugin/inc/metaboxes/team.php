<?php


//
// Set a unique slug-like ID
$prefix = 'imigrat_meta_team';
//
// Create a metabox
CSF::createMetabox( $prefix, array(
	'title'      	=> 'Imigrat Team Setting',
	'icon'       	=> 'el el-cogs',
	'position'   	=> 'normal',
	'priority'   	=> 'core',
	'post_type' 	=> array( 'team' ),
	'show_restore'       => false,
	'context'            => 'advanced',
	'nav'                => 'normal',
	'theme'              => 'dark',
	'class'              => '',
) );
//
// Create a section
CSF::createSection($prefix, array(
	'fields' => array(
		array(
			'id'    => 'designation',
			'type'  => 'text',
			'title' => esc_html__( 'Designation', 'imigrat-plugin' ),
		),
		
		//Team Info 
		array(
			'id'    => 'team_info',
			'type'  => 'group',
			'title' => esc_html__( 'Team Information', 'imigrat-plugin' ),
			'fields'	=> array(
				array(
					'id'    => 'team_info_icon',
					'type'  => 'icon',
					'title' => esc_html__( 'Icon', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'team_info_title',
					'type'     => 'text',
					'title'    => esc_html__( 'Info Title', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the info Title', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'team_info_description',
					'type'     => 'text',
					'title'    => esc_html__( 'Description', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Description', 'imigrat-plugin' ),
				),
			),
		),
		
		array(
			'id'    => 'team_social_heading',
			'type'  => 'text',
			'title' => esc_html__( 'Social Heading', 'imigrat-plugin' ),
		),
		array(
			'id'    => 'social_profile',
			'type'  => 'group',
			'title' => esc_html__( 'Social Profiles', 'imigrat-plugin' ),
			'fields'	=> array(
				array(
					'id'    => 'url',
					'type'  => 'text',
					'title' => esc_html__( 'URL', 'imigrat-plugin' ),
				),
				array(
					'id'    => 'icon',
					'type'  => 'icon',
					'title' => esc_html__( 'Icon', 'imigrat-plugin' ),
				),
				array(
					'id'    => 'background',
					'type'  => 'color',
					'title' => esc_html__( 'Background Color', 'imigrat-plugin' ),
				),
				array(
					'id'    => 'color',
					'type'  => 'color',
					'title' => esc_html__( 'Color', 'imigrat-plugin' ),
				),
			)
		),
		// 
		//About Section
		array(
			'id' => 'show_about_area',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide About Information', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show About Information', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'    => 'team_about_heading',
			'type'  => 'text',
			'title' => esc_html__( 'About Title', 'imigrat-plugin' ),
			'dependency' => array('show_about_area', '==', true),
		),
		array(
			'id'    => 'team_about_description',
			'type'  => 'textarea',
			'title' => esc_html__( 'About Description', 'imigrat-plugin' ),
			'dependency' => array('show_about_area', '==', true),
		),
		
		//Skills Section
		array(
			'id' => 'show_skills_area',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Skills Information', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Skills Information', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'    => 'team_skills_title',
			'type'  => 'text',
			'title' => esc_html__( 'Skill Title', 'imigrat-plugin' ),
			'dependency' => array('show_skills_area', '==', true),
		),
		array(
			'id'    => 'team_skills_description',
			'type'  => 'textarea',
			'title' => esc_html__( 'Skill Description', 'imigrat-plugin' ),
			'dependency' => array('show_skills_area', '==', true),
		),
		array(
			'id'    => 'team_skills',
			'type'  => 'group',
			'dependency' => array('show_skills_area', '==', true),			
			'title' => esc_html__( 'Skills', 'imigrat-plugin' ),
			'fields'	=> array(
				array(
					'id'       => 'team_skills_title1',
					'type'     => 'text',
					'title'    => esc_html__( 'Skills Counter Title', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Skills Counter Title', 'imigrat-plugin' ),
				),
				array(
					'id'       => 'team_skills_counter_value',
					'type'     => 'text',
					'title'    => esc_html__( 'Skills Counter Value', 'imigrat-plugin' ),
					'desc'     => esc_html__( 'Enter the Skills Counter Value', 'imigrat-plugin' ),
				),
			),
		),
		
		//Contact Form Section
		array(
			'id' => 'show_contact_form_area',
			'type' => 'switcher',
			'title' => esc_html__('Show/Hide Contact Form Section', 'imigrat-plugin'),
			'desc' => esc_html__('Enable to Show Contact Form Section', 'imigrat-plugin'),
			'default'  => false,
		),
		array(
			'id'    => 'team_contact_form_title',
			'type'  => 'text',
			'title' => esc_html__( 'Form Title', 'imigrat-plugin' ),
			'dependency' => array('show_contact_form_area', '==', true),
		),
		array(
			'id'    => 'team_form_url',
			'type'  => 'textarea',
			'title' => esc_html__( 'Contact Form 7 Url', 'imigrat-plugin' ),
			'dependency' => array('show_contact_form_area', '==', true),
		),
		
	)
));
