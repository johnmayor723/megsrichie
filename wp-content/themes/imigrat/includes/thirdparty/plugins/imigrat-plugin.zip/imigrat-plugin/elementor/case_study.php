<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Case_Study extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_case_study';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Case Study', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }

    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'why_choose_us',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2'  => __( 'Style 2', 'imigrat' ),
					'style3'  => __( 'Style 3', 'imigrat' ),
					'style4'  => __( 'Style 4', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
            ]
        );

        // image
        $this->add_control(
			'image',
			[
				'label' => esc_html__('Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
            ]
        );

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

	/************************************************************************
								Tab Style Start
	*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-about-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-about-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-page-about-section',
			]
		);
		$this->end_controls_section();

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-2 h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-2 h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-2 h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-2 h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p',
			]
		);
		$this->end_controls_section();

		//Experiance box Style
		$this->start_controls_section(
			'experiance_box_style',
			[
				'label' => esc_html__( 'Experiance Box Style', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'experiance_box_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'experiance_box_year_typography',
				'label' => __('Year Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area h3',
			]
		);
		$this->add_control(
			'experiance_box_year_color',
			[
				'label' => esc_html__( 'Experiance Year Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area h3' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'experiance_box_title_typography',
				'label' => __('Text Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area p',
			]
		);
		$this->add_control(
			'experiance_box_title_color',
			[
				'label' => esc_html__( 'Experiance Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-img-wrapper .imi-about-exp-area p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		//Feature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'feature_list__margin',
            [
                'label'      => esc_html__( 'Margin', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list-2 ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'feature_list_padding',
            [
                'label'      => esc_html__( 'Padding', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list-2 ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-about-feature-list-2 ul',
			]
		);

		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'cleanex'),
				'selector' => '{{WRAPPER}} .imi-about-feature-list-2 ul li',
			]
		);

		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'feature_list_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'feature_list_text_stroke',
				'selector' => '
					{{WRAPPER}} .imi-about-feature-list-2 ul li
				',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_text_shadow',
				'selector' => '
						{{WRAPPER}} .imi-about-feature-list-2 ul li',
			]
		);
		$this->end_controls_section();


	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if($settings['style'] == 'style4' ) : ?>
    <div class="case-block_one style-three">
        <div class="case-block_one-inner">
            <div class="content-column">
                <div class="inner-column">
                    <?php if(!empty( $settings['sub_title'] )) : ?>
                    <div class="title"><?php echo wp_kses($settings['sub_title'], true);?></div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['title'] )) : ?>
                    <h3 class="case-block_one-heading">
                        <a href="<?php echo esc_url($settings['button_link']['url']); ?>"><?php echo wp_kses($settings['title'], true);?></a>
                    </h3>
                    <?php endif; ?>

                    <?php if(!empty( $settings['text'] )) : ?>
                    <div class="case-block_one-text"><?php echo wp_kses($settings['text'], true);?></div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
                    <div class="button-box">
                        <a class="btn-style-six theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
                            <div class="btn-wrap">
                                <span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
                                    <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                                <span class="text-two">
                                    <?php echo wp_kses($settings['button_text'], true);?>
                                    <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty( $settings['image']['id'] )) : ?>
                    <div class="image">
                        <a href="<?php echo esc_url($settings['button_link']['url']); ?>">
                            <img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="" />
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
	<?php elseif($settings['style'] == 'style3' ) : ?>
    <div class="case-block_one style-two">
        <div class="case-block_one-inner">
            <!-- Content Column -->
            <div class="content-column">
                <div class="inner-column">
                    <?php if(!empty( $settings['image']['id'] )) : ?>
                    <div class="image">
                        <a href="<?php echo esc_url($settings['button_link']['url']); ?>">
                            <img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="" />
                        </a>
                    </div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['sub_title'] )) : ?>
                    <div class="title"><?php echo wp_kses($settings['sub_title'], true);?></div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['title'] )) : ?>
                    <h3 class="case-block_one-heading">
                        <a href="<?php echo esc_url($settings['button_link']['url']); ?>"><?php echo wp_kses($settings['title'], true);?></a>
                    </h3>
                    <?php endif; ?>

                    <?php if(!empty( $settings['text'] )) : ?>
                    <div class="case-block_one-text"><?php echo wp_kses($settings['text'], true);?></div>
                    <?php endif; ?>

                    <?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
                    <div class="button-box">
                        <a class="btn-style-six theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
                            <div class="btn-wrap">
                                <span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
                                    <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                                <span class="text-two">
                                    <?php echo wp_kses($settings['button_text'], true);?>
                                    <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                            </div>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
	<?php elseif($settings['style'] == 'style2' ) : ?>
    <div class="case-block_one">
        <div class="case-block_one-inner">
            <div class="row clearfix">
                <!-- Image Column -->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if(!empty( $settings['image']['id'] )) : ?>
                        <div class="image">
                            <a href="<?php echo esc_url($settings['button_link']['url']); ?>">
                                <img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="" />
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if(!empty( $settings['sub_title'] )) : ?>
                        <div class="title"><?php echo wp_kses($settings['sub_title'], true);?></div>
                        <?php endif; ?>

                        <?php if(!empty( $settings['title'] )) : ?>
                        <h3 class="case-block_one-heading">
                            <a href="<?php echo esc_url($settings['button_link']['url']); ?>"><?php echo wp_kses($settings['title'], true);?></a>
                        </h3>
                        <?php endif; ?>

                        <?php if(!empty( $settings['text'] )) : ?>
                        <div class="case-block_one-text"><?php echo wp_kses($settings['text'], true);?></div>
                        <?php endif; ?>

                        <?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
                        <div class="button-box">
                            <a class="btn-style-six theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
                                <div class="btn-wrap">
                                    <span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
                                        <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                                    <span class="text-two">
                                        <?php echo wp_kses($settings['button_text'], true);?>
                                        <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<?php else : ?>
    <div class="case-block_one">
        <div class="case-block_one-inner">
            <div class="row clearfix">
                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if(!empty( $settings['sub_title'] )) : ?>
                        <div class="title"><?php echo wp_kses($settings['sub_title'], true);?></div>
                        <?php endif; ?>

                        <?php if(!empty( $settings['title'] )) : ?>
                        <h3 class="case-block_one-heading">
                            <a href="<?php echo esc_url($settings['button_link']['url']); ?>"><?php echo wp_kses($settings['title'], true);?></a>
                        </h3>
                        <?php endif; ?>

                        <?php if(!empty( $settings['text'] )) : ?>
                        <div class="case-block_one-text"><?php echo wp_kses($settings['text'], true);?></div>
                        <?php endif; ?>

                        <?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
                        <div class="button-box">
                            <a class="btn-style-six theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
                                <div class="btn-wrap">
                                    <span class="text-one"><?php echo wp_kses($settings['button_text'], true);?>
                                        <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                                    <span class="text-two">
                                        <?php echo wp_kses($settings['button_text'], true);?>
                                        <i class="fas fa-arrow-circle-right fa-fw"></i></span>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <?php if(!empty( $settings['image']['id'] )) : ?>
                        <div class="image">
                            <a href="<?php echo esc_url($settings['button_link']['url']); ?>">
                                <img src="<?php echo esc_url(wp_get_attachment_url($settings['image']['id'])); ?>" alt="" />
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php
		endif;
    }
}