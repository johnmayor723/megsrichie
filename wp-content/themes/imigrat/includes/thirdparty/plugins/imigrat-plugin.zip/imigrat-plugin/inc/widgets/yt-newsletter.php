<?php

CSF::createWidget('yt_newsletter', array(
    'title'       => esc_html__('YT Footer Newsletter', 'imigrat-plugin'),
    'classname'   => 'yt-about-company',
    'description' => esc_html__('Newsletter for footer', 'imigrat-plugins'),
    'fields'      => array(
        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   => 'Title',
        ),
		array(
            'id'      => 'short_description',
            'type'    => 'textarea',
            'title'   => esc_html__( 'Short Description', 'imigrat-plugin'),
        ),
		array(
            'id'      => 'newsletter_shortcode',
            'type'    => 'textarea',
            'title'   => 'News Letter Short Code',
        ),
	)
));

//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_newsletter') ) {
    function yt_newsletter($args, $instance) {

        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/newsletter.php';
    }
}
