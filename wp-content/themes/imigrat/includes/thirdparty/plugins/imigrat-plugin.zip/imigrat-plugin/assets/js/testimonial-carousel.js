(function($) {

	"use strict";
	var testimonial_carousel_js = function($scope, $) {


		$(document).ready(function () {
			var swiper = new Swiper(".imi-testimonial-slider", {
				slidesPerView: 1,
				spaceBetween: 0,
				loop: true,
				pagination: false,
				navigation: {
					nextEl: ".swiper-button-next",
					prevEl: ".swiper-button-prev",
				},
			});
		});

		$(document).ready(function () {
			var swiper = new Swiper(".imi-testimonial-slider-2", {
				slidesPerView: 1,
				spaceBetween: 0,
				loop: true,
				speed: 1000,
				pagination: {
					el: '.swiper-paginations_3',
					clickable: true,
				},
			});
		});

		$(document).ready(function () {
			var swiper = new Swiper(".imi-testimonial-slider-3", {
				slidesPerView: 1,
				spaceBetween: 30,
				loop: true,
				speed: 1000,
				pagination: {
					el: ".swiper-pagination",
					clickable: true,
				},
			});
		});

		$(document).ready(function () {
			var swiper = new Swiper(".imi-testimonial-slider-h5", {
				slidesPerView: 3,
				spaceBetween: 35,
				loop: true,
				pagination: false,
				navigation: {
					nextEl: ".swiper-button-next",
					prevEl: ".swiper-button-prev",
				},
				breakpoints: {
					1500: {
						slidesPerView: 3,
					},
					1199: {
						slidesPerView: 3,
					},
					991: {
						slidesPerView: 3,
					},
					920: {
						slidesPerView: 2,
					},
					767: {
						slidesPerView: 2,
					},
					600: {
						slidesPerView: 2,
					},
					500: {
						slidesPerView: 1,
					}
				},
			});
		});

	};

	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_testimonials.default', testimonial_carousel_js);
    });

})(window.jQuery);