(function($) {
	
	"use strict";
	var banner_script_js = function($scope, $) {
		
		
		$(document).ready(function () {
			var swiper = new Swiper(".imi-slider-wrapper", {
				slidesPerView: 1,
				spaceBetween: 0,                  
				loop: true,
				effect: 'fade',
				pagination: false,
				navigation: {
					nextEl: ".swiper-main-next",
					prevEl: ".swiper-main-prev",
				},
			});
		});
		
	};
	
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_banner_1.default', banner_script_js);
    });	

})(window.jQuery);