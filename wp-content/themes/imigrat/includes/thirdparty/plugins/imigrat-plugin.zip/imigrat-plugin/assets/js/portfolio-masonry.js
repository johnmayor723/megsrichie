(function($) {
	
	"use strict";
	var portfolio_masonry_js = function($scope, $) {
		
		//Sortable Masonary with Filters
		function enableMasonry() {
			if($('.sortable-masonry').length){
		
				var winDow = $(window);
				// Needed variables
				var $container=$('.sortable-masonry .items-container');
				var $filter=$('.filter-btns');
		
				$container.isotope({
					filter:'*',
					 masonry: {
						columnWidth : '.grid-item.grid-size-33'
					 },
					animationOptions:{
						duration:500,
						easing:'linear'
					}
				});
				
		
				// Isotope Filter 
				$filter.find('button').on('click', function(){
					var selector = $(this).attr('data-filter');
		
					try {
						$container.isotope({ 
							filter	: selector,
							animationOptions: {
								duration: 500,
								easing	: 'linear',
								queue	: false
							}
						});
					} catch(err) {
		
					}
					return false;
				});
		
		
				winDow.on('resize', function(){
					var selector = $filter.find('button.is-checked').attr('data-filter');
	
					$container.isotope({ 
						filter	: selector,
						animationOptions: {
							duration: 500,
							easing	: 'linear',
							queue	: false
						}
					});
				});
		
		
				var filterItemA	= $('.filter-btns button');
		
				filterItemA.on('click', function(){
					var $this = $(this);
					if ( !$this.hasClass('is-checked')) {
						filterItemA.removeClass('is-checked');
						$this.addClass('is-checked');
					}
				});
			}
		}
	
		enableMasonry();
	};
	
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_portfolio.default', portfolio_masonry_js);
    });	

})(window.jQuery);