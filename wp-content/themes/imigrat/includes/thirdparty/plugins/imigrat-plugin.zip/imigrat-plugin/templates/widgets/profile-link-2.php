<?php

extract($args);
$title = apply_filters('widget_title', $instance['title']);
echo wp_kses_post($before_widget); ?>

<div class="download-widget ul-li-block">
    <?php echo wp_kses_post($before_title . $title . $after_title); ?>
    <div class="imi_2-service-widget-download">
        <?php 
			$download_group = $instance['download_links_group'];
			if (!empty( $download_group )) : 
		?>
        <?php foreach( $download_group as $download ):?>
        <div class="imi_2-download-service-item d-flex align-items-center position-relative">
            <div class="download-icon">
                <i class="fas fa-file-pdf"></i>
            </div>
            <div class="download-text headline">
            	
                <h3><?php echo wp_kses( $download[ 'download_sub_title' ], true );?></h3>
                <span><?php echo wp_kses( $download[ 'download_title' ], true );?></span>
            </div>
            <div class="file-download-btn position-absolute">
                <a class="d-flex align-items-center justify-content-center" href="<?php echo esc_url( $download[ 'download_link' ]['url']);?>"><i class="fal fa-arrow-to-bottom"></i></a>
            </div>
        </div>
        <?php endforeach;?>
        <?php endif; ?>
       
    </div>
</div>

<?php
echo wp_kses_post($after_widget);
