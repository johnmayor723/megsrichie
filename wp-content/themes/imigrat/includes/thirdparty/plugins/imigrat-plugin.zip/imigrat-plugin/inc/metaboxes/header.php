<?php

//

// Create a section

CSF::createSection( $prefix, [

    'title'  => esc_html__( "Imigrat Header Settings", "imigrat-plugin" ),

    'fields' => [

        [

            'id'      => 'header_source_type',

            'type'    => 'button_set',

            'title'   => esc_html__( 'Header Source Type', 'imigrat-plugin' ),

            'options' => [

                'd' => esc_html__( 'Default', 'imigrat-plugin' ),

                'e' => esc_html__( 'Elementor', 'imigrat-plugin' ),

            ],

            'default' => '',

        ],

        [

            'id'         => 'header_new_elementor_template',

            'type'       => 'select',

            'title'      => __( 'Template', 'imigrat-plugin' ),

            'options'    => 'posts',

            'query_args' => [

                'post_type'      => ['elementor_library'],

                'posts_per_page' => -1,

                'orderby'        => 'title',

                'order'          => 'DESC',

            ],

            'dependency' => ['header_source_type', '==', 'e'],

        ],

        [

            'id'         => 'header_style_settings',

            'type'       => 'image_select',

            'title'      => esc_html__( 'Choose Header Styles', 'imigrat-plugin' ),

            'options'    => [

                'header_v1' => get_template_directory_uri() . '/assets/images/redux/header/header1.png',
                'header_v2' => get_template_directory_uri() . '/assets/images/redux/header/header2.png',
                'header_v3' => get_template_directory_uri() . '/assets/images/redux/header/header3.png',
                'header_v4' => get_template_directory_uri() . '/assets/images/redux/header/header4.png',
                'header_v5' => get_template_directory_uri() . '/assets/images/redux/header/header5.png',
                'header_v6' => get_template_directory_uri() . '/assets/images/redux/header/header6.png',

            ],

            'dependency' => [ [ 'header_source_type', '==', 'd' ] ],

        ],

    ],

] );
