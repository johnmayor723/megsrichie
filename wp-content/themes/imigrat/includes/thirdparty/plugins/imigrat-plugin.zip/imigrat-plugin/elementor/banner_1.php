<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Banner_1 extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_banner_1';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Banner Slider', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-library-open';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }

	public function get_script_depends() {
		wp_register_script( 'banner-scripts', YT_URL . 'assets/js/banner-carousel.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'banner-scripts' ];
	}

    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
					'style3' => __( 'Style 3', 'imigrat' ),
					'style4' => __( 'Style 4', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
            ]
        );

		// shape image
		$this->add_control(
			'shape_image',
			[
				'label' => esc_html__('Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style2', 'style3', 'style4'],
				],
			]
		);

		$this->add_control(
			'shape_image2',
			[
				'label' => esc_html__('Shape Image 2', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style3', 'style4'],
				],
			]
		);

		$this->add_control(
			'shape_image3',
			[
				'label' => esc_html__('Shape Image 3', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style3', 'style4'],
				],
			]
		);

		// big image
		$this->add_control(
			'big_image',
			[
				'label' => esc_html__('Big Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style4'],
				],
			]
		);

		// small image
		$this->add_control(
			'small_image',
			[
				'label' => esc_html__('Small Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => ['style4'],
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
				'condition' => [
					'style' => ['style4'],
				],
            ]
        );

		// title
		$this->add_control(
			'title',
			[
				'label' => esc_html__('Title', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('We are Imigrat', 'imigrat'),
				'placeholder' => esc_html__('Type your title here', 'imigrat'),
				'label_block' => true,
			]
		);

		// text
		$this->add_control(
			'text',
			[
				'label' => esc_html__('Text', 'imigrat'),
				'type' => Controls_Manager::TEXTAREA,
				'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'imigrat'),
				'placeholder' => esc_html__('Type your text here', 'imigrat'),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
				'condition' => [
					'style' => ['style4'],
				],
            ]
        );

		// video button link
		$this->add_control(
			'video_button_link',
			[
				'label' => esc_html__('Video Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		// buton text
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__('Button Text', 'imigrat'),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__('Learn More', 'imigrat'),
			]
		);

		// button link
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__('Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'banner_1',
            [
                'label' => esc_html__( 'BANNER SLIDE ITEMS', 'imigrat' ),
				'condition' => [
					'style' => ['style3', 'style2', 'style1'],
				],
            ]
        );

		//Our Slider
		$repeater = new Repeater();

		// slide design section
		$repeater->add_control(
			'slide_style',
			[
				'label' => __( 'Slide Style', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
					'style3' => __( 'Style 3', 'imigrat' ),
				],
			]
		);

		$repeater->add_control(
			'banner_image',
			[
				'label' => esc_html__('Banner Feature Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__('Slide Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'   => [
					'slide_style' => ['style3', 'style1'],
				],
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'imigrat' ),
				'condition'   => [
					'slide_style' => 'style2',
				],
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => __( ' Text', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'form_title',
			[
				'label'       => __( ' Form Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Form Title', 'imigrat' ),
				'condition'   => [
					'slide_style' => 'style1',
				],
			]
		);
		$repeater->add_control(
			'mailchimp_form_url',
			[
				'label'       => __( 'MailChimp Form Url', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Contact Form Url', 'imigrat' ),
				'condition'   => [
					'slide_style' => 'style1',
				],
			]
		);

		// button section
		$repeater->add_control(
			'button_text',
			[
				'label'       => __( 'Button Text', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Text', 'imigrat' ),
				'condition'   => [
					'slide_style' => ['style3', 'style2'],
				],
			]
		);

		$repeater->add_control(
			'button_link',
			[
				'label'       => __( 'Button Link', 'imigrat' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Link', 'imigrat' ),
				'condition'   => [
					'slide_style' => ['style3', 'style2'],
				],
			]
		);

		$this->add_control(
			'slides',
			[
				'label'                 => __('Add Slide Item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'GENERAL SETTING', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style1', 'style2'],
				],
			]
		);

		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-slider-items' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-slider-items' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-slider-items',
			]
		);
		$this->end_controls_section();

		// SUB-HEADING STYLE
		$this->start_controls_section(
			'subtitle_style',
			[
				'label' => esc_html__('SUBTITLE STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style2'],
				],
			]
		);
		$this->add_control(
			'show_subtitle_style',
			[
				'label'       => __( 'ON/OFF Sub Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'label' => __('Sub Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .slider-one_title',
                'separator' => 'before',
				'condition'             => [
					'show_subtitle_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'subtitle_color',
            [
                'label' => __('Sub Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .slider-one_title' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_subtitle_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		/**Title Style**/
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__('TITLE STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'show_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' =>
                    '
						{{WRAPPER}} .imi-slider-items .imi-slider-text h1,
						{{WRAPPER}} .slider-one_heading,
						{{WRAPPER}} .slider-two_heading,
						{{WRAPPER}} .banner-one_title
					',
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text h1' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .slider-one_heading' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .slider-two_heading' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .banner-one_title' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );

		$this->add_control(
            'title_span_color',
            [
                'label' => __('Title Span Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .slider-one_heading span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .slider-two_heading span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .banner-one_title span' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );

		// span background
		$this->add_control(
			'span_background',
			[
				'label' => __( 'Span Background', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .banner-one_title span::before' => 'background-color: {{VALUE}}',
				],
				'condition'             => [
					'show_title_style'    => 'yes',
					'style' => ['style4'],
				]
			]
		);

		$this->end_controls_section();

		/**Content Style**/
		$this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__('CONTENT STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'show_content_style',
			[
				'label'       => __( 'ON/OFF  Content Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'label' => __('Content Typography', 'imigrat'),
                'selector' =>
                    '
					{{WRAPPER}} .imi-slider-items .imi-slider-text p,
					{{WRAPPER}} .slider-one_text,
					{{WRAPPER}} .slider-two_text,
					{{WRAPPER}} .banner-one .text
					',
                'separator' => 'before',
				'condition'             => [
					'show_content_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'content_color',
            [
                'label' => __('Content Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text p' => 'color: {{VALUE}}!important',
                    '{{WRAPPER}} .slider-one_text' => 'color: {{VALUE}}!important',
                    '{{WRAPPER}} .slider-two_text' => 'color: {{VALUE}}!important',
                    '{{WRAPPER}} .banner-one .text' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_content_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();


		/**Form Title Style**/
		$this->start_controls_section(
			'form_title_style',
			[
				'label' => esc_html__('FORM TITLE STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style1'],
				],
			]
		);
		$this->add_control(
			'show_form_title_style',
			[
				'label'       => __( 'ON/OFF Form Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'form_title_typography',
                'label' => __('Form Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter span',
                'separator' => 'before',
				'condition'             => [
					'show_form_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'form_title_color',
            [
                'label' => __('Form Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter span' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_form_title_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		/**Button Style One**/
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('FORM BUTTON STYLE SETTING', 'imigrat-plugin'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style1'],
				],
			]
		);
		$this->add_control(
			'show_btn_style',
			[
				'label'       => __( 'ON/OFF Button Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'yt_btn_background',
			[
				'label'                 => __( 'Button Background', 'imigrat-plugin' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_bgtype',
				'label' => __( 'Button Background', 'imigrat-plugin' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' =>
					'{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'hover_background',
			[
				'label'                 => __( 'Button Hover Background', 'imigrat-plugin' ),
				'type'                  => Controls_Manager::HEADING,
				'separator'             => 'before',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_hover_bg_bgtype',
				'label' => __( 'Button Hover Background', 'imigrat-plugin' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' =>
					'{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button:hover',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'show_border_radius',
			[
				'label'       => __( 'ON/OFF Button Radius Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_control(
            'btn_border_radius',
            [
                'label' => esc_html__('Border Radius', 'imigrat-plugin'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => ['px'],
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
				'condition'             => [
					'show_border_radius'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_border_type',
			[
				'label'       => __( 'ON/OFF Border Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'btn_border_type',
                'selector' =>
					'{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button',
				'separator' => 'before',
				'condition'             => [
					'show_border_type'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'btn_border_hover_color',
            [
                'label' => __('Button Border Hover Color', 'imigrat-plugin'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button:hover' => 'border-color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_border_type'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_box_shadow',
			[
				'label'       => __( 'ON/OFF Box Shadow Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'border_box_shadow',
                'selector' =>
					'{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button',
				'separator' => 'before',
				'condition'             => [
					'show_box_shadow'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_btn_padding',
			[
				'label'       => __( 'ON/OFF Padding Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_responsive_control(
            'btn_padding',
            [
                'label'              => __( 'Padding', 'imigrat-plugin' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => [ 'px', 'em', '%' ],
                'selectors'          => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                ],

                'frontend_available' => true,
				'condition'             => [
					'show_btn_padding'    => 'yes',
				]
            ]
        );
		$this->add_control(
			'show_typo_color',
			[
				'label'       => __( 'ON/OFF Typography and Color Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition'             => [
					'show_btn_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_title_typography',
                'label' => __('Button Text Typography', 'imigrat-plugin'),
                'selector' =>
					'{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button',
                'separator' => 'before',
				'condition'             => [
					'show_typo_color'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'btn_title_color',
            [
                'label' => __('Button Text Color', 'imigrat-plugin'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_typo_color'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'btn_title_hover_color',
            [
                'label' => __('Button Text Hover Color', 'imigrat-plugin'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-slider-items .imi-slider-text .imi-slider-newsletter form button:hover' => 'color: {{VALUE}}!important',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_typo_color'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();

		// button style
		$this->start_controls_section(
			'btn_style',
			[
				'label' => __( 'BUTTON STYLE', 'imigrat-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style2', 'style3', 'style4'],
				],
			]
		);

		// enable button style
		$this->add_control(
			'show_btn_style2',
			[
				'label'       => __( 'ON/OFF Button Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		// button typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_title_typography2',
				'label' => __('Button Text Typography', 'imigrat-plugin'),
				'selector' =>
					'
						{{WRAPPER}} .btn-style-two span,
						{{WRAPPER}} .btn-style-four span,
						{{WRAPPER}} .btn-style-seven span
					',
				'separator' => 'before',
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// border radius
		$this->add_responsive_control(
			'btn_border_radius2',
			[
				'label'              => __( 'Border Radius', 'imigrat-plugin' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', 'em', '%' ],
				'selectors'          => [
					'{{WRAPPER}} .btn-style-two' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-four' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .btn-style-seven' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
				],

				'frontend_available' => true,
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->start_controls_tabs( '_tabs_button-' );

		$this->start_controls_tab(
            '_tab_button_normal',
            [
                'label' => __( 'Normal', 'elementhelper' ),
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
            ]
        );

		// button color
		$this->add_control(
			'btn_title_color2',
			[
				'label' => __( 'Button Text Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-two span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven span' => 'color: {{VALUE}}!important',
				],
				'condition' => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg color
		$this->add_control(
			'btn_bg_color2',
			[
				'label' => __( 'Button Background Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-two' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
            'button_hover',
            [
                'label' => __( 'Hover', 'elementhelper' ),
            ]
        );

		// button hover color
		$this->add_control(
			'btn_title_hover_color2',
			[
				'label' => __( 'Button Text Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-two:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover span' => 'color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover span' => 'color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		// button bg hover color
		$this->add_control(
			'btn_bg_hover_color2',
			[
				'label' => __( 'Button Background Hover Color', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .btn-style-two:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-four:hover::before' => 'background-color: {{VALUE}}!important',
					'{{WRAPPER}} .btn-style-seven:hover::before' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_btn_style2'    => 'yes',
				]
			]
		);

		$this->end_controls_tab();
        $this->end_controls_tabs();

		$this->end_controls_section();

		// video button style
		$this->start_controls_section(
			'videobtn_style',
			[
				'label' => __( 'VIDEO BUTTON STYLE', 'imigrat-plugin' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'style' => ['style4'],
				],
			]
		);

		// enable button style
		$this->add_control(
			'show_videobtn_style',
			[
				'label'       => __( 'ON/OFF Video Button Style', 'imigrat-plugin' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat-plugin' ),
				'label_off' => esc_html__( 'Hide', 'imigrat-plugin' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		// button height width
		$this->add_responsive_control(
			'btn_height_width',
			[
				'label'              => __( 'Button Height Width', 'imigrat-plugin' ),
				'type'               => Controls_Manager::SLIDER,
				'size_units'         => [ 'px', 'em', '%' ],
				'range'              => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'em' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					]
				],
				'selectors'          => [
					'{{WRAPPER}} .banner-one_video-box' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};'
				],
				'frontend_available' => true,
				'default'  => [
					'unit' => 'px',
					'size' => 90,
				],
				'condition'             => [
					'show_videobtn_style'    => 'yes',
				]
			]
		);

		// button icon size
		$this->add_responsive_control(
			'btn_icon_size',
			[
				'label'              => __( 'Button Icon Size', 'imigrat-plugin' ),
				'type'               => Controls_Manager::SLIDER,
				'size_units'         => [ 'px', 'em', '%' ],
				'range'              => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'em' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					]
				],
				'selectors'          => [
					'{{WRAPPER}} .banner-one_video-box i' => 'font-size: {{SIZE}}{{UNIT}};'
				],
				'frontend_available' => true,
				'default'  => [
					'unit' => 'px',
					'size' => 22,
				],
				'condition'             => [
					'show_videobtn_style'    => 'yes',
				]
			]
		);

		// button icon color normal
		$this->add_control(
			'btn_icon_color',
			[
				'label' => __( 'Icon Color Normal', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .banner-one_video-box i' => 'color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_videobtn_style'    => 'yes',
				]
			]
		);

		// button icon color hover
		$this->add_control(
			'btn_icon_hover_color',
			[
				'label' => __( 'Icon Color Hover', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .banner-one_video-box:hover i' => 'color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_videobtn_style'    => 'yes',
				]
			]
		);
		// button bg color normal
		$this->add_control(
			'btn_bg_color',
			[
				'label' => __( 'Background Color Normal', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .banner-one_video-box' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_videobtn_style'    => 'yes',
				]
			]
		);

		// button bg color hover
		$this->add_control(
			'btn_bg_hover_color',
			[
				'label' => __( 'Background Color Hover', 'imigrat-plugin' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .banner-one_video-box:hover' => 'background-color: {{VALUE}}!important',
				],
				'condition'             => [
					'show_videobtn_style'    => 'yes',
				]
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if($settings['style'] == 'style4' ) : ?>

	<section class="banner-one">
		<div class="banner-one_color-layer"></div>
		<div class="container">

			<?php if(!empty( $settings['shape_image']['id'] )) : ?>
			<div class="banner-one_pattern"
				style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>)"></div>
			<?php endif; ?>

			<?php if(!empty( $settings['shape_image2']['id'] )) : ?>
			<div class="banner-one_pattern-two"
				style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image2']['id'])); ?>)"></div>
			<?php endif; ?>

			<?php if(!empty( $settings['title'] )) : ?>
			<h2 class="banner-one_title"><?php echo wp_kses($settings['title'], true);?></h2>
			<?php endif; ?>


			<div class="row ">
				<div class="image col-lg-7 col-md-12 col-sm-12">

					<?php if(!empty( $settings['big_image']['id'] )) : ?>
					<img src="<?php echo esc_url(wp_get_attachment_url($settings['big_image']['id'])); ?>" alt="" />
					<?php endif; ?>

					<?php if(!empty( $settings['shape_image3']['id'] )) : ?>
					<div class="banner-one_pattern-three"
						style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image3']['id'])); ?>)">
					</div>
					<?php endif; ?>

				</div>
				<div class="video-column col-lg-5 col-md-12 col-sm-12">
					<?php if(!empty( $settings['text'] )) : ?>
					<div class="text"><?php echo wp_kses($settings['text'], true);?></div>
					<?php endif; ?>

					<!-- Button Box -->
					<?php if(!empty( $settings['button_text'] || $settings['button_link']['url'] )) : ?>
					<div class="button-box">
						<a class="btn-style-seven theme-btn" href="<?php echo esc_url($settings['button_link']['url']); ?>">
							<div class="btn-wrap">
								<span class="text-one">
									<?php echo wp_kses($settings['button_text'], true);?>
									<i class="fal fa-angle-double-right fa-fw"></i></span>
								<span class="text-two"><?php echo wp_kses($settings['button_text'], true);?>
								 <i class="fal fa-angle-double-right fa-fw"></i></span>
							</div>
						</a>
					</div>
					<?php endif; ?>

					<div class="video-image">

						<?php if(!empty( $settings['small_image']['id'] )) : ?>
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['small_image']['id'])); ?>" alt="" />
						<?php endif; ?>

						<?php if(!empty( $settings['video_button_link']['url'] )) : ?>
						<a href="<?php echo esc_url($settings['video_button_link']['url']); ?>" class="video_box banner-one_video-box">
							<i class="fa fa-play"></i>
							<i class="ripple"></i>
						</a>
						<?php endif; ?>

					</div>
				</div>
			</div>
		</div>
	</section>

	<?php elseif($settings['style'] == 'style3' ) : ?>

	<section class="slider-two">
		<div class="imi-slider-wrapper swiper">
			<div class="swiper-wrapper">
			<?php foreach($settings['slides'] as $key => $item):?>
				<!-- Swiper Slide -->
				<div class="swiper-slide"
				style="background-image: url(<?php if(!empty($item['banner_image']['id'])) {
					echo esc_url(wp_get_attachment_url($item['banner_image']['id']));
				} else {
					echo '';
				} ?>)">

					<?php if(!empty( $settings['shape_image']['id'] )) : ?>
					<div class="slider-two_pattern"
						style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>)"></div>
					<?php endif; ?>

					<?php if(!empty( $settings['shape_image2']['id'] )) : ?>
					<div class="slider-two_pattern-two"
						style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image2']['id'])); ?>)"></div>
					<?php endif; ?>

					<?php if(!empty( $settings['shape_image3']['id'] )) : ?>
					<div class="slider-two_pattern-three"
						style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image3']['id'])); ?>)"></div>
					<?php endif; ?>
					<!-- Slide -->
					<div class="slide">
						<div class="container">
							<div class="row clearfix">
								<div class="content-column col-lg-6 col-md-12 col-sm-12">
									<div class="slider-two_content">
										<?php if(!empty( $item['title'] )) : ?>
										<h2 class="slider-two_heading"><?php echo wp_kses($item['title'], true);?></h2>
										<?php endif; ?>

										<?php if(!empty( $item['text'] )) : ?>
										<div class="slider-two_text"><?php echo wp_kses($item['text'], true);?></div>
										<?php endif; ?>

										<?php if(!empty( $item['button_text'] || $item['button_link']['url'] )) : ?>
										<!-- Button Box -->
										<div class="button-box">
											<a class="btn-style-four theme-btn" href="<?php echo esc_url($item['button_link']['url']); ?>">
												<div class="btn-wrap">
													<span class="text-one">
														<?php echo wp_kses($item['button_text'], true);?>
														<i class="fas fa-arrow-circle-right fa-fw"></i></span>
													<span class="text-two">
														<?php echo wp_kses($item['button_text'], true);?>
														<i class="fas fa-arrow-circle-right fa-fw"></i></span>
												</div>
											</a>
										</div>
										<?php endif; ?>
									</div>
								</div>
								<div class="image-column col-lg-6 col-md-12 col-sm-12">
									<?php if(!empty( $item['image']['id'] )) : ?>
									<div class="image">
										<span class="color-layer"></span>
										<img src="<?php echo esc_url(wp_get_attachment_url($item['image']['id'])); ?>" alt="" />
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach;?>
			</div>
		</div>
	</section>


	<?php elseif($settings['style'] == 'style2' ) : ?>
	<section class="slider-one">
		<div class="slider-one_pattern" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>)"></div>
		<div class="imi-slider-wrapper-3 swiper">
			<div class="swiper-wrapper">
				<?php foreach($settings['slides'] as $key => $item):?>
				<!-- Swiper Slide -->
				<div class="swiper-slide">
					<!-- Slide -->
					<div class="slide">
						<div class="container">
							<div class="slider-one_content">
								<?php if(!empty( $item['subtitle'] )) : ?>
								<div class="slider-one_title"><?php echo wp_kses($item['subtitle'], true);?></div>
								<?php endif; ?>

								<?php if(!empty( $item['title'] )) : ?>
								<h2 class="slider-one_heading"><?php echo wp_kses($item['title'], true);?></h2>
								<?php endif; ?>

								<?php if(!empty( $item['text'] )) : ?>
								<div class="slider-one_text"><?php echo wp_kses($item['text'], true);?></div>
								<?php endif; ?>

								<?php if(!empty( $item['button_text'] )) : ?>
								<!-- Button Box -->
								<div class="button-box">
									<a class="btn-style-two theme-btn" href="<?php echo esc_url($item['button_link']['url']); ?>">
										<div class="btn-wrap">
											<span class="text-one"><?php echo wp_kses($item['button_text'], true);?>
												<i>
													<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-2.png" alt="" />
												</i>
											</span>
											<span class="text-two"><?php echo wp_kses($item['button_text'], true);?>
												<i>
													<img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/icon/arrow-right-1.png" alt="" />
												</i>
											</span>
										</div>
									</a>
								</div>
								<?php endif;?>
							</div>
						</div>
						<?php if(!empty( $item['banner_image']['id'] )) : ?>
						<div class="side-image">
							<span class="color-layer"></span>
							<img src="<?php echo esc_url(wp_get_attachment_url($item['banner_image']['id'])); ?>" alt="" />
						</div>
						<?php endif;?>
					</div>
				</div>
				<?php endforeach;?>
			</div>
		</div>
	</section>
	<?php else : ?>
    <!-- Start of Slider section
	============================================= -->
	<section id="imi-slider" class="imi-slider-section position-relative">
		<div class="imi-slider-wrapper swiper">
			<div class="swiper-wrapper">
            	<?php foreach($settings['slides'] as $key => $item):?>
				<div class="swiper-slide">
					<div class="imi-slider-items position-relative">
						<div class="imi-slider-img-wrapper position-absolute">
							<?php if(!empty( $item['banner_image']['id'] )) : ?>
							<div class="slider-img1">
								<img src="<?php echo esc_url(wp_get_attachment_url($item['banner_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							</div>
							<?php endif;?>

							<?php if(!empty( $item['image']['id'] )) : ?>
							<div class="slider-img2">
								<img src="<?php echo esc_url(wp_get_attachment_url($item['image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							</div>
							<?php endif;?>
						</div>
						<div class="container">
							<div class="imi-slider-text headline pera-content">
								<?php if(!empty( $item['title'] )) : ?>
								<h1><?php echo wp_kses($item['title'], true);?></h1>
								<?php endif; ?>

								<?php if(!empty( $item['text'] )) : ?>
								<p><?php echo wp_kses($item['text'], true);?></p>
								<?php endif; ?>

								<?php if(!empty( $item['form_title'] || $item['mailchimp_form_url'] )) : ?>
								<div class="imi-slider-newsletter">
									<span class="newsletter-title text-uppercase"><?php echo wp_kses($item['form_title'], true);?></span>
									<?php echo do_shortcode( $item['mailchimp_form_url'] );?>
								</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
                <?php endforeach;?>
			</div>
		</div>
		<div class="next-prev-btn">
			<div class="swiper-main-next"><i class="fas fa-arrow-up"></i></div>
			<div class="swiper-main-prev"><i class="fas fa-arrow-down"></i></div>
		</div>
	</section>
	<!-- End of Slider section
	============================================= -->
      <?php
	  endif;
    }
}