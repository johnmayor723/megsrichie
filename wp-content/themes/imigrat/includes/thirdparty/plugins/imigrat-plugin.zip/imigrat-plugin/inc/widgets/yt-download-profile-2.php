<?php
// Control core classes for avoid errors
//
// Create a widget 1
//
CSF::createWidget('yt_download_profile_2', array(
    'title'       => esc_html__('YT Download Profile 2'),
    'classname'   => 'yt-download-profile-2',
    'description' => esc_html__('Show download profile 2'),
    'fields'      => array(
        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   => 'Title',
        ),
		array(
			'id'      => 'download_links_group',
			'type'    => 'group',
			'title'   => 'Group',
			'fields'    => array(
				array(
					'id'      => 'download_sub_title',
					'type'    => 'text',
					'title'   => esc_html__('Sub Title', 'imigrat'),
				),
				array(
					'id'	=> 'download_title',
					'type'  => 'text',
					'title' => esc_html__('Title', 'imigrat'),
				),
				array(
					'id'      => 'download_link',
					'type'    => 'link',
					'title'   => esc_html__('Download Link'),
					'default' => '#',
				),
			
			)
		),
    )
));
//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_download_profile_2') ) {
    function yt_download_profile_2($args, $instance) {
        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/profile-link-2.php';
    }
}
