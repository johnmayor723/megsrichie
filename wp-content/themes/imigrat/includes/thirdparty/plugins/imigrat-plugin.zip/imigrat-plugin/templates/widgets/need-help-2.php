<?php

extract($args);
echo wp_kses_post($before_widget); ?>


<div class="contact-cta-widget text-center ul-li-block">
    <?php if ($instance['widget_bg_img']) { ?>
    <div class="cta-logo">
        <img src="<?php echo esc_url(wp_get_attachment_url($instance['widget_bg_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
    </div>
    <?php } ?>
    
    <?php if ($instance['help_title']) { ?>
    <div class="cta-text">
       <?php echo wp_kses_post($instance['help_title']); ?>
    </div>
    <?php } ?>
    
    <?php if($instance['help_btn_link']['url'] || $instance['help_btn_title']){ ?>
    <div class="cta-btn">
        <a href="<?php echo esc_url($instance['help_btn_link']['url']); ?>"><?php echo wp_kses_post($instance['help_btn_title']); ?> <i class="far fa-long-arrow-right"></i></a>
    </div>
    <?php } ?>
</div>

<?php
echo wp_kses_post($after_widget);
