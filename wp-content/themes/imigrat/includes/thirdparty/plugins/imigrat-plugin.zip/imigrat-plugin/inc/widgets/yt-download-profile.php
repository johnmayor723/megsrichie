<?php
// Control core classes for avoid errors
//
// Create a widget 1
//
CSF::createWidget('yt_download_profile', array(
    'title'       => esc_html__('YT Download Profile'),
    'classname'   => 'yt-download-profile',
    'description' => esc_html__('Show download profile'),
    'fields'      => array(
        array(
            'id'      => 'download_btn_title',
            'type'    => 'text',
            'title'   => esc_html__('Button Title'),
        ),
        array(
            'id'      => 'profile_link',
            'type'    => 'link',
            'title'   => esc_html__('Profile Link'),
            'default' => '#',
        ),
    )
));
//
// Front-end display of widget example 1
// Attention: This function named considering above widget base id.
//
if ( ! function_exists('yt_download_profile') ) {
    function yt_download_profile($args, $instance) {
        include IMIGRATPLUGIN_PLUGIN_PATH . 'templates/widgets/profile-link.php';
    }
}
