<?php
namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Social_Links extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_social_links';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Social Links', 'imigrat' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-social-icons';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}


	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		// design style section
		$this->start_controls_section(
			'design_style_section',
			[
				'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
			]
		);

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
					'style2'  => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
            ]
        );

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Section Bg Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'style' => 'style2',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'funfacts',
			[
				'label' => esc_html__( 'Social Links', 'imigrat' ),
			]
		);
		//Our Slider
		$repeater = new Repeater();

		// icon
        $repeater->add_control(
			'icon',
			[
				'label'      => __('Icon', 'elementhelper'),
				'type'       => Controls_Manager::ICONS,
				'show_label' => true,
				'default'    => [
					'value'   => 'far fa-grin-wink',
					'library' => 'solid',
				],
			]
		);

        // link
        $repeater->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'imigrat' ),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__( 'https://your-link.com', 'imigrat' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );

		$this->add_control(
			'slides',
			[
				'label'  => __('Add Slide Item', 'imigrat'),
				'type'   => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

		/** Style Tab **/
		$this->register_style_background_controls();
    }

	/************************************************************************
								Tab Style Start
	*************************************************************************/

	protected function register_style_background_controls()
	{

		/**Loop Style**/
		$this->start_controls_section(
			'loop_style',
			[
				'label' => esc_html__('LOOP CONTENT STYLE SETTING', 'imigrat'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		//Title Style
		$this->add_control(
			'show_loop_title_style',
			[
				'label'       => __( 'ON/OFF  Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_title_typography',
                'label' => __('Title Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-counter-item h3',
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_title_color',
            [
                'label' => __('Title Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-counter-item h3' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'funfact_borders_color',
            [
                'label' => __('Left/Right Border Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-counter-item h3' => 'border-color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_title_style'    => 'yes',
				]
            ]
        );
		//Content Style
		$this->add_control(
			'show_loop_value_style',
			[
				'label'       => __( 'ON/OFF  Counter Value Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'loop_value_typography',
                'label' => __('Counter Value Typography', 'imigrat'),
                'selector' =>
                    '{{WRAPPER}} .imi-counter-item p',
                'separator' => 'before',
				'condition'             => [
					'show_loop_value_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'loop_value_color',
            [
                'label' => __('Counter Value Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-counter-item p' => 'color: {{VALUE}}'
                ],
                'separator' => 'before',
				'condition'             => [
					'show_loop_value_style'    => 'yes',
				]
            ]
        );
		$this->end_controls_section();
	}
	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if( $settings['style'] == 'style2' ) : ?>
	<section class="social-share_one style-two"
		<?php if(!empty( $settings['bg_image']['id'] )) : ?>
		style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)"
		<?php endif; ?>
		>
		<div class="container">
			<div class="row clearfix">
				<!-- Title Column -->
				<div class="title-column col-lg-4 col-md-12 col-sm-12">
					<h3><?php echo wp_kses($settings['title'], true) ;?></h3>
				</div>
				<!-- Social Column -->
				<div class="social-column col-lg-8 col-md-12 col-sm-12">
					<!-- Social Box -->
					<ul class="social-share_one-icons">
						<?php foreach($settings['slides'] as $key => $item):?>
                        <li>
                            <a href="<?php echo esc_url($item['link']['url']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['icon'] ); ?>
                            </a>
                        </li>
                        <?php endforeach;?>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<?php else : ?>
    <section class="social-share_one">
        <div class="container">
            <div class="row clearfix">
                <div class="title-column col-lg-4 col-md-12 col-sm-12">
                    <h3><?php echo wp_kses($settings['title'], true) ;?></h3>
                </div>
                <div class="social-column col-lg-8 col-md-12 col-sm-12">
                    <ul class="social-share_one-icons">
                        <?php foreach($settings['slides'] as $key => $item):?>
                        <li>
                            <a href="<?php echo esc_url($item['link']['url']); ?>">
                                <?php \Elementor\Icons_Manager::render_icon( $item['icon'] ); ?>
                            </a>
                        </li>
                        <?php endforeach;?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <?php
	endif;
	}
}