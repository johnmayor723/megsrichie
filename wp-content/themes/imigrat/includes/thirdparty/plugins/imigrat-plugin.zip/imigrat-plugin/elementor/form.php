<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Widget_Base;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Text_Stroke;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Form extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_form';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Form', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return ['imigrat'];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

        // design style section
        $this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

        // design style section
        $this->add_control(
            'layout_control',
            [
                'label'       => esc_html__( 'Layout Style', 'imigrat' ),
                'label_block' => true,
                'type'        => Controls_Manager::SELECT,
                'default'     => '1',
                'options'     => [
                    '1' => esc_html__( 'Style One ', 'imigrat' ),
                    '2' => esc_html__( 'Style Two ', 'imigrat' ),
                    '3' => esc_html__( 'Style Three ', 'imigrat' ),
                    '4' => esc_html__( 'Style Four ', 'imigrat' ),
                    '5' => esc_html__( 'Style Five ', 'imigrat' ),
                    '6' => esc_html__( 'Style Six ', 'imigrat' ),
                    '7' => esc_html__( 'Style Seven ', 'imigrat' ),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label'     => esc_html__( 'CONTENT SECTION', 'imigrat' ),
                'condition' => [
                    'layout_control' => ['5', '6', '7'],
                ],
            ]
        );

        // section heading
        $this->add_control(
            'section_heading',
            [
                'label'       => esc_html__( 'Section Heading', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Enter your Section Heading', 'imigrat' ),
                'default'     => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),
                'condition'   => [
                    'layout_control' => ['7'],
                ],
            ]
        );

        // section description
        $this->add_control(
            'section_description',
            [
                'label'       => esc_html__( 'Section Description', 'imigrat' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Enter your Section Description', 'imigrat' ),
                'default'     => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),
                'condition'   => [
                    'layout_control' => ['7'],
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => esc_html__( 'Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
                'default'     => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

            ]
        );

        $this->add_control(
            'text',
            [
                'label'       => esc_html__( 'Text', 'imigrat' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
                'default'     => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'image_section',
            [
                'label'     => esc_html__( 'IMAGE SECTION', 'imigrat' ),
                'condition' => [
                    'layout_control' => ['5', '6', '7'],
                ],
            ]
        );

        $this->add_control(
            'bg_image',
            [
                'label'   => esc_html__( 'Section Bg Image ', 'imigrat' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );

        $this->add_control(
            'image1',
            [
                'label'   => esc_html__( 'Image 1', 'imigrat' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );

        $this->add_control(
            'image2',
            [
                'label'     => esc_html__( 'Image 2', 'imigrat' ),
                'type'      => Controls_Manager::MEDIA,
                'default'   => ['url' => Utils::get_placeholder_image_src()],
                'condition' => [
                    'layout_control' => ['5'],
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'skill_section',
            [
                'label'     => esc_html__( 'COUNT SECTION', 'imigrat' ),
                'condition' => [
                    'layout_control' => ['5'],
                ],
            ]
        );

        $repeater = new Repeater();

        // count icon image
        $repeater->add_control(
            'count_icon',
            [
                'label'   => esc_html__( 'Count Icon', 'imigrat' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => ['url' => Utils::get_placeholder_image_src()],
            ]
        );

        // count number
        $repeater->add_control(
            'count_number',
            [
                'label'   => esc_html__( 'Count Number', 'imigrat' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( '75', 'imigrat' ),
            ]
        );

        $repeater->add_control(
            'count_title',
            [
                'label'       => __( 'Count Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
                'dynamic'     => [
                    'active' => true,
                ],
                'label_block' => true,
                'placeholder' => __( 'Enter your List', 'imigrat' ),
            ]
        );

        $this->add_control(
            'count_lists',
            [
                'label'       => __( 'Add Count Item', 'imigrat' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ count_title }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'call_info_section',
            [
                'label'     => esc_html__( 'CALL INFO', 'imigrat' ),
                'condition' => [
                    'layout_control' => ['5'],
                ],
            ]
        );

        // call info text
        $this->add_control(
            'call_info_text',
            [
                'label'   => esc_html__( 'Call Info Text', 'imigrat' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( 'Call Us Now', 'imigrat' ),
            ]
        );

        // call info number
        $this->add_control(
            'call_info_number',
            [
                'label'   => esc_html__( 'Call Info Number', 'imigrat' ),
                'type'    => Controls_Manager::TEXT,
                'default' => esc_html__( '+123 456 7890', 'imigrat' ),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'form',
            [
                'label' => esc_html__( 'Imigrat Form', 'imigrat' ),
            ]
        );

        $this->add_control(
            'form_bg_image',
            [
                'label'       => __( 'Form BG Image1', 'imigrat' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => ['url' => Utils::get_placeholder_image_src()],
                'condition'   => [
                    'layout_control' => '1',
                ],
            ]
        );
        $this->add_control(
            'form_title',
            [
                'label'       => esc_html__( 'Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Enter your title', 'imigrat' ),
                'default'     => esc_html__( 'Trusted By Thousand', 'imigrat' ),
                'condition'   => [
                    'layout_control' => ['1', '2'],
                ],
            ]
        );
        $this->add_control(
            'form_text',
            [
                'label'       => esc_html__( 'Title', 'imigrat' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__( 'Enter your title', 'imigrat' ),
                'default'     => esc_html__( 'Trusted By Thousand', 'imigrat' ),
                'condition'   => [
                    'layout_control' => ['1', '2'],
                ],
            ]
        );

        $this->add_control(
            'cf7_shortocde',
            [
                'label'       => esc_html__( 'Select Contact Form 7', 'imigrat' ),
                'type'        => Controls_Manager::SELECT,
                'label_block' => true,
                'options'     => get_contact_form_7_list(),
            ]
        );

        $this->end_controls_section();

        // contact info section
        $this->start_controls_section(
            'contact_info_section',
            [
                'label'     => esc_html__( 'CONTACT INFO', 'imigrat' ),
                'condition' => [
                    'layout_control' => ['7'],
                ],
            ]
        );

        $repeater = new Repeater();

        // contact info icon
        $repeater->add_control(
            'contact_info_icon',
            [
                'label'      => __( 'Icon', 'elementhelper' ),
                'type'       => Controls_Manager::ICONS,
                'show_label' => true,
                'default'    => [
                    'value'   => 'far fa-grin-wink',
                    'library' => 'solid',
                ],
            ]
        );

        // contact info label
        $repeater->add_control(
            'contact_info_label',
            [
                'label'       => esc_html__( 'Contact Info Label', 'imigrat' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Phone', 'imigrat' ),
                'label_block' => true,
            ]
        );

        // wp editor
        $repeater->add_control(
            'contact_info_text',
            [
                'label' => esc_html__( 'Contact Info Text', 'imigrat' ),
                'type'  => Controls_Manager::WYSIWYG,
            ]
        );

        // contact infos
        $this->add_control(
            'contact_infos',
            [
                'label'       => esc_html__( 'Add Contact Info', 'imigrat' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'title_field' => '{{{ contact_info_label }}}',
            ]
        );

        $this->end_controls_section();

        /************************************************************************
        Tab Style Start
         *************************************************************************/

        /**Service Box Style**/
        $this->start_controls_section(
            'general_box_style',
            [
                'label' => esc_html__( 'Box Setting', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs( 'imigrat_general_box_tab' );

        $this->start_controls_tab(
            'imigrat_general_box_normal',
            [
                'label' => __( 'Normal', 'imigrat' ),
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'general_box_bgtype',
                'label'    => __( 'Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' =>
                '{{WRAPPER}} .imi-consulting-contact-form-area,
							 {{WRAPPER}} .eligibility-form,
							 {{WRAPPER}} .imi-benifit-form-wrapper
							',
            ]
        );
        $this->add_responsive_control(
            'general_box_space',
            [
                'label'              => __( 'Space', 'imigrat' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => ['px', 'em', '%'],
                'selectors'          => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .eligibility-form'                 => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .imi-benifit-form-wrapper'         => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

                'frontend_available' => true,
            ]
        );
        $this->add_responsive_control(
            'general_box_padding',
            [
                'label'              => __( 'Padding', 'imigrat' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => ['px', 'em', '%'],
                'selectors'          => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .eligibility-form'                 => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .imi-benifit-form-wrapper'         => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

                'frontend_available' => true,
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'general_box_border_type',
                'selector'  =>
                '{{WRAPPER}} .imi-consulting-contact-form-area,
							 {{WRAPPER}} .eligibility-form,
							 {{WRAPPER}} .imi-benifit-form-wrapper
							',
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'general_box_shadow',
                'selector'  =>
                '{{WRAPPER}} .imi-consulting-contact-form-area,
							 {{WRAPPER}} .eligibility-form,
							 {{WRAPPER}} .imi-benifit-form-wrapper
							',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'general_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'  => 'before',
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .eligibility-form'                 => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .imi-benifit-form-wrapper'         => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        //Small Title Style
        $this->start_controls_section(
            'small_title_style',
            [
                'label'     => esc_html__( 'Small Title', 'imigrat' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_control' => '2',
                ],
            ]
        );
        $this->add_responsive_control(
            'small_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'small_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'small_title_bgtype',
                'label'    => __( 'Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle
						',
            ]
        );

        $this->add_control(
            'small_title_color',
            [
                'label'     => esc_html__( 'Text Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'small_title_typography',
                'label'    => __( 'Typography', 'cleanex' ),
                'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Stroke::get_type(),
            [
                'name'     => 'small_title_text_stroke',
                'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'small_title_text_shadow',
                'selector' => '{{WRAPPER}} .imi-section-title-2 .imi-subtitle',
            ]
        );

        $this->end_controls_section();

        //Title Style
        $this->start_controls_section(
            'title_style',
            [
                'label'     => esc_html__( 'Title', 'imigrat' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_control' => ['1', '2'],
                ],
            ]
        );

        $this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .imi-section-title-2 h2'                                         => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .imi-section-title-2 h2'                                         => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'title_bgtype',
                'label'    => __( 'Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' => '
						{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text h3,
						{{WRAPPER}} .imi-section-title-2 h2',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Text Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text h3' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .imi-section-title-2 h2'                                         => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __( 'Typography', 'imigrat' ),
                'selector' => '
					{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text h3,
					{{WRAPPER}} .imi-section-title-2 h2
				',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'title_text_shadow',
                'selector' => '
						{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text h3,
						{{WRAPPER}} .imi-section-title-2 h2',
            ]
        );

        $this->end_controls_section();
        //Text Style

        $this->start_controls_section(
            'text_style',
            [
                'label'     => esc_html__( 'Text', 'imigrat' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_control' => '1',
                ],
            ]
        );

        $this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'text_bgtype',
                'label'    => __( 'Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text p',
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'     => esc_html__( 'Text Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text p' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'text_typography',
                'label'    => __( 'Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text p',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name'     => 'text_text_shadow',
                'selector' => '{{WRAPPER}} .imi-consulting-contact-form-area .imi-consulting-title-text p',
            ]
        );

        $this->end_controls_section();

        /**Form Style**/
        $this->start_controls_section(
            'form_style',
            [
                'label'     => esc_html__( 'Form Style Setting', 'imigrat' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_control' => ['1', '2', '3', '5'],
                ],
            ]
        );
        $this->start_controls_tabs( 'imigrat_tabs_form' );

        $this->start_controls_tab(
            'imigrat_tab_form_normal',
            [
                'label' => __( 'Normal', 'imigrat' ),
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'form_bgtype',
                'label'    => __( 'Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' =>
                '{{WRAPPER}} .form-group input,
				{{WRAPPER}} .form-group textarea,
				{{WRAPPER}} .form-group select',
            ]
        );
        $this->add_responsive_control(
            'form_width_size',
            [
                'label'      => __( 'Width', 'imigrat' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%', 'custom'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .te-contact-form input'    => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form select'   => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form textarea' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'form_height_size',
            [
                'label'      => __( 'Height', 'imigrat' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%', 'custom'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .te-contact-form input'    => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form select'   => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form textarea' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'form_spacing',
            [
                'label'              => __( 'Spacing', 'imigrat' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => ['px', 'em', '%'],
                'selectors'          => [
                    '{{WRAPPER}} .te-contact-form input'    => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form select'   => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form textarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

                'frontend_available' => true,
            ]
        );
        $this->add_responsive_control(
            'form_padding',
            [
                'label'              => __( 'Padding', 'imigrat' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => ['px', 'em', '%'],
                'selectors'          => [
                    '{{WRAPPER}} .te-contact-form input'    => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form select'   => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

                'frontend_available' => true,
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'form_border_type',
                'selector'  =>
                '{{WRAPPER}} .te-contact-form input,
							 {{WRAPPER}} .te-contact-form select,
							 {{WRAPPER}} .te-contact-form textarea',
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'form_border_box_shadow',
                'selector'  =>
                '{{WRAPPER}} .te-contact-form input,
							 {{WRAPPER}} .te-contact-form select,
							 {{WRAPPER}} .te-contact-form textarea',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'form_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'  => 'before',
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .te-contact-form input'    => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form select'   => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .te-contact-form textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'form_title_typography',
                'label'     => __( 'Text Typography', 'imigrat' ),
                'selector'  =>
                '{{WRAPPER}} .te-contact-form input,
							 {{WRAPPER}} .te-contact-form select,
							 {{WRAPPER}} .te-contact-form textarea',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'form_title_color',
            [
                'label'     => __( 'Text Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .te-contact-form input'    => 'color: {{VALUE}}',
                    '{{WRAPPER}} .te-contact-form select'   => 'color: {{VALUE}}',
                    '{{WRAPPER}} .te-contact-form textarea' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'form_icon_color',
            [
                'label'     => __( 'Form Icon Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .te-contact-form .imi-consulting-form-icon' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        // title style
        $this->start_controls_section(
            'title_style2',
            [
                'label' => esc_html__( 'Title Style Setting', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // title color
        $this->add_control(
            'title_color2',
            [
                'label'     => esc_html__( 'Title Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .title-box h4' => 'color: {{VALUE}}',
                ],
            ]
        );

        // title typograsphy
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography2',
                'label'    => __( 'Title Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .title-box h4',
            ]
        );

        $this->end_controls_section();

        // description style
        $this->start_controls_section(
            'description_style',
            [
                'label' => esc_html__( 'Description Style Setting', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // description color
        $this->add_control(
            'description_color',
            [
                'label'     => esc_html__( 'Description Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .title-box .text' => 'color: {{VALUE}}',
                ],
            ]
        );

        // description typograsphy
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'description_typography',
                'label'    => __( 'Description Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .title-box .text',
            ]
        );

        $this->end_controls_section();

        // counter style
        $this->start_controls_section(
            'counter_style',
            [
                'label' => esc_html__( 'Counter Style Setting', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // icon bg color
        $this->add_control(
            'counter_icon_bg_color',
            [
                'label'     => esc_html__( 'Icon Background Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .fluid-one_counter-icon' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        // number color
        $this->add_control(
            'counter_number_color',
            [
                'label'     => esc_html__( 'Number Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .counter' => 'color: {{VALUE}}',
                ],
            ]
        );

        // number typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'counter_number_typography',
                'label'    => __( 'Number Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .counter',
            ]
        );

        // title color
        $this->add_control(
            'counter_title_color',
            [
                'label'     => esc_html__( 'Title Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .fluid-one_count-box' => 'color: {{VALUE}}',
                ],
            ]
        );

        // title typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'counter_title_typography',
                'label'    => __( 'Title Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .fluid-one_count-box',
            ]
        );

        $this->end_controls_section();

        // call info style
        $this->start_controls_section(
            'call_info_style',
            [
                'label' => esc_html__( 'Call Info Style Setting', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        // call info wrapper bg color
		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'call_info_wrapper_bg_color',
                'label'    => __( 'Button Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' =>
                '{{WRAPPER}} .fluid-one_phone',
            ]
        );

        // icon bg color
        $this->add_control(
            'call_info_icon_bg_color',
            [
                'label'     => esc_html__( 'Icon Background Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .fluid-one_phone-icon' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        // icon color
        $this->add_control(
            'call_info_icon_color',
            [
                'label'     => esc_html__( 'Icon Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .fluid-one_phone-icon::before' => 'color: {{VALUE}}',
                ],
            ]
        );

        // call info label color
        $this->add_control(
            'call_info_label_color',
            [
                'label'     => esc_html__( 'Label Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .fluid-one_phone-box' => 'color: {{VALUE}}',
                ],
            ]
        );

        // call info label typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'call_info_label_typography',
                'label'    => __( 'Label Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .fluid-one_phone-box',
            ]
        );

        // number color
        $this->add_control(
            'call_info_number_color',
            [
                'label'     => esc_html__( 'Number Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .fluid-one_phone-box a' => 'color: {{VALUE}}',
                ],
            ]
        );

        // number typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'call_info_number_typography',
                'label'    => __( 'Number Typography', 'imigrat' ),
                'selector' => '{{WRAPPER}} .fluid-one_phone-box a',
            ]
        );

        $this->end_controls_section();

        /**Button Style**/
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__( 'Button Style Setting', 'imigrat' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs( 'imigrat_tabs_btn' );

        $this->start_controls_tab(
            'imigrat_tab_btn_normal',
            [
                'label' => __( 'Normal', 'imigrat' ),
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'btn_bgtype',
                'label'    => __( 'Button Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' =>
                '{{WRAPPER}} .imi-consulting-contact-form-area button,
							 {{WRAPPER}} .faq-one__link,
							 {{WRAPPER}} button,
							 {{WRAPPER}} .theme-btn
							 ',
            ]
        );
        $this->add_responsive_control(
            'btn_width_size',
            [
                'label'      => __( 'Width', 'imigrat' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%', 'custom'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .faq-one__link'                           => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} button'                                   => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .theme-btn'                               => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'btn_height_size',
            [
                'label'      => __( 'Height', 'imigrat' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%', 'custom'],
                'range'      => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%'  => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .faq-one__link'                           => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} button'                                   => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .theme-btn'                               => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'btn_padding',
            [
                'label'              => __( 'Padding', 'imigrat' ),
                'type'               => Controls_Manager::DIMENSIONS,
                'size_units'         => ['px', 'em', '%'],
                'selectors'          => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .faq-one__link'                           => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} button'                                   => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .theme-btn'                               => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

                'frontend_available' => true,
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'      => 'btn_border_type',
                'selector'  =>
                '{{WRAPPER}} .imi-consulting-contact-form-area button,
							 {{WRAPPER}} .faq-one__link,
							 {{WRAPPER}} button,
							 {{WRAPPER}} .theme-btn
							 ',
                'separator' => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'      => 'border_box_shadow',
                'selector'  =>
                '{{WRAPPER}} .imi-consulting-contact-form-area button,
							 {{WRAPPER}} .faq-one__link,
							 {{WRAPPER}} button,
							 {{WRAPPER}} .theme-btn
							 ',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'btn_border_radius',
            [
                'label'      => esc_html__( 'Border Radius', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'separator'  => 'before',
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .faq-one__link'                           => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} button'                                   => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .theme-btn'                               => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'btn_title_typography',
                'label'     => __( 'Button Text Typography', 'imigrat' ),
                'selector'  =>
                '{{WRAPPER}} .imi-consulting-contact-form-area button,
							 {{WRAPPER}} .faq-one__link,
							 {{WRAPPER}} button,
							 {{WRAPPER}} .theme-btn
							 ',
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'btn_title_color',
            [
                'label'     => __( 'Button Text Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one__link'                           => 'color: {{VALUE}}',
                    '{{WRAPPER}} button'                                   => 'color: {{VALUE}}',
                    '{{WRAPPER}} .theme-btn'                               => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'imigrat_tab_btn_hover',
            [
                'label' => __( 'Hover', 'imigrat' ),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'btn_hover_bg_bgtype',
                'label'    => __( 'Button Hover Background', 'imigrat' ),
                'types'    => ['classic', 'gradient'],
                'selector' =>
                '{{WRAPPER}} .imi-consulting-contact-form-area button:hover,
							 {{WRAPPER}} .faq-one__link:hover,
							 {{WRAPPER}} button:hover,
							 {{WRAPPER}} .theme-btn:hover
							 ',
            ]
        );
        $this->add_control(
            'btn_border_hover_color',
            [
                'label'     => __( 'Button Border Hover Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button:hover' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one__link:hover'                           => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} button:hover'                                   => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .theme-btn:hover'                               => 'border-color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        $this->add_control(
            'btn_title_hover_color',
            [
                'label'     => __( 'Button Text Hover Color', 'imigrat' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-contact-form-area button:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .faq-one__link:hover'                           => 'color: {{VALUE}}',
                    '{{WRAPPER}} button:hover'                                   => 'color: {{VALUE}}',
                    '{{WRAPPER}} .theme-btn:hover'                               => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    /**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html( 'post' );
        $layout = $settings['layout_control'];
        ?>

    <?php if ( $layout == 7 ): ?>
		<section class="consult-two"
			<?php if ( !empty( $settings['bg_image']['id'] ) ): ?>
			style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $settings['bg_image']['id'] ) ); ?>)">
			<?php endif;?>
		>
		<div class="container">
			<div class="row clearfix">
				<!-- Content Column -->
				<div class="content-column col-lg-8 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<?php if ( !empty( $settings['section_heading'] ) ): ?>
							<h2><?php echo wp_kses( $settings['section_heading'], true ); ?></h2>
							<?php endif;?>

							<?php if ( !empty( $settings['section_description'] ) ): ?>
							<div class="text"><?php echo wp_kses( $settings['section_description'], true ); ?></div>
							<?php endif;?>
						</div>
						<ul class="consult-two_list">
							<?php foreach ( $settings['contact_infos'] as $info ): ?>
							<li>
								<span class="icon d-flex justify-content-center align-items-center">
								<?php \Elementor\Icons_Manager::render_icon( $info['contact_info_icon'] );?>
								</span>
								<strong><?php echo wp_kses( $info['contact_info_label'], true ); ?></strong>
								<?php echo wp_kses( $info['contact_info_text'], true ); ?>
							</li>
							<?php endforeach;?>
						</ul>
						<?php if ( !empty( $settings['image1']['id'] ) ): ?>
						<div class="consult-image">
							<img src="<?php echo esc_url( wp_get_attachment_url( $settings['image1']['id'] ) ); ?>" alt="" />
						</div>
						<?php endif;?>
					</div>
				</div>
				<!-- Form Column -->
				<div class="form-column col-lg-4 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="title-box">
							<?php if ( !empty( $settings['title'] ) ): ?>
							<h4><?php echo wp_kses( $settings['title'], true ); ?></h4>
							<?php endif;?>

							<?php if ( !empty( $settings['text'] ) ): ?>
							<div class="text"><?php echo wp_kses( $settings['text'], true ); ?></div>
							<?php endif;?>
						</div>

						<!-- Fluid Form -->
						<div class="fluid-form">
							<?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
						</div>
						<!-- End Fluid Form -->

					</div>
				</div>
			</div>
		</div>
	</section>
    <?php elseif ( $layout == 6 ): ?>
		<section class="consult-one"
			<?php if ( !empty( $settings['bg_image']['id'] ) ): ?>
			style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $settings['bg_image']['id'] ) ); ?>)">
			<?php endif;?>
		>
		<div class="container">
			<div class="row clearfix">
				<div class="image-column col-lg-7 col-md-12 col-sm-12">
					<?php if ( !empty( $settings['image1']['id'] ) ): ?>
					<div class="image">
						<img src="<?php echo esc_url( wp_get_attachment_url( $settings['image1']['id'] ) ); ?>" alt="" />
					</div>
					<?php endif;?>
				</div>
				<div class="form-column col-lg-5 col-md-12 col-sm-12">
					<div class="form-column_inner">
						<div class="fluid-form-box">
							<div class="title-box">
								<?php if ( !empty( $settings['title'] ) ): ?>
								<h4><?php echo wp_kses( $settings['title'], true ); ?></h4>
								<?php endif;?>

								<?php if ( !empty( $settings['text'] ) ): ?>
								<div class="text"><?php echo wp_kses( $settings['text'], true ); ?></div>
								<?php endif;?>
							</div>

							<div class="fluid-form">
								<?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <?php elseif ( $layout == 5 ): ?>
	<section class="fluid-one">
		<div class="clearfix">
			<!-- Left Column -->
			<div class="left-column"
				<?php if ( !empty( $settings['bg_image']['id'] ) ): ?>
				style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $settings['bg_image']['id'] ) ); ?>)">
				<?php endif;?>
				<div class="left-column_inner">
					<div class="fluid-form-box">
						<div class="title-box">

							<?php if ( !empty( $settings['title'] ) ): ?>
							<h4><?php echo wp_kses( $settings['title'], true ); ?></h4>
							<?php endif;?>

							<?php if ( !empty( $settings['text'] ) ): ?>
							<div class="text"><?php echo wp_kses( $settings['text'], true ); ?></div>
							<?php endif;?>

						</div>

						<!-- Fluid Form -->
						<div class="fluid-form">
							<?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
						</div>
						<!-- End Fluid Form -->

					</div>
				</div>
			</div>
			<!-- Right Column -->
			<div class="right-column"
				<?php if ( !empty( $settings['image2']['id'] ) ): ?>
				style="background-image: url(<?php echo esc_url( wp_get_attachment_url( $settings['image2']['id'] ) ); ?>)">
				<?php endif;?>
				<div class="right-column_inner">
					<!-- Fluid One Counter -->
					<div class="fluid-one_counter">

						<?php foreach ( $settings['count_lists'] as $count ): ?>
						<div class="fluid-one_counter-box">
							<?php if ( !empty( $count['count_icon']['id'] ) ): ?>
							<div class="fluid-one_counter-icon">
								<img src="<?php echo esc_url( wp_get_attachment_url( $count['count_icon']['id'] ) ); ?>" alt="" />
							</div>
							<?php endif;?>

							<div class="fluid-one_count-box">
								<span class="counter"><?php echo wp_kses( $count['count_number'], true ); ?></span>
								<?php echo wp_kses( $count['count_title'], true ); ?>
							</div>
						</div>
						<?php endforeach;?>

					</div>

					<!-- Side Image -->
					<?php if ( !empty( $settings['image1']['id'] ) ): ?>
					<div class="side-image">
						<img src="<?php echo esc_url( wp_get_attachment_url( $settings['image1']['id'] ) ); ?>" alt="" />
					</div>
					<?php endif;?>

					<!-- Fluid One Phone -->
					<div class="fluid-one_phone">
						<div class="fluid-one_phone-box">
							<div class="fluid-one_phone-icon fas fa-phone-alt fa-fw"></div>
							<?php echo wp_kses( $settings['call_info_text'], true ); ?> <br>
							<a href="tel:<?php echo esc_attr( $settings['call_info_number'] ); ?>"><?php echo wp_kses( $settings['call_info_number'], true ); ?></a>
						</div>
					</div>

				</div>
			</div>
		</div>
	</section>
    <?php elseif ( $layout == 4 ): ?>
	<div class="imi-contact-page-form-area">
        <?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
    </div>

	<?php elseif ( $layout == 3 ): ?>
	<div class="imi-check-eligibility-area wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1000ms">
        <div class="eligibility-form te-contact-form">
            <?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
        </div>
    </div>

	<?php elseif ( $layout == 2 ): ?>
    <div class="imi-benifit-form-wrapper">
        <div class="imi-section-title-2 headline-2 pera-content">
            <div class="imi-subtitle text-uppercase">
                <?php if ( $settings['form_title'] ) {?><?php echo wp_kses( $settings['form_title'], true ); ?><?php }?>
            </div>
            <?php if ( $settings['form_text'] ) {?><h2><?php echo wp_kses( $settings['form_text'], true ); ?></h2><?php }?>
        </div>
        <div class="te-contact-form">
		<?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
        </div>
    </div>

    <?php else: ?>

    <div class="imi-consulting-contact-form-area position-relative" data-background="<?php echo esc_url( wp_get_attachment_url( $settings['form_bg_image']['id'] ) ); ?>">
        <div class="imi-consulting-title-text headline pera-content">
            <?php if ( $settings['form_title'] ) {?><h3><?php echo wp_kses( $settings['form_title'], true ); ?></h3><?php }?>
            <?php if ( $settings['form_text'] ) {?><p><?php echo wp_kses( $settings['form_text'], true ); ?> </p><?php }?>
        </div>
        <?php if ( $settings['cf7_shortocde'] ) {?>
        <div class="imi-consulting-form-area te-contact-form">
            <?php echo do_shortcode( '[contact-form-7 id="' . esc_attr( $settings['cf7_shortocde'] ) . '"]' ); ?>
        </div>
        <?php }?>
    </div>

    <?php endif;
    }
}