<?php

extract($args);
echo wp_kses_post($before_widget); ?>

<?php if ($instance['download_btn_title'] || $instance['profile_link']['url']) { ?>
<div class="download-widget">
    <a href="<?php echo esc_url($instance['profile_link']['url']); ?>"><i class="fal fa-file-alt"></i> <?php echo wp_kses( $instance[ 'download_btn_title' ], true );?></a>
</div>
<?php } ?>

<?php
echo wp_kses_post($after_widget);
