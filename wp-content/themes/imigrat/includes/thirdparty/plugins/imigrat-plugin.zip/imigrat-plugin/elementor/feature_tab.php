<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Feature_Tab extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_feature_tab';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Feature Tab', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }

	/**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'design_style_section',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat'),
				),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
				'condition' => [
					'layout_control' => ['3'],
				],
            ]
        );

		$this->add_control(
			'shape1',
			[
				'label' => esc_html__('Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'shape2',
			[
				'label' => esc_html__('Shape 2 Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'shape3',
			[
				'label' => esc_html__('Shape 3 Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__( 'SECTION CONTENT', 'imigrat' ),
            ]
        );

		$this->add_control(
			'bg_image',
			[
			  	'label' => __( 'Background Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2']
				],
			]
	    );
		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['2', '3']
				],
			]
		);
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['2', '3']
				],
			]
		);

		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your title', 'imigrat' ),
				'default' => esc_html__( 'Sed ut perspiciatis unde omnis iste natus error sit voluptate accusantium laudantium totam rem aperiam', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['2', '3']
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'featre_section',
            [
                'label' => esc_html__( 'FEATURE SECTION', 'imigrat' ),
				'condition' => [
					'layout_control'      => ['1']
				],
            ]
        );

		//Our Slider
		$repeater = new Repeater();

		$repeater->add_control(
			'tab_title',
			[
				'label'       => __( 'Tab List Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab List Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'feature_image',
			[
			  	'label' => __( 'Feature Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$repeater->add_control(
			'sub_title',
			[
				'label'       => __( 'Sub Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'text',
			[
				'label'       => __( 'Text', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'amount_title',
			[
				'label'       => __( 'Amount Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Amount Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'percent_amount',
			[
				'label'       => __( 'Percent Amount', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Percent Amount', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'features_list',
			[
				'label'       => __( 'Feature List', 'imigrat' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'imigrat' ),
			]
		);
		$this->add_control(
			'features',
			[
				'label'                 => __('Add Tab item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'               => $repeater->get_controls(),
				'condition' => [
					'layout_control'      => ['1']
				],
				'default' => [
					[

						'list_icon'  => 'flaticon-insurance-3'
					],

				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
            'tab_section',
            [
                'label' => esc_html__( 'TAB SECTION', 'imigrat' ),
            ]
        );

		//Our Slider v2
		$repeater = new Repeater();

		// style control
		$repeater->add_control(
			'tab_style',
			[
				'label'   => __( 'Tab Style', 'imigrat' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1' => __( 'Style 1', 'imigrat' ),
					'style2' => __( 'Style 2', 'imigrat' ),
				],
			]
		);

		$repeater->add_control(
			'tab_title',
			[
				'label'       => __( 'Tab List Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab List Title', 'imigrat' ),
			]
		);
		$repeater->add_control(
			'tab_image1',
			[
			  	'label' => __( 'Tab Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$repeater->add_control(
			'tab_image2',
			[
			  	'label' => __( 'Tab Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
	    );
		$repeater->add_control(
			'tab_image3',
			[
			  	'label' => __( 'Tab Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'tab_style'      => ['style1']
				],
			]
	    );
		$repeater->add_control(
			'tab_image4',
			[
			  	'label' => __( 'Tab Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				  'condition' => [
					'tab_style'      => ['style1']
				],
			]
	    );

		// tab contet title
		$repeater->add_control(
			'tab_content_title',
			[
				'label'       => __( 'Tab Content Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Content Title', 'imigrat' ),
				'condition' => [
					'tab_style'      => ['style2']
				],
			]
		);

		// tab content
		$repeater->add_control(
			'tab_content',
			[
				'label'       => __( 'Tab Content', 'imigrat' ),
				'type'        => Controls_Manager::WYSIWYG,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Content', 'imigrat' ),
				'condition' => [
					'tab_style'      => ['style2']
				],
			]
		);

		// tab button text
		$repeater->add_control(
			'tab_button_text',
			[
				'label'       => __( 'Tab Button Text', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Button Text', 'imigrat' ),
				'condition' => [
					'tab_style'      => ['style2']
				],
			]
		);

		// tab button link
		$repeater->add_control(
			'tab_button_link',
			[
				'label'       => __( 'Tab Button Link', 'imigrat' ),
				'type'        => Controls_Manager::URL,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Tab Button Link', 'imigrat' ),
				'condition' => [
					'tab_style'      => ['style2']
				],
			]
		);

		$this->add_control(
			'tabs',
			[
				'label'                 => __('Add Tab item', 'imigrat'),
				'type'                  => Controls_Manager::REPEATER,
				'fields'                => $repeater->get_controls(),
				'condition' => [
					'layout_control'      => ['2', '3']
				],
				'default' => [
					[
						'list_icon'  => 'flaticon-insurance-3'
					],
				],
			]
		);
		$this->end_controls_section();

		/************************************************************************
								Tab Style Start
		*************************************************************************/

		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => ['1','2']
				]
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-benifit-tab-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-team-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-benifit-tab-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .imi-team-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-benifit-tab-section',
								'{{WRAPPER}} .imi-team-section',
			]
		);
		$this->end_controls_section();

		//Team Small Title Style
		$this->start_controls_section(
			'team_sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '2'
				]
			]
		);
		$this->add_responsive_control(
            'team_sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'team_sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'team_sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
			]
		);

		$this->add_control(
			'team_sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 .sub-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'team_sub_title_shape_color',
			[
				'label' => esc_html__( 'Sub Title Line Shape Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 .sub-title:before' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .imi-section-title-1 .sub-title:after' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'team_sub_title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'team_sub_title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'team_title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '2'
				]
			]
		);
		$this->add_responsive_control(
            'team_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
        $this->add_responsive_control(
            'team_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'team_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
			]
		);
		$this->add_control(
			'team_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'team_title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'team_title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
			]
		);
		$this->end_controls_section();

		//Text Style
		$this->start_controls_section(
			'team_text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '2'
				]
			]
		);
		$this->add_responsive_control(
            'team_text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
        $this->add_responsive_control(
            'team_text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'team_text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-1 p',
			]
		);
		$this->add_control(
			'team_text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-1 p',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'team_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-1 p',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'team_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-1 p',
			]
		);
		$this->end_controls_section();


		//Team Tab Button Style
		$this->start_controls_section(
			'team_tab_btn_style',
			[
				'label' => esc_html__( 'Team Tab Button Style', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '2'
				]
			]
		);
		$this->add_control(
			'team_tab_btn_color',
			[
				'label' => esc_html__( 'Tab Button Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'team_tab_btn_hover_color',
			[
				'label' => esc_html__( 'Tab Button Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link.active' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'team_tab_btn_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'team_tab_btn_stroke',
				'selector' => '{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'team_tab_btn_shadow',
				'selector' => '{{WRAPPER}} .imi-team-tab-btn .nav-tabs .nav-link',
			]
		);
		$this->end_controls_section();



		//Tabs Style
		$this->start_controls_section(
			'features_tabs_style',
			[
				'label' => esc_html__( 'Feature Tabs Style', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition'             => [
					'layout_control'    => '1'
				]
			]
		);
		$this->add_control(
			'show_tab_btn_title_style',
			[
				'label'       => __( 'ON/OFF Tab Button Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'tab_btn_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_tab_btn_title_style'    => 'yes',
				]
            ]
        );
		$this->add_responsive_control(
            'tab_btn_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_tab_btn_title_style'    => 'yes',
				]
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'tab_btn_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link',
				'condition'             => [
					'show_tab_btn_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'tab_btn_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_tab_btn_title_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tab_btn_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link',
				'condition'             => [
					'show_tab_btn_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'tab_btn_hover_color',
			[
				'label' => esc_html__( 'Text Hover Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link.active' => 'color: {{VALUE}};',
					'{{WRAPPER}} .imi-tab-benifit-tab-btn .nav-tabs .nav-link:hover' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_tab_btn_title_style'    => 'yes',
				]
			]
		);

		//Sub Title Style
		$this->add_control(
			'show_sub_title_style',
			[
				'label'       => __( 'ON/OFF Tab Sub Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 .sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 .sub-title' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'sub_title_shape_color',
			[
				'label' => esc_html__( 'Sub Title Line Shape Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 .sub-title:before' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .imi-section-title-1 .sub-title:after' => 'background-color: {{VALUE}};',
				],
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-1 .sub-title',
				'condition'             => [
					'show_sub_title_style'    => 'yes',
				]
			]
		);

		//Title Style
		$this->add_control(
			'show_title_style',
			[
				'label'       => __( 'ON/OFF Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-1 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-1 h2' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_title_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '{{WRAPPER}} .imi-section-title-1 h2',
				'condition'             => [
					'show_title_style'    => 'yes',
				]
			]
		);

		//Text Style
		$this->add_control(
			'show_text_style',
			[
				'label'       => __( 'ON/OFF Text Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_text_style'    => 'yes',
				]
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_text_style'    => 'yes',
				]
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p',
				'condition'             => [
					'show_text_style'    => 'yes',
				]
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_text_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p',
				'condition'             => [
					'show_text_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p',
				'condition'             => [
					'show_text_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}} .imi-tab-benifit-tab-text-area .imi-section-title-1 p',
				'condition'             => [
					'show_text_style'    => 'yes',
				]
			]
		);

		//Processing Title Style
		$this->add_control(
			'show_processing_title_style',
			[
				'label'       => __( 'ON/OFF Processing Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'processing_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-processing-cost-area .process-title',
				'condition'             => [
					'show_processing_title_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'processing_title_color',
			[
				'label' => esc_html__( 'Processing Title Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-processing-cost-area .process-title' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_processing_title_style'    => 'yes',
				]
			]
		);

		//Processing percent Style
		$this->add_control(
			'show_processing_percent_style',
			[
				'label'       => __( 'ON/OFF Processing Percentage Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'processing_percent_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-processing-cost .imi-processing-number',
				'condition'             => [
					'show_processing_percent_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'processing_percent_color',
			[
				'label' => esc_html__( 'Processing Percentage Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-processing-cost .imi-processing-number' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_processing_percent_style'    => 'yes',
				]
			]
		);

		//Feature List Style
		$this->add_control(
			'show_feature_list_style',
			[
				'label'       => __( 'ON/OFF Arrow Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-processing-cost .imi-processing-list li' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_feature_list_style'    => 'yes',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'cleanex'),
				'selector' => '{{WRAPPER}} .imi-processing-cost .imi-processing-list li',
				'condition'             => [
					'show_feature_list_style'    => 'yes',
				]
			]
		);
		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-processing-cost .imi-processing-list li' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_feature_list_style'    => 'yes',
				]
			]
		);
		$this->end_controls_section();

	}




	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$layout = $settings[ 'layout_control' ];
	?>
    <?php if( $layout == 3 ):?>
	<section class="services-three">
		<?php if(!empty( $settings['shape1']['id'] )) : ?>
		<div class="services-three_image" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape1']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['shape2']['id'] )) : ?>
		<div class="services-three_icon" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape2']['id'])); ?>)"></div>
		<?php endif; ?>

		<?php if(!empty( $settings['shape3']['id'] )) : ?>
		<div class="services-three_icon-two" style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['shape3']['id'])); ?>)"></div>
		<?php endif; ?>
		<div class="container">
			<div class="sec-title-two light centered">
				<?php if(!empty( $settings['sub_title'] )) : ?>
				<div class="title"><?php echo wp_kses($settings['sub_title'], true); ?></div>
				<?php endif; ?>

				<?php if(!empty( $settings['title'] )) : ?>
				<h2><?php echo wp_kses($settings['title'], true); ?></h2>
				<?php endif; ?>

				<?php if(!empty( $settings['text'] )) : ?>
				<div class="text"><?php echo wp_kses($settings['text'], true); ?></div>
				<?php endif; ?>
			</div>
			<!-- Product Info Tabs -->
			<div class="product-info-tabs">
				<!-- Product Tabs -->
				<div class="prod-tabs tabs-box">

					<!-- Tab Btns -->
					<ul class="tab-btns tab-buttons clearfix">
						<?php foreach($settings['tabs'] as $key => $item):?>
						<li data-tab="#prod-plan-<?php echo esc_attr($key);?>" class="tab-btn <?php if($key == 1) echo 'active-btn'; ?>">
							<?php if(!empty( $item['tab_image1']['id'] )) : ?>
							<span><img src="<?php echo esc_url(wp_get_attachment_url($item['tab_image1']['id'])); ?>" alt="" /></span>
							<?php endif; ?>
							<?php echo wp_kses($item['tab_title'], true); ?>
						</li>
						<?php endforeach;?>
					</ul>

					<!-- Tabs Container -->
					<div class="tabs-content">
						<?php foreach($settings['tabs'] as $key => $item):?>
						<div class="tab <?php if($key == 1) echo 'active-tab';?>" id="prod-plan-<?php echo esc_attr($key);?>">
							<div class="content">
								<?php if(!empty( $item['tab_image2']['id'] )) : ?>
								<div class="image">
									<img src="<?php echo esc_url(wp_get_attachment_url($item['tab_image2']['id'])); ?>" alt="" />
								</div>
								<?php endif; ?>

								<?php if(!empty( $item['tab_content_title'] )) : ?>
								<h4><?php echo wp_kses($item['tab_content_title'], true); ?></h4>
								<?php endif; ?>

								<?php if(!empty( $item['tab_content'] )) : ?>
								<div class="text"><?php echo wp_kses($item['tab_content'], true); ?></div>
								<?php endif; ?>

								<?php if(!empty( $item['tab_button_link']['url'] || $item['tab_button_text'] )) : ?>
								<!-- Button Box -->
								<div class="button-box">
									<a class="btn-style-five theme-btn" href="<?php echo esc_url($item['tab_button_link']['url']) ?>">
										<div class="btn-wrap">
											<span class="text-one"><?php echo wp_kses($item['tab_button_text'], true); ?>
												<i class="fas fa-arrow-circle-right fa-fw"></i></span>
											<span class="text-two"><?php echo wp_kses($item['tab_button_text'], true); ?>
												<i class="fas fa-arrow-circle-right fa-fw"></i></span>
										</div>
									</a>
								</div>
								<?php endif; ?>
							</div>
						</div>
						<?php endforeach;?>
					</div>
				</div>
			</div>
		</div>
	</section>
    <?php elseif( $layout == 2 ):?>

    <!-- Start of Team section
	============================================= -->
	<section id="imi-team" class="imi-team-section" <?php if($settings['bg_image']['id']){ ?>data-background="<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>"<?php } ?>>
		<div class="container">
			<div class="imi-team-content">
				<div class="row">
					<div class="col-lg-6">
						<div class="imi-team-text-area">
							<div class="imi-section-title-1 pera-content headline wow fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
                            	<?php if($settings['sub_title']) { ?>
								<div class="sub-title text-uppercase position-relative">
									<?php echo wp_kses($settings['sub_title'], true); ?>
								</div>
                                <?php } ?>
                                <?php if($settings['title'] || $settings['text']){ ?>
								<h2>
									<?php if($settings['title']) { ?><?php echo wp_kses($settings['title'], true); ?><?php } ?>
								</h2>
								<?php if($settings['text']) { ?><p><?php echo wp_kses($settings['text'], true); ?></p><?php } ?>
                                <?php } ?>
							</div>
							<div class="imi-team-tab-btn wow fadeInLeft" data-wow-delay="200ms" data-wow-duration="1500ms">
								<ul class="nav nav-tabs"  role="tablist">
                                	<?php foreach($settings['tabs'] as $key => $item):?>
									<li class="nav-item" role="presentation">
										<button class="nav-link <?php if($key == 1) echo 'active';?>" id="imi_team_tab_1<?php echo esc_attr($key);?>" data-bs-toggle="tab" data-bs-target="#imi_team_tab_1_1<?php echo esc_attr($key);?>" type="button" role="tab"  aria-selected="<?php if($key == 0) echo 'true'; else echo 'false'; ?>"><?php echo wp_kses($item['tab_title'], true); ?></button>
									</li>
                                    <?php endforeach;?>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-6 wow fadeInRight" data-wow-delay="300ms" data-wow-duration="1500ms">
						<div class="imi-team-item-content">
							<div class="tab-content">
                            	<?php foreach($settings['tabs'] as $key => $item):?>
								<div class="tab-pane animated fadeInUp show <?php if($key == 1) echo 'active';?>" id="imi_team_tab_1_1<?php echo esc_attr($key);?>" role="tabpanel" aria-labelledby="imi_team_tab_1<?php echo esc_attr($key);?>">
									<div class="imi-team-list-item ul-li">
										<ul>
											<li><a href="<?php echo esc_url($item['tab_image1']['url']);?>"><img src="<?php echo esc_url(wp_get_attachment_url($item['tab_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></a></li>
											<li><a href="<?php echo esc_url($item['tab_image2']['url']);?>"><img src="<?php echo esc_url(wp_get_attachment_url($item['tab_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></a></li>
											<li><a href="<?php echo esc_url($item['tab_image3']['url']);?>"><img src="<?php echo esc_url(wp_get_attachment_url($item['tab_image3']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></a></li>
											<li><a href="<?php echo esc_url($item['tab_image4']['url']);?>"><img src="<?php echo esc_url(wp_get_attachment_url($item['tab_image4']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></a></li>
										</ul>
									</div>
								</div>
                                <?php endforeach;?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End of Team section
	============================================= -->

    <?php else:?>
        <!-- Start of benefit section
	============================================= -->
	<section id="imi-benifit-tab" class="imi-benifit-tab-section" <?php if($settings['bg_image']['id']){ ?>data-background="<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>"<?php } ?>>
		<div class="imi-benifit-tab-content d-flex align-items-center">
			<div class="imi-tab-benifit-tab-btn wow fadeInLeft" data-wow-delay="200ms" data-wow-duration="1500ms">
				<ul class="nav nav-tabs" role="tablist">
					<?php foreach($settings['features'] as $key => $item):?>
                    <li class="nav-item" role="presentation">
						<button class="nav-link <?php if($key == 1) echo 'active';?>" id="imi_tab_1<?php echo esc_attr($key);?>" data-bs-toggle="tab" data-bs-target="#imi_tab_1_1<?php echo esc_attr($key);?>" type="button" role="tab"  aria-selected="<?php if($key == 0) echo 'true'; else echo 'false'; ?>"><?php echo wp_kses($item['tab_title'], true); ?> <i class="fal fa-long-arrow-right"></i></button>
					</li>
					<?php endforeach;?>
				</ul>
			</div>
			<div class="tab-content">
				<?php foreach($settings['features'] as $keys => $item):?>
                <div class="tab-pane animated fadeInUp show <?php if($keys == 0) echo 'active';?>" id="imi_tab_1_1<?php echo esc_attr($keys);?>" role="tabpanel">
					<div class="imi-tab-benifit-tab-img-text-area d-flex align-items-center">
						<div class="imi-tab-benifit-tab-img-area">
							<div class="imi-tab-benifit-tab-img position-relative">
								<img src="<?php echo esc_url(wp_get_attachment_url($item['feature_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
							</div>
						</div>
						<div class="imi-tab-benifit-tab-text-area">
							<div class="imi-section-title-1 pera-content headline">
                            	<?php if($item['sub_title']) { ?>
								<div class="sub-title text-uppercase position-relative">
									<?php echo wp_kses($item['sub_title'], true); ?>
								</div>
                                <?php } ?>
								<h2><?php echo wp_kses($item['title'], true); ?></h2>
								<p><?php echo wp_kses($item['text'], true); ?></p>
							</div>
							<div class="imi-processing-cost-area">
								<span class="process-title"><?php echo wp_kses($item['amount_title'], true); ?></span>
								<div class="imi-processing-cost  d-flex align-items-center">
									<div class="imi-processing-number">
										<?php echo wp_kses($item['percent_amount'], true); ?>
									</div>
									<?php $features_list = $item['features_list'];
										if(!empty($features_list)){
										$features_list1 = explode("\n", ($features_list));
									?>
                                    <div class="imi-processing-list ul-li-block">
										<ul>
											<?php foreach($features_list1 as $features): ?>
                                            <li><?php echo wp_kses($features, true); ?></li>
                                            <?php endforeach; ?>
										</ul>
									</div>
                                    <?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				 <?php endforeach;?>
			</div>
		</div>
	</section>
	<!-- End of benefit section
	============================================= -->

    <?php endif;
    }
}