<?php
namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Float_Image extends Widget_Base {
	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'imigrat_float_image';
	}
	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Imigrat Float Image', 'imigrat' );
	}
	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image';
	}
	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'imigrat' ];
	}

	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'float_image',
			[
				'label' => esc_html__( 'Imigrat Float Image', 'imigrat' ),
			]
		);
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
					'3' => esc_html__( 'Style Three ', 'imigrat')
				),
			]
		);
		$this->add_control(
			'feature_image1',
			[
			  	'label' => __( 'Feature Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => ['1','2','3']
				],
			]
	    );
		$this->add_control(
			'shape_image',
			[
			  	'label' => __( 'Shape Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => '3'
				],
			]
	    );
		$this->add_control(
			'feature_image2',
			[
			  	'label' => __( 'Feature Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => '1'
				],
			]
	    );
		$this->add_control(
			'feature_image3',
			[
			  	'label' => __( 'Feature Image', 'imigrat' ),
			  	'type' => Controls_Manager::MEDIA,
			  	'label_block' => true,
			  	'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition' => [
					'layout_control'      => '1'
				],
			]
	    );


		$this->end_controls_section();
    }


	/**
     * Render button widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $allowed_tags = wp_kses_allowed_html('post'); 
		$layout = $settings[ 'layout_control' ];
	?>

		<?php if( $layout == 3 ):?>
        <div class="imi-pricing-about-section position-relative p-0 m-0">
            <div class="imi-pricing-about-content position-relative">
                <div class="imi-price-about-img position-absolute">
                    <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
                    <?php if($settings['shape_image']['id']){ ?><span class="side-shape2 position-absolute"><img src="<?php echo esc_url(wp_get_attachment_url($settings['shape_image']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>"></span><?php } ?>
                </div>
            </div>
        </div>
		<?php elseif( $layout == 2 ):?>

        <div class="imi-benifit-img">
            <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
        </div>

        <?php else:?>

        <div class="imi-about-img-wrapper-2 position-relative">
            <div class="imi-about-img wow fadeInLeft" data-wow-delay="400ms" data-wow-duration="1500ms">
                <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image1']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
            </div>
            <div class="imi-about-inner-img-1 position-absolute wow fadeInRight" data-wow-delay="500ms" data-wow-duration="1500ms">
                <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image2']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
            </div>
            <div class="imi-about-inner-img-2 position-absolute wow fadeInDown" data-wow-delay="600ms" data-wow-duration="1500ms">
                <img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_image3']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image','imigrat');?>">
            </div>
        </div>

    <?php endif;
	}
}