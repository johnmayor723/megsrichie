<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Phone_Info extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_phone_info';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Phone No', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'phone_info',
            [
                'label' => esc_html__( 'Imigrat Phone Info', 'imigrat' ),
            ]
        );
		$this->add_control(
			'layout_control',
			[
				'label'   => esc_html__( 'Layout Style', 'imigrat' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => array(
					'1' => esc_html__( 'Style One ', 'imigrat'),
					'2' => esc_html__( 'Style Two ', 'imigrat'),
				),
			]
		);
		$this->add_control(
			'icon',
			[
				'label' => esc_html__('Enter The icons', 'imigrat'),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'solid',
				],
				
			]
			
		);		
		$this->add_control(
			'phone_title',
			[
				'label' => esc_html__( 'Phone Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Phone Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),
				
			]
		);		
		$this->add_control(
			'phone_no',
			[
				'label' => esc_html__( 'Phone No', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Phone No', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),
				
			]
		);
		$this->end_controls_section();
	
	
	/************************************************************************
								Tab Style Start
	*************************************************************************/
	
		//General Style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__( 'General Setting', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'general_margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-cta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
        $this->add_responsive_control(
            'general_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-cta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'general_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-consulting-cta',				
			]
		);
		$this->end_controls_section();
		
		
		//Title Style		
		$this->start_controls_section(
			'phone_info_style',
			[
				'label' => esc_html__( 'Phone Info Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		//Icon Color 
		$this->add_control(
			'show_phone_icon_style',
			[
				'label'       => __( 'ON/OFF Phone Icon Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);	
		$this->add_control(
            'phone_icon_color',
            [
                'label' => __('Phone Icon Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-cta .inner-icon' => 'color: {{VALUE}}',
					'{{WRAPPER}} .imi-consulting-cta-btn-grp .imi-consulting-cta .inner-icon i' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
				'condition'             => [
					'show_phone_icon_style'    => 'yes',
				]
            ]
        );
		$this->add_control(
            'phone_icon_bg_color',
            [
                'label' => __('Phone Icon BG Color', 'imigrat'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .imi-consulting-cta .inner-icon' => 'background-color: {{VALUE}}',
				],
                'separator' => 'before',
				'condition'             => [
					'show_phone_icon_style'    => 'yes',
				]
            ]
        );
		
		//Phone Title
		$this->add_control(
			'show_phone_title_style',
			[
				'label'       => __( 'ON/OFF Phone Title Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'phone_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-cta .inner-text span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator'  => 'before',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
            ]
        );
		
        $this->add_responsive_control(
            'phone_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-cta .inner-text span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'separator'  => 'before',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'phone_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => 
						'{{WRAPPER}} .imi-consulting-cta .inner-text span
						',	
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]			
			]
		);
		
		$this->add_control(
			'phone_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-consulting-cta .inner-text span' => 'color: {{VALUE}};'
				],
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'phone_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => 
					'{{WRAPPER}} .imi-consulting-cta .inner-text span
					',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'phone_title_text_stroke',
				'selector' => '{{WRAPPER}} .imi-consulting-cta .inner-text span',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'phone_title_shadow',
				'selector' => '{{WRAPPER}} .imi-consulting-cta .inner-text span',
				'condition'             => [
					'show_phone_title_style'    => 'yes',
				]
			]
		);
		//Phone No
		$this->add_control(
			'show_phone_no_style',
			[
				'label'       => __( 'ON/OFF Phone Number Style', 'imigrat' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'imigrat' ),
				'label_off' => esc_html__( 'Hide', 'imigrat' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		$this->add_responsive_control(
            'phone_no__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-cta .inner-text h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
            ]
        );
		
        $this->add_responsive_control(
            'phone_no_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-consulting-cta .inner-text h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
            ]
        );
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'phone_no_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .imi-consulting-cta .inner-text h3',	
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]			
			]
		);
		
		$this->add_control(
			'phone_no_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-consulting-cta .inner-text h3' => 'color: {{VALUE}};',
				],
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'phone_no_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '{{WRAPPER}} .imi-consulting-cta .inner-text h3',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'phone_no_stroke',
				'selector' => '{{WRAPPER}} .imi-consulting-cta .inner-text h3',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'phone_no_shadow',
				'selector' => '{{WRAPPER}} .imi-consulting-cta .inner-text h3',
				'condition'             => [
					'show_phone_no_style'    => 'yes',
				]
			]
		);
		$this->end_controls_section();
		
	}
	
	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		$icon = $settings[ 'icon' ];
		$layout = $settings[ 'layout_control' ];
	?>
    
	<?php if( $layout == 2 ):?>
    
    <div class="imi-consulting-cta-btn-grp p-0 m-0 d-flex align-items-center wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">
        <div class="imi-consulting-cta d-flex align-items-center">
            <div class="inner-icon d-flex align-items-center justify-content-center">
                <?php if( !empty( $icon ) ):?>
					<?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
                <?php else:?>
                    <i class="fas fa-phone-alt"></i>
                <?php endif;?>
            </div>
            <div class="inner-text headline">
                <span><?php echo wp_kses($settings['phone_title'], true); ?></span>
                <h3><?php echo wp_kses($settings['phone_no'], true); ?></h3>
            </div>
        </div>
    </div>
    
	<?php else: ?>
    
    <div class="imi-consulting-cta d-flex align-items-center wow fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">
        <div class="inner-icon d-flex align-items-center justify-content-center">
        <?php if( !empty( $icon ) ):?>
            <?php \Elementor\Icons_Manager::render_icon( $icon ); ?>
        <?php else:?>
            <i class="fas fa-phone-alt"></i>
        <?php endif;?>        
        </div>
        <div class="inner-text headline">
            <span><?php echo wp_kses($settings['phone_title'], true); ?></span>
            <h3><?php echo wp_kses($settings['phone_no'], true); ?></h3>
        </div>
	</div>
    
    <?php endif;
    }
}