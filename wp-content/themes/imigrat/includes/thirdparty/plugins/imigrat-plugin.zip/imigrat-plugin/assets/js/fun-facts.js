(function($) {

	"use strict";
	var fun_facts = function($scope, $) {

        // load it after jquery is loaded
        // $('.counter').counterUp({
        //     delay: 10,
        //     time: 1000
        // });

	};

	$(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_get_funfacts.default', fun_facts);
    });

})(window.jQuery);