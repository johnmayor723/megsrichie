<?php
extract($args);
echo wp_kses_post($before_widget); ?>

<div class="logo-widget">
    <?php if ($instance['widget_logo_img']) { ?>
    <a class="mb-25 d-block" href="<?php echo home_url('/'); ?>">
        <img src="<?php echo esc_url(wp_get_attachment_url($instance['widget_logo_img']['id'])); ?>" alt="<?php esc_attr_e('Awesome Image', 'imigrat'); ?>">
    </a>
    <?php } ?>

	<?php if ($instance['content2']) { ?>
    <div class="text">
        <?php echo wp_kses_post($instance['content2']); ?>
    </div>
    <?php } ?>

	<?php if($instance['widget_author_name'] || $instance['widget_email_address']){ ?>
    <div class="tweet-box">
        <div class="tweet-box_inner">
            <div class="tweet-box_icon fab fa-twitter"></div>
            <?php echo wp_kses_post($instance['widget_author_name']); ?>
            <a href="<?php echo esc_attr($instance['widget_email_address']); ?>"><i><?php echo wp_kses_post($instance['widget_email_address']); ?></i></a>
        </div>
    </div>
    <?php } ?>

</div>
<?php

echo wp_kses_post($after_widget);
