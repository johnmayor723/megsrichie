<?php

extract($args);
$title = apply_filters('widget_title', $instance['title']);
echo wp_kses_post($before_widget); ?>

<!-- Footer Column -->
<div class="contact-widget">
    <?php echo wp_kses_post($before_title . $title . $after_title); ?>
    <div class="imi-2-contact-item-area">
        <?php if($instance['contact_address']){ ?>
        <div class="imi-2-contact-item d-flex">
            <div class="inner-icon">
                <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="inner-text">
                <?php echo wp_kses_post($instance['contact_address']); ?>
            </div>
        </div>
        <?php } ?>
        <?php if($instance['contact_phone']){ ?>
        <div class="imi-2-contact-item d-flex">
            <div class="inner-icon">
                <i class="fas fa-phone-alt"></i>
            </div>
            <div class="inner-text">
                <?php echo wp_kses_post($instance['contact_phone']); ?>
            </div>
        </div>
        <?php } ?>
    </div>
    <?php if ($instance['opening_hours_title'] || $instance['opening_hours_days']) { ?>
    <div class="imi-2-open-hours">
        <h4><?php echo wp_kses_post($instance['opening_hours_title']); ?> </h4>
        <p><?php echo wp_kses_post($instance['opening_hours_days']); ?></p>
    </div>
    <?php } ?>
</div>

<?php
echo wp_kses_post($after_widget);
