<?php namespace IMIGRATPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Stroke;
use Elementor\Plugin;
/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Why_Choose_Us extends Widget_Base {
    /**
     * Get widget name.
     * Retrieve button widget name.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'imigrat_why_choose_us';
    }
    /**
     * Get widget title.
     * Retrieve button widget title.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__( 'Imigrat Why Choose Us', 'imigrat' );
    }
    /**
     * Get widget icon.
     * Retrieve button widget icon.
     *
     * @since  1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-form-horizontal';
    }
    /**
     * Get widget categories.
     * Retrieve the list of categories the button widget belongs to.
     * Used to determine where to display the widget in the editor.
     *
     * @since  2.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'imigrat' ];
    }

	public function get_script_depends() {
		wp_register_script( 'why_choose_us', YT_URL . 'assets/js/why_choose_us.js', [ 'elementor-frontend' ], '1.0.0', true );
		return [ 'why_choose_us' ];
	}
    /**
     * Register button widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since  1.0.0
     * @access protected
     */
    protected function register_controls() {

		// design style section
		$this->start_controls_section(
            'why_choose_us',
            [
                'label' => esc_html__( 'DESIGN STYLE', 'imigrat' ),
            ]
        );

		// design style section
		$this->add_control(
			'style',
			[
				'label' => __( 'CHOOSE STYLE', 'imigrat' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => __( 'Style 1', 'imigrat' ),
				],
			]
		);

		$this->end_controls_section();

		// design style section
		$this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'IMAGE SECTION', 'imigrat' ),
            ]
        );

		$this->add_control(
			'sec_bg_image',
			[
				'label' => esc_html__('Section Bg Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Shape Image ', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->add_control(
			'image1',
			[
				'label' => esc_html__('Image 1', 'imigrat'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__( 'CONTENT SECTION', 'imigrat' ),
            ]
        );

		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Sub Title', 'imigrat' ),
				'default' => esc_html__( 'Trusted By Thousand', 'imigrat' ),

			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Title', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'text',
			[
				'label' => esc_html__( 'Text ', 'imigrat' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'placeholder' => esc_html__( 'Enter your Text', 'imigrat' ),
				'default' => esc_html__( 'Take a trivial example which of ever undertakes', 'imigrat' ),

			]
		);

		$this->add_control(
			'features_list',
			[
				'label' => esc_html__('Feature List', 'imigrat'),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'imigrat' ),
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'skill_section',
            [
                'label' => esc_html__( 'SKILL SECTION', 'imigrat' ),
            ]
        );

        $repeater = new Repeater();

		$repeater->add_control(
			'skill_title',
			[
				'label'       => __( 'Skill Title', 'imigrat' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'label_block' => true,
				'placeholder' => __( 'Enter your List', 'imigrat' ),
			]
		);

        // percentage
        $repeater->add_control(
            'percentage',
            [
                'label' => esc_html__( 'Percentage', 'imigrat' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ '%' ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 50,
                ],
            ]
        );

        // color picker
        $repeater->add_control(
            'skill_color',
            [
                'label' => esc_html__( 'Color', 'imigrat' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#000',
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .bar' => 'background-color: {{VALUE}} !important;',
                ],
            ]
        );

		$this->add_control(
			'skill_lists',
			[
				'label'     => __('Add skill Item', 'imigrat'),
				'type'      => Controls_Manager::REPEATER,
				'fields'    => $repeater->get_controls(),
				'title_field' => '{{{ skill_title }}}',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'button_section',
            [
                'label' => esc_html__( 'BUTTONS', 'imigrat' ),
            ]
        );

		// video button link
		$this->add_control(
			'video_button_link',
			[
				'label' => esc_html__('Video Button Link', 'imigrat'),
				'type' => Controls_Manager::URL,
				'placeholder' => esc_html__('https://your-link.com', 'imigrat'),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

	/************************************************************************
								Tab Style Start
	*************************************************************************/

		//Small Title Style
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => esc_html__( 'Sub Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'sub_title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'sub_title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'sub_title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .color-layer',
			]
		);

		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 .imi-subtitle' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'sub_title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'sub_title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 .imi-subtitle,
				{{WRAPPER}} .sec-title .title',
			]
		);
		$this->end_controls_section();

		//Title Style
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'title__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-section-title-2 h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'title_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-section-title-2 h2' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title h2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'title_text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'title_text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-section-title-2 h2,
				{{WRAPPER}} .sec-title h2',
			]
		);
		$this->end_controls_section();


		//Text Style
		$this->start_controls_section(
			'text_style',
			[
				'label' => esc_html__( 'Text', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
            'text__margin',
            [
                'label'      => esc_html__( 'Margin', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'text_padding',
            [
                'label'      => esc_html__( 'Padding', 'pyloncore' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .sec-title .text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'text_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p' => 'color: {{VALUE}};',
					'{{WRAPPER}} .sec-title .text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => __('Typography', 'imigrat'),
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'text_stroke',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);

		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '
				{{WRAPPER}} .imi-about-page-text-area .imi-about-text-desc p,
				{{WRAPPER}} .sec-title .text',
			]
		);
		$this->end_controls_section();

		//Feature List Style
		$this->start_controls_section(
			'feature_list_style',
			[
				'label' => esc_html__( 'Feature List', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
            'feature_list__margin',
            [
                'label'      => esc_html__( 'Margin', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list-2 ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .about-one_check' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'feature_list_padding',
            [
                'label'      => esc_html__( 'Padding', 'imigrat' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors'  => [
                    '{{WRAPPER}} .imi-about-feature-list-2 ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .about-one_check' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'feature_list_bgtype',
				'label' => __( 'Background', 'imigrat' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '
					{{WRAPPER}} .imi-about-feature-list-2 ul,
					{{WRAPPER}} .about-one_check
				',
			]
		);

		$this->add_control(
			'feature_list_color',
			[
				'label' => esc_html__( 'Text Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li' => 'color: {{VALUE}};',
					'{{WRAPPER}} .about-one_check li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_list_typography',
				'label' => __('Typography', 'cleanex'),
				'selector' => '
				{{WRAPPER}} .imi-about-feature-list-2 ul li
				{{WRAPPER}} .about-one_check li',
			]
		);

		$this->add_control(
			'feature_list_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li:before' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'feature_list_icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .imi-about-feature-list-2 ul li:before' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Text_Stroke::get_type(),
			[
				'name' => 'feature_list_text_stroke',
				'selector' => '
					{{WRAPPER}} .imi-about-feature-list-2 ul li,
					{{WRAPPER}} .about-one_check li
				',
			]
		);
		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'feature_list_text_shadow',
				'selector' => '
						{{WRAPPER}} .imi-about-feature-list-2 ul li,
						{{WRAPPER}} .about-one_check li',
			]
		);
		$this->end_controls_section();

		// skkil list style
		$this->start_controls_section(
			'skill_list_style',
			[
				'label' => esc_html__( 'Skill List', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// skill title color
		$this->add_control(
			'skill_title_color',
			[
				'label' => esc_html__( 'Title Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skills .skill-item .skill-header .skill-title' => 'color: {{VALUE}};',
				],
			]
		);

		// skil title typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'skill_title_typography',
				'label' => __('Title Typography', 'cleanex'),
				'selector' => '{{WRAPPER}} .skills .skill-item .skill-header .skill-title',
			]
		);

		// skil percentage color
		$this->add_control(
			'skill_percentage_color',
			[
				'label' => esc_html__( 'Percentage Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .skills .count-box' => 'color: {{VALUE}};',
				],
			]
		);

		// skill percentage typography
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'skill_percentage_typography',
				'label' => __('Percentage Typography', 'cleanex'),
				'selector' => '{{WRAPPER}} .skills .count-box',
			]
		);

		// skil inner height
		$this->add_control(
			'skill_inner_height',
			[
				'label' => esc_html__( 'Inner Height', 'imigrat' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .skills .skill-item .skill-bar .bar-inner .bar' => 'height: {{SIZE}}px;',
				],
			]
		);

		// skill outer height
		$this->add_control(
			'skill_outer_height',
			[
				'label' => esc_html__( 'Outer Height', 'imigrat' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .skills .skill-item .skill-bar' => 'height: {{SIZE}}px;',
				],
			]
		);

		// skill boreder
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .skills .skill-item .skill-bar',
			]
		);

		// skill border group
		$this->end_controls_section();

		// vide button style'
		$this->start_controls_section(
			'video_button_style',
			[
				'label' => esc_html__( 'Video Button', 'imigrat' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		// video button height & width
		$this->add_control(
			'video_button_height_width',
			[
				'label' => esc_html__( 'Height & Width', 'imigrat' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .choose-one_video-box' => 'height: {{SIZE}}px; width: {{SIZE}}px;',
				],
			]
		);

		// video button size
		$this->add_control(
			'video_button_size',
			[
				'label' => esc_html__( 'Icon Size', 'imigrat' ),
				'type' => Controls_Manager::SLIDER,
				'selectors' => [
					'{{WRAPPER}} .choose-one_video-box' => 'font-size: {{SIZE}}px;',
				],
			]
		);

		// add normal tab
		$this->start_controls_tabs(
			'video_button_style_tabs'
		);

		// add normal tab
		$this->start_controls_tab(
			'video_button_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'imigrat' ),
			]
		);

		// video button color
		$this->add_control(
			'video_button_color',
			[
				'label' => esc_html__( 'Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .choose-one_video-box::before' => 'color: {{VALUE}};',
				],
			]
		);

		// video button background color
		$this->add_control(
			'video_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .choose-one_video-box' => 'background-color: {{VALUE}};',
				],
			]
		);

		// end normal tab
		$this->end_controls_tab();

		// add hover tab
		$this->start_controls_tab(
			'video_button_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'imigrat' ),
			]
		);

		// video button hover color
		$this->add_control(
			'video_button_hover_color',
			[
				'label' => esc_html__( 'Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .choose-one_video-box:hover::before' => 'color: {{VALUE}};',
				],
			]
		);

		// video button hover background color
		$this->add_control(
			'video_button_hover_background_color',
			[
				'label' => esc_html__( 'Background Color', 'imigrat' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .choose-one_video-box:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
	?>

	<?php if($settings['style'] == 'style4' ) : ?>


	<?php else : ?>

	<!-- add sec_bg_image image in before pesodo elment -->
    <section class="choose-one">
        <?php if(!empty( $settings['bg_image']['id'] )) : ?>
		<div class="choose-one_pattern"
            style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_image']['id'])); ?>)">
        </div>
        <?php endif; ?>
		<div class="container">
			<div class="row clearfix">
				<!-- Content Column -->
				<div class="choose-one_content-column col-lg-6 col-md-12 col-sm-12">
					<div class="choose-one_content">
						<div class="sec-title light">

                            <?php if(!empty( $settings['sub_title'] )) : ?>
							<div class="title"><span class="color-layer"></span><?php echo wp_kses($settings['sub_title'], true); ?></div>
							<?php endif; ?>

							<?php if(!empty( $settings['title'] )) : ?>
							<h2><?php echo wp_kses($settings['title'], true); ?></h2>
							<?php endif; ?>

                            <?php if(!empty( $settings['text'] )) : ?>
							<div class="text"><?php echo wp_kses($settings['text'], true); ?></div>
                            <?php endif; ?>

						</div>
						<div class="row clearfix">
							<div class="col-lg-12 col-md-12 col-sm-12">

                                <?php $features_list = $settings['features_list'];
                                    if(!empty($features_list)){
                                    $features_list = explode("\n", ($features_list));
                                ?>
                                <ul class="about-one_check style-two split-in-half">
                                <?php foreach($features_list as $features): ?>
                                    <li><?php echo wp_kses($features, true); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <?php } ?>

							</div>
						</div>

						<!-- Skills -->
						<div class="skills">
                            <?php foreach( $settings['skill_lists'] as $skill ) : ?>
							<!-- Skill Item -->
							<div class="skill-item">
								<div class="skill-header clearfix">
                                    <?php if(!empty( $skill['skill_title'] )) : ?>
									<div class="skill-title"><?php echo wp_kses($skill['skill_title'], true); ?></div>
                                    <?php endif; ?>
								</div>
								<div class="skill-bar">
									<div class="bar-inner">
										<div class="bar progress-line"
                                            data-width="<?php echo esc_attr($skill['percentage']['size']); ?>"
											data-bg-color="<?php echo esc_attr($skill['skill_color']); ?>">
											<div class="skill-percentage"></div>
										</div>
									</div>
								</div>
								<div class="count-box"><span class="counter"><?php echo esc_html($skill['percentage']['size']); ?></span>%</div>

							</div>
                            <?php endforeach; ?>

						</div>

					</div>
				</div>

				<!-- Video Column -->
				<div class="choose-one_video-column col-lg-6 col-md-12 col-sm-12">
					<!-- Choose One Video -->
					<div class="choose-one_video">
                        <?php if(!empty( $settings['image1']['id'] )) : ?>
						<img src="<?php echo esc_url(wp_get_attachment_url($settings['image1']['id'])); ?>" alt="" />
                        <?php endif; ?>

                        <?php if(!empty( $settings['video_button_link']['url'] )) : ?>
						<a href="<?php echo esc_url($settings['video_button_link']['url']); ?>" class="video_box choose-one_video-box fa fa-play">
                            <i class="ripple"></i>
                        </a>
                        <?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
    <?php
		endif;
    }
}