(function($) {
	
	"use strict";
	var visa_carousel_script_js = function($scope, $) {
		
		$(document).ready(function () {
			var swiper = new Swiper(".imi-visa-category-slider", {
				slidesPerView: 3,
				spaceBetween: 30,                  
				loop: true,
				navigation: false,
				pagination: {
					el: ".swiper-paginations",
					clickable: true,
				},
				breakpoints: {
					1500: {
						slidesPerView: 3,
					},
					1199: {
						slidesPerView: 3,
					},
					1024: {
						slidesPerView: 2,
					},
					767: {
						slidesPerView: 2,
					},
					575: {
						slidesPerView: 1,
					},
					0: {
						slidesPerView: 1,
					}
				},
			});
		});
		
	};
	
	$(window).on('elementor/frontend/init', function () {
            elementorFrontend.hooks.addAction('frontend/element_ready/imigrat_visa_carousel.default', visa_carousel_script_js);
    });	

})(window.jQuery);